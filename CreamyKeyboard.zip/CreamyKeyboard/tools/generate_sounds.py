#!/usr/bin/env python3
"""
Creamy Keyboard - mechanical switch sound generator.

Every key sound is synthesised (no samples, no licensing issues):
  * a damped "thock" resonance of the case/plate with a quick pitch drop,
  * two softer overtones (plate + keycap),
  * a sub-bass pop for the bottom-out,
  * a very soft low-passed tap (this is what makes it "creamy": no sharp click),
  * gentle saturation + low-pass for warmth.

Tweak PROFILES / KINDS and re-run to taste:

    python3 tools/generate_sounds.py                 # -> app/src/main/res/raw
    python3 tools/generate_sounds.py some/out/dir

Output files are named  snd_<profile>_<name>.wav  (44.1 kHz, mono, 16 bit).
"""
import os
import sys
import wave
import zlib

import numpy as np

SR = 44100

# body f0 / decay, overtones, tap, sub pop, final low-pass.
# Phone speakers roll off below ~300 Hz, so the "thock" body sits at 250-400 Hz
# (audible everywhere) and the sub pop adds depth on headphones.
PROFILES = {
    "creamy": dict(f0=292, tb=34, f1=590, t1=22, f2=1010, t2=12, tap_lp=2600, tap_amp=0.55,
                   tap_tau=2.4, click=0.07, pop=0.45, pop_f=120, glide=0.28, lp=5200),
    "thock": dict(f0=214, tb=46, f1=430, t1=28, f2=760, t2=15, tap_lp=2000, tap_amp=0.45,
                  tap_tau=3.0, click=0.04, pop=0.70, pop_f=96, glide=0.34, lp=4200),
    "linear": dict(f0=385, tb=26, f1=770, t1=15, f2=1300, t2=9, tap_lp=3400, tap_amp=0.60,
                   tap_tau=2.0, click=0.10, pop=0.22, pop_f=150, glide=0.20, lp=6400),
}

# fm = pitch multiplier, dm = decay multiplier, g = gain, ms = length
KINDS = {
    "alpha": dict(fm=1.00, dm=1.00, g=1.00, ms=130),
    "space": dict(fm=0.82, dm=1.35, g=1.10, ms=190),
    "enter": dict(fm=0.88, dm=1.15, g=1.05, ms=170),
    "back": dict(fm=0.92, dm=1.05, g=1.00, ms=150),
    "mod": dict(fm=0.95, dm=0.85, g=0.90, ms=120),
}

FILES = []  # (resource suffix, kind, is_down, variant)
FILES += [(f"d{i}", "alpha", True, i) for i in range(1, 6)]
FILES += [(f"u{i}", "alpha", False, i) for i in range(1, 4)]
FILES += [(f"sd{i}", "space", True, i) for i in range(1, 3)] + [("su1", "space", False, 1)]
FILES += [("ed1", "enter", True, 1), ("eu1", "enter", False, 1)]
FILES += [(f"bd{i}", "back", True, i) for i in range(1, 3)] + [("bu1", "back", False, 1)]
FILES += [("md1", "mod", True, 1), ("mu1", "mod", False, 1)]


def tvec(n):
    return np.arange(n) / SR


def damped_sine(n, f, tau_ms, phase=0.0, glide=0.0, glide_tau_ms=8.0):
    t = tvec(n)
    fr = f * (1.0 + glide * np.exp(-t / (glide_tau_ms / 1000.0)))
    ph = 2.0 * np.pi * np.cumsum(fr) / SR + phase
    return np.sin(ph) * np.exp(-t / (tau_ms / 1000.0))


def lowpass(x, fc, order=2):
    a = float(np.exp(-2.0 * np.pi * fc / SR))
    y = np.asarray(x, dtype=np.float64)
    for _ in range(order):
        out = np.empty_like(y)
        acc = 0.0
        for i in range(len(y)):
            acc = (1.0 - a) * y[i] + a * acc
            out[i] = acc
        y = out
    return y


def finish(x, peak, fade_ms=16):
    x = x / (np.max(np.abs(x)) + 1e-9) * peak
    f = int(SR * fade_ms / 1000)
    x[-f:] *= np.linspace(1.0, 0.0, f) ** 2
    return x


def synth_down(p, k, seed):
    r = np.random.default_rng(seed)
    n = int(SR * k["ms"] / 1000)
    jf = 1.0 + r.uniform(-0.045, 0.045)
    dm = k["dm"] * (1.0 + r.uniform(-0.10, 0.10))
    fm = k["fm"] * jf
    body = damped_sine(n, p["f0"] * fm, p["tb"] * dm, glide=p["glide"], glide_tau_ms=11)
    mid = 0.46 * damped_sine(n, p["f1"] * fm, p["t1"] * dm, phase=0.6, glide=0.15, glide_tau_ms=7)
    top = 0.20 * damped_sine(n, p["f2"] * fm, p["t2"] * dm, phase=1.1)
    pop = p["pop"] * damped_sine(n, p["pop_f"] * k["fm"], 22 * dm, phase=0.3, glide=0.5, glide_tau_ms=6)
    tap = lowpass(r.standard_normal(n), p["tap_lp"], 2)
    tap = tap * np.exp(-tvec(n) / (p["tap_tau"] / 1000.0))
    tap = tap / (np.max(np.abs(tap)) + 1e-9) * p["tap_amp"]
    click = p["click"] * damped_sine(n, 2300 * jf, 2.8, phase=0.2)
    x = body + mid + top + pop + tap + click
    x *= 1.0 - np.exp(-tvec(n) / 0.0004)          # soft attack, no digital click
    x = np.tanh(1.6 * x) / np.tanh(1.6)             # warmth
    x = lowpass(x, p["lp"], 2)
    return finish(x, min(0.95, 0.80 * k["g"]))


def synth_up(p, k, seed):
    r = np.random.default_rng(seed)
    n = int(SR * 72 / 1000)
    jf = 1.0 + r.uniform(-0.05, 0.05)
    f0 = p["f0"] * 1.45 * (k["fm"] ** 0.5) * jf
    body = 0.6 * damped_sine(n, f0, 12, glide=0.12, glide_tau_ms=5)
    tap = lowpass(r.standard_normal(n), p["tap_lp"] * 1.3, 2) * np.exp(-tvec(n) / 0.0018)
    tap = tap / (np.max(np.abs(tap)) + 1e-9) * 0.30
    x = body + tap + 0.04 * damped_sine(n, 2100 * jf, 2.2)
    x *= 1.0 - np.exp(-tvec(n) / 0.0003)
    x = lowpass(np.tanh(1.3 * x), p["lp"], 2)
    return finish(x, 0.34 * k["g"], 12)


def write_wav(path, x):
    data = (np.clip(x, -1.0, 1.0) * 32767).astype("<i2").tobytes()
    with wave.open(path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(data)


def main():
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    out = sys.argv[1] if len(sys.argv) > 1 else os.path.join(root, "app", "src", "main", "res", "raw")
    os.makedirs(out, exist_ok=True)
    count = 0
    for prof, p in PROFILES.items():
        for name, kind, down, var in FILES:
            seed = zlib.crc32(f"{prof}/{name}".encode())
            k = KINDS[kind]
            x = synth_down(p, k, seed) if down else synth_up(p, k, seed)
            write_wav(os.path.join(out, f"snd_{prof}_{name}.wav"), x)
            count += 1
    print(f"wrote {count} sounds to {out}")


if __name__ == "__main__":
    main()

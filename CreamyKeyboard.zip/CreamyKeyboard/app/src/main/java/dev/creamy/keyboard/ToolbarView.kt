package dev.creamy.keyboard

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Build
import android.os.SystemClock
import android.text.TextPaint
import android.text.TextUtils
import android.view.MotionEvent
import android.view.View
import androidx.core.graphics.ColorUtils
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

class ToolDef(val id: String, val icon: Int, val label: String)

/**
 * The strip above the keys. It has four faces: suggestion chips (best one in the middle), a
 * scrollable tool bar, an inline search field (emoji / GIF / web) and a listening indicator.
 */
class ToolbarView(ctx: Context) : View(ctx) {

    interface Listener {
        fun onSuggestion(s: Suggestion)
        fun onToggleTools()
        fun onTool(id: String)
        fun onMic()
        fun onInlineBack()
        fun onInlineSubmit()
        fun onInlineResult(i: Int)
        fun onPaste()
    }

    companion object {
        const val M_SUGGEST = 0
        const val M_TOOLS = 1
        const val M_INLINE = 2
        const val M_VOICE = 3
    }

    var listener: Listener? = null
    var theme: KbTheme? = null
        set(v) {
            field = v
            invalidate()
        }
    var mode = M_SUGGEST
        set(v) {
            field = v
            offX = 0f
            invalidate()
        }
    var tools: List<ToolDef> = emptyList()
        set(v) {
            field = v
            invalidate()
        }
    var activeTools: Set<String> = emptySet()
        set(v) {
            field = v
            invalidate()
        }
    var inlineText = ""
        set(v) {
            field = v
            invalidate()
        }
    var inlineHint = ""
    var inlineResults: List<String> = emptyList()
        set(v) {
            field = v
            offX = 0f
            invalidate()
        }
    var voiceText = ""
        set(v) {
            field = v
            invalidate()
        }
    var clipText: String? = null
        set(v) {
            field = v
            invalidate()
        }
    var incognito = false
        set(v) {
            field = v
            invalidate()
        }

    private val slots = arrayOfNulls<Suggestion>(3)
    private val density = ctx.resources.displayMetrics.density
    private fun dp(v: Float): Float = v * density

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val txt = TextPaint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val path = Path()
    private val hitId = ArrayList<Int>()
    private val hitRect = ArrayList<RectF>()
    private var offX = 0f
    private var maxOff = 0f

    private var pressId = -1
    private var downX = 0f
    private var downOff = 0f
    private var dragging = false
    private val pressSpring = Spring(1f, 1f, 900f, 0.6f)
    private var animating = false
    private var lastFrame = 0L

    private val tf: Typeface = if (Build.VERSION.SDK_INT >= 28) {
        Typeface.create(Typeface.create("sans-serif-rounded", Typeface.NORMAL), 600, false)
    } else {
        Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }

    init {
        txt.textAlign = Paint.Align.CENTER
        txt.typeface = tf
    }

    fun setItems(list: List<Suggestion>) {
        slots[0] = list.getOrNull(1)
        slots[1] = list.getOrNull(0)
        slots[2] = list.getOrNull(2)
        invalidate()
    }

    fun hasItems(): Boolean = slots[0] != null || slots[1] != null || slots[2] != null

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        setMeasuredDimension(MeasureSpec.getSize(wSpec), dp(52f).toInt())
    }

    // ---------------------------------------------------------------- drawing helpers

    private fun cookie(c: Canvas, th: KbTheme, r: RectF, fill: Int, rot: Float, scale: Float) {
        paint.style = Paint.Style.FILL
        paint.color = fill
        val s = min(r.width(), r.height()) / 2f * scale
        Shapes.fill(path, Shapes.wavy(th.waves, th.amp * 1.3f), r.centerX(), r.centerY(), s, s, rot)
        c.drawPath(path, paint)
    }

    private fun pill(c: Canvas, r: RectF, fill: Int) {
        paint.style = Paint.Style.FILL
        paint.color = fill
        c.drawRoundRect(r, r.height() / 2f, r.height() / 2f, paint)
    }

    private fun label(c: Canvas, s: String, r: RectF, size: Float, color: Int, maxW: Float) {
        txt.textSize = size
        txt.color = color
        val t = TextUtils.ellipsize(s, txt, maxW, TextUtils.TruncateAt.END).toString()
        val fm = txt.fontMetrics
        c.drawText(t, r.centerX(), r.centerY() - (fm.ascent + fm.descent) / 2f, txt)
    }

    private fun scaled(id: Int, r: RectF): RectF {
        if (id != pressId) return r
        val s = pressSpring.value
        val cx = r.centerX()
        val cy = r.centerY()
        rect.set(cx - r.width() / 2f * s, cy - r.height() / 2f * s, cx + r.width() / 2f * s, cy + r.height() / 2f * s)
        return rect
    }

    private fun hit(id: Int, r: RectF) {
        hitId.add(id)
        hitRect.add(RectF(r))
    }

    // ---------------------------------------------------------------- drawing

    override fun onDraw(c: Canvas) {
        val th = theme ?: return
        hitId.clear()
        hitRect.clear()
        val w = width.toFloat()
        val h = height.toFloat()
        val pad = dp(6f)
        val bs = h - 2f * pad
        val gap = dp(6f)
        val left = RectF(pad, pad, pad + bs, pad + bs)
        val right = RectF(w - pad - bs, pad, w - pad, pad + bs)
        val mL = left.right + gap
        val mR = right.left - gap
        val iconSize = bs * 0.5f

        when (mode) {
            M_SUGGEST -> {
                hit(1, left)
                val l = scaled(1, left)
                cookie(c, th, l, th.btn, 0f, 1f)
                KbIcons.draw(c, if (incognito) KbIcons.INCOGNITO else KbIcons.MENU, l.centerX(), l.centerY(), iconSize, th.btnText)
                hit(2, right)
                val rr = scaled(2, right)
                cookie(c, th, rr, th.btn, 0f, 1f)
                KbIcons.draw(c, KbIcons.MIC, rr.centerX(), rr.centerY(), iconSize, th.btnText)
                drawChips(c, th, mL, mR, bs, pad, gap)
            }
            M_TOOLS -> {
                hit(1, left)
                val l = scaled(1, left)
                cookie(c, th, l, th.btn, 0f, 1f)
                KbIcons.draw(c, KbIcons.CHEV_L, l.centerX(), l.centerY(), iconSize, th.btnText)
                val bw = bs * 1.18f
                val total = tools.size * (bw + gap)
                maxOff = max(0f, total - (w - mL - pad) - 0f)
                if (offX > maxOff) offX = maxOff
                c.save()
                c.clipRect(mL, 0f, w, h)
                for (i in tools.indices) {
                    val t = tools[i]
                    val x = mL + i * (bw + gap) - offX
                    if (x + bw < mL || x > w) continue
                    val r = RectF(x, pad, x + bw, pad + bs)
                    val on = activeTools.contains(t.id)
                    hit(10 + i, RectF(max(x, mL), r.top, min(x + bw, w), r.bottom))
                    val sr = scaled(10 + i, r)
                    pill(c, sr, if (on) th.chipSel else th.chip)
                    KbIcons.draw(c, t.icon, sr.centerX(), sr.centerY(), iconSize * 0.92f, if (on) th.chipSelText else th.chipText)
                }
                c.restore()
            }
            M_INLINE -> {
                hit(1, left)
                val l = scaled(1, left)
                cookie(c, th, l, th.btn, 0f, 1f)
                KbIcons.draw(c, KbIcons.CHEV_L, l.centerX(), l.centerY(), iconSize, th.btnText)
                hit(2, right)
                val rr = scaled(2, right)
                cookie(c, th, rr, th.accent, 0f, 1f)
                KbIcons.draw(c, KbIcons.SEARCH, rr.centerX(), rr.centerY(), iconSize, th.accentText)
                val qEnd = if (inlineResults.isEmpty()) mR else min(mR, mL + (mR - mL) * 0.42f)
                val q = RectF(mL, pad, qEnd, pad + bs)
                pill(c, q, th.chip)
                val shown = inlineText.ifEmpty { inlineHint }
                val col = if (inlineText.isEmpty()) th.hint else th.chipText
                txt.textSize = bs * 0.40f
                txt.color = col
                val tw = min(txt.measureText(shown), q.width() - dp(28f))
                val ell = TextUtils.ellipsize(shown, txt, q.width() - dp(28f), TextUtils.TruncateAt.START).toString()
                txt.textAlign = Paint.Align.LEFT
                val fm = txt.fontMetrics
                c.drawText(ell, q.left + dp(14f), q.centerY() - (fm.ascent + fm.descent) / 2f, txt)
                txt.textAlign = Paint.Align.CENTER
                if (inlineText.isNotEmpty() || ((SystemClock.uptimeMillis() / 500L) % 2L == 0L)) {
                    paint.style = Paint.Style.FILL
                    paint.color = th.accent
                    val cx = q.left + dp(14f) + (if (inlineText.isEmpty()) 0f else tw) + dp(2f)
                    c.drawRect(cx, q.centerY() - bs * 0.2f, cx + dp(2f), q.centerY() + bs * 0.2f, paint)
                }
                if (inlineResults.isNotEmpty()) {
                    val rl = qEnd + gap
                    val rw = bs * 1.05f
                    val total = inlineResults.size * (rw + gap)
                    maxOff = max(0f, total - (mR - rl))
                    if (offX > maxOff) offX = maxOff
                    c.save()
                    c.clipRect(rl, 0f, mR, h)
                    for (i in inlineResults.indices) {
                        val x = rl + i * (rw + gap) - offX
                        if (x + rw < rl || x > mR) continue
                        val r = RectF(x, pad, x + rw, pad + bs)
                        hit(100 + i, RectF(max(x, rl), r.top, min(x + rw, mR), r.bottom))
                        val sr = scaled(100 + i, r)
                        pill(c, sr, th.chip)
                        label(c, inlineResults[i], sr, bs * 0.46f, th.chipText, rw)
                    }
                    c.restore()
                } else {
                    maxOff = 0f
                }
                postInvalidateDelayed(500L)
            }
            else -> {
                hit(1, left)
                val pulse = 1f + 0.08f * sin(SystemClock.uptimeMillis() / 170f)
                cookie(c, th, left, th.accent, SystemClock.uptimeMillis() / 900f, pulse)
                KbIcons.draw(c, KbIcons.MIC, left.centerX(), left.centerY(), iconSize, th.accentText)
                hit(2, right)
                val rr = scaled(2, right)
                cookie(c, th, rr, th.btn, 0f, 1f)
                KbIcons.draw(c, KbIcons.CLOSE, rr.centerX(), rr.centerY(), iconSize, th.btnText)
                val q = RectF(mL, pad, mR, pad + bs)
                pill(c, q, th.chip)
                label(c, voiceText.ifEmpty { Tx.t("Ti ascolto…", "Listening…") }, q, bs * 0.40f, th.chipText, q.width() - dp(24f))
                postInvalidateOnAnimation()
            }
        }
    }

    private fun drawChips(c: Canvas, th: KbTheme, mL: Float, mR: Float, bs: Float, pad: Float, gap: Float) {
        val mw = mR - mL
        val clip = clipText
        if (clip != null && !hasItems()) {
            val r = RectF(mL, pad, mR, pad + bs)
            hit(4, r)
            val sr = scaled(4, r)
            pill(c, sr, th.chipSel)
            KbIcons.draw(c, KbIcons.CLIPBOARD, sr.left + bs * 0.55f, sr.centerY(), bs * 0.42f, th.chipSelText)
            val tr = RectF(sr.left + bs * 0.9f, sr.top, sr.right - dp(10f), sr.bottom)
            txt.textAlign = Paint.Align.LEFT
            txt.textSize = bs * 0.38f
            txt.color = th.chipSelText
            val ell = TextUtils.ellipsize(clip.replace('\n', ' '), txt, tr.width(), TextUtils.TruncateAt.END).toString()
            val fm = txt.fontMetrics
            c.drawText(ell, tr.left, tr.centerY() - (fm.ascent + fm.descent) / 2f, txt)
            txt.textAlign = Paint.Align.CENTER
            return
        }
        val cw = (mw - 2f * gap) / 3f
        for (i in 0 until 3) {
            val s = slots[i] ?: continue
            val x = mL + i * (cw + gap)
            val r = RectF(x, pad, x + cw, pad + bs)
            hit(10 + i, r)
            val sr = scaled(10 + i, r)
            val center = i == 1
            pill(c, sr, if (center) th.chipSel else th.chip)
            val tc = if (center) th.chipSelText else th.chipText
            val text = if (s.kind == Suggestion.LITERAL) "\"" + s.text + "\"" else s.text
            val size = if (s.kind == Suggestion.EMOJI) bs * 0.52f else bs * 0.38f
            label(c, text, sr, size, tc, cw - dp(16f))
        }
    }

    // ---------------------------------------------------------------- touch

    private fun hitAt(x: Float, y: Float): Int {
        for (i in hitId.indices.reversed()) {
            if (hitRect[i].contains(x, y)) return hitId[i]
        }
        return -1
    }

    private val frame = object : Runnable {
        override fun run() {
            val now = SystemClock.uptimeMillis()
            val dt = ((now - lastFrame) / 1000f).coerceIn(0f, 0.05f)
            lastFrame = now
            pressSpring.step(dt)
            invalidate()
            if (!pressSpring.settled()) postOnAnimation(this) else animating = false
        }
    }

    private fun kick() {
        if (!animating) {
            animating = true
            lastFrame = SystemClock.uptimeMillis()
            postOnAnimation(frame)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                downX = e.x
                downOff = offX
                dragging = false
                pressId = hitAt(e.x, e.y)
                pressSpring.target = 0.92f
                kick()
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.x - downX
                if (!dragging && abs(dx) > dp(8f) && maxOff > 0f && (mode == M_TOOLS || mode == M_INLINE)) {
                    dragging = true
                    pressId = -1
                }
                if (dragging) {
                    offX = (downOff - dx).coerceIn(0f, maxOff)
                    invalidate()
                }
            }
            MotionEvent.ACTION_UP -> {
                val id = pressId
                pressId = -1
                pressSpring.target = 1f
                kick()
                if (!dragging && id != -1) dispatch(id)
            }
            MotionEvent.ACTION_CANCEL -> {
                pressId = -1
                pressSpring.target = 1f
                kick()
            }
        }
        return true
    }

    private fun dispatch(id: Int) {
        val l = listener ?: return
        when {
            id == 1 -> if (mode == M_INLINE) l.onInlineBack() else if (mode == M_VOICE) l.onMic() else l.onToggleTools()
            id == 2 -> if (mode == M_INLINE) l.onInlineSubmit() else l.onMic()
            id == 4 -> l.onPaste()
            id in 10..99 -> {
                if (mode == M_TOOLS) {
                    val t = tools.getOrNull(id - 10)
                    if (t != null) l.onTool(t.id)
                } else if (mode == M_SUGGEST) {
                    val s = slots.getOrNull(id - 10)
                    if (s != null) l.onSuggestion(s)
                }
            }
            id >= 100 -> l.onInlineResult(id - 100)
        }
    }
}

package dev.creamy.keyboard

import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.inputmethodservice.InputMethodService
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.text.InputType
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.core.view.inputmethod.EditorInfoCompat
import androidx.core.view.inputmethod.InputConnectionCompat
import androidx.core.view.inputmethod.InputContentInfoCompat
import java.io.File
import java.net.URLEncoder
import java.util.concurrent.Executors

/** Toolbar tools (order and visibility are configurable in the settings app). */
object ToolTable {
    val ids = listOf(
        "clipboard", "emoji", "gif", "sticker", "translate", "ai", "search",
        "voice", "onehand", "resize", "incognito", "theme", "settings"
    )

    fun def(id: String): ToolDef? = when (id) {
        "clipboard" -> ToolDef(id, KbIcons.CLIPBOARD, Tx.t("Appunti", "Clipboard"))
        "emoji" -> ToolDef(id, KbIcons.EMOJI, "Emoji")
        "gif" -> ToolDef(id, KbIcons.GIF, "GIF")
        "sticker" -> ToolDef(id, KbIcons.STICKER, "Sticker")
        "translate" -> ToolDef(id, KbIcons.TRANSLATE, Tx.t("Traduttore", "Translator"))
        "ai" -> ToolDef(id, KbIcons.AI, "AI")
        "search" -> ToolDef(id, KbIcons.SEARCH, Tx.t("Cerca sul web", "Web search"))
        "voice" -> ToolDef(id, KbIcons.MIC, Tx.t("Dettatura", "Voice typing"))
        "onehand" -> ToolDef(id, KbIcons.ONEHAND, Tx.t("Una mano", "One-handed"))
        "resize" -> ToolDef(id, KbIcons.RESIZE, Tx.t("Altezza", "Height"))
        "incognito" -> ToolDef(id, KbIcons.INCOGNITO, Tx.t("Incognito", "Incognito"))
        "theme" -> ToolDef(id, KbIcons.THEME, Tx.t("Tema", "Theme"))
        "settings" -> ToolDef(id, KbIcons.SETTINGS, Tx.t("Impostazioni", "Settings"))
        else -> null
    }
}

class CreamyIME : InputMethodService(), KeyboardView.Listener, ToolbarView.Listener, Host {

    companion object {
        private const val M_LETTERS = 0
        private const val M_SYM1 = 1
        private const val M_SYM2 = 2
        private const val M_NUM = 3
        private const val M_PHONE = 4
    }

    private class Fix(val orig: String, val repl: String, val sep: String)
    private class GlideInfo(var word: String)
    private class Inline(val live: ((String) -> List<String>)?, val submit: (String) -> Unit) {
        val sb = StringBuilder()
    }

    private lateinit var root: KbRoot
    private lateinit var predictor: Predictor
    private lateinit var sounds: SoundEngine
    private lateinit var haptics: Haptics
    private var curTheme: KbTheme? = null

    private val ui = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private var gen = 0

    // field state
    private var info: EditorInfo? = null
    private var mode = M_LETTERS
    private var fieldKind = 0
    private var noSuggest = false
    private var password = false
    private var shift = 0
    private var lastShiftTap = 0L
    private var lang = "en"
    private var langs: List<String> = listOf("en")
    private var shortcuts: Map<String, String> = emptyMap()

    // typing state
    private var word = ""
    private var prev = ""
    private var sentenceStart = true
    private var afterWord = false
    private var spaceAuto = false
    private var lastWasSpace = false
    private var lastSpaceAt = 0L
    private var ownEditAt = 0L
    private var lastFix: Fix? = null
    private var lastGlide: GlideInfo? = null

    // ui state
    private var panel: View? = null
    private var savedPanel: View? = null
    private var inlineSt: Inline? = null
    private var modeBeforeInline = -1
    private var voice: SpeechRecognizer? = null

    // clipboard chip
    private var lastClipText: String? = null
    private var lastClipAt = 0L
    private var clipUsed = true

    private var clipListener: ClipboardManager.OnPrimaryClipChangedListener? = null
    private var prefListener: SharedPreferences.OnSharedPreferenceChangeListener? = null

    private val pending = HashMap<IntP, Int>()
    private var pendingCount = 0

    private val applyRunnable = Runnable {
        refreshPrefs()
        applyAll()
        worker.execute { predictor.warm(langs) }
    }
    private val resyncRunnable = Runnable {
        if (inlineSt == null) {
            refreshContext()
            updateShift()
            requestSuggestions()
        }
    }

    // ------------------------------------------------------------------ lifecycle

    override fun onCreate() {
        super.onCreate()
        Store.init(this)
        predictor = Predictor(this)
        sounds = SoundEngine(this)
        haptics = Haptics(this)
        sounds.warmUp()
        ClipStore.load(this)
        refreshPrefs()
        worker.execute { predictor.warm(langs) }

        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val cl = ClipboardManager.OnPrimaryClipChangedListener { readClip(true) }
        clipListener = cl
        cm.addPrimaryClipChangedListener(cl)

        val pl = SharedPreferences.OnSharedPreferenceChangeListener { _, key -> onPrefChanged(key) }
        prefListener = pl
        Store.sp.registerOnSharedPreferenceChangeListener(pl)
    }

    override fun onDestroy() {
        flushStats()
        stopVoice()
        try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipListener?.let { cm.removePrimaryClipChangedListener(it) }
        } catch (e: Exception) {
            // ignore
        }
        prefListener?.let { Store.sp.unregisterOnSharedPreferenceChangeListener(it) }
        sounds.release()
        predictor.user.save()
        worker.shutdown()
        super.onDestroy()
    }

    override fun onCreateInputView(): View {
        val r = KbRoot(this)
        root = r
        panel = null
        savedPanel = null
        inlineSt = null
        r.kb.listener = this
        r.toolbar.listener = this
        r.side.listener = object : SideStrip.Listener {
            override fun onExpand() {
                P.ONE_HAND.set("off")
            }

            override fun onSwap() {
                P.ONE_HAND.set(if (P.ONE_HAND.get() == "left") "right" else "left")
            }
        }
        applyAll()
        return r
    }

    override fun onEvaluateFullscreenMode(): Boolean = false

    override fun onComputeInsets(outInsets: InputMethodService.Insets) {
        super.onComputeInsets(outInsets)
        if (!::root.isInitialized) return
        val loc = IntArray(2)
        root.getLocationInWindow(loc)
        val top = loc[1] + root.visibleTop()
        if (!isFullscreenMode) {
            outInsets.contentTopInsets = top
            outInsets.visibleTopInsets = top
            outInsets.touchableInsets = InputMethodService.Insets.TOUCHABLE_INSETS_VISIBLE
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (::root.isInitialized) applyAll()
    }

    override fun onStartInputView(info: EditorInfo, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        if (!::root.isInitialized) return
        this.info = info
        parseField(info)
        refreshPrefs()
        inlineSt = null
        savedPanel = null
        if (panel != null) {
            panel = null
            root.setPanel(null)
        }
        word = ""
        prev = ""
        sentenceStart = true
        afterWord = false
        spaceAuto = false
        lastWasSpace = false
        lastFix = null
        lastGlide = null
        applyAll()
        root.kb.enterIcon = enterIconFor(info)
        root.toolbar.mode = ToolbarView.M_SUGGEST
        refreshContext()
        updateShift()
        requestSuggestions()
        readClip(false)
        worker.execute { predictor.warm(langs) }
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        super.onFinishInputView(finishingInput)
        flushStats()
        stopVoice()
        if (::root.isInitialized) root.kb.cancelAll()
        worker.execute { predictor.user.save() }
    }

    override fun onUpdateSelection(
        oldSelStart: Int, oldSelEnd: Int, newSelStart: Int, newSelEnd: Int,
        candidatesStart: Int, candidatesEnd: Int
    ) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd)
        if (!::root.isInitialized || inlineSt != null) return
        if (SystemClock.uptimeMillis() - ownEditAt < 220L) return
        // the cursor was moved (or the text changed) by someone else: resync
        lastFix = null
        lastGlide = null
        spaceAuto = false
        lastWasSpace = false
        ui.removeCallbacks(resyncRunnable)
        ui.postDelayed(resyncRunnable, 60L)
    }

    // ------------------------------------------------------------------ preferences / theme / layout

    private fun onPrefChanged(key: String?) {
        val k = key ?: return
        if (k == P.CLEAR_VER.key) {
            worker.execute { predictor.user.clear() }
            return
        }
        if (k == P.DICT_VER.key) {
            predictor.reloadLexicons()
            worker.execute { predictor.warm(langs) }
            return
        }
        if (k.startsWith("st_") || k.startsWith("ai_") || k.startsWith("clip") || k == P.ACTIVE.key ||
            k == P.EMOJI_RECENT.key || k == P.GIPHY.key || k == P.TR_TARGET.key
        ) return
        ui.removeCallbacks(applyRunnable)
        ui.postDelayed(applyRunnable, 90L)
    }

    private fun refreshPrefs() {
        langs = Langs.enabled()
        lang = Langs.active()
        shortcuts = parseShortcuts(P.SHORTCUTS.get())
    }

    private fun parseShortcuts(s: String): Map<String, String> {
        val m = HashMap<String, String>()
        for (line in s.lines()) {
            val i = line.indexOf('=')
            if (i > 0) {
                val k = line.substring(0, i).trim().lowercase()
                val v = line.substring(i + 1).trim()
                if (k.isNotEmpty() && v.isNotEmpty()) m[k] = v
            }
        }
        return m
    }

    private fun applyAll() {
        if (!::root.isInitialized) return
        val th = Themes.build(this)
        curTheme = th
        root.applyTheme(th)
        val kb = root.kb
        kb.glideOn = P.GLIDE.get() && !password
        kb.previewOn = P.PREVIEW.get()
        kb.hintsOn = P.HINTS.get()
        kb.trailOn = P.TRAIL.get()
        kb.spaceCursorOn = P.SPACE_CURSOR.get()
        kb.backSwipeOn = P.BACK_SWIPE.get()
        kb.longPressMs = P.LONGPRESS.get().toLong()
        root.setOneHand(P.ONE_HAND.get(), P.ONE_HAND_W.get())
        buildTools()
        loadLayout()
    }

    private fun buildTools() {
        if (!::root.isInitialized) return
        val list = ArrayList<ToolDef>()
        for (id in P.TOOLS.get().split(",")) {
            val d = ToolTable.def(id.trim())
            if (d != null) list.add(d)
        }
        val active = HashSet<String>()
        if (P.INCOGNITO.get()) active.add("incognito")
        if (P.ONE_HAND.get() != "off") active.add("onehand")
        root.toolbar.tools = list
        root.toolbar.activeTools = active
        root.toolbar.incognito = P.INCOGNITO.get()
    }

    private fun loadLayout() {
        if (!::root.isInitialized) return
        val l = Langs.get(lang)
        val objs = langs.map { Langs.get(it) }
        val globe = langs.size > 1
        val lay = when (mode) {
            M_SYM1 -> LayoutFactory.symbols1(l, globe, fieldKind, objs)
            M_SYM2 -> LayoutFactory.symbols2(globe, fieldKind, objs)
            M_NUM -> LayoutFactory.numeric()
            M_PHONE -> LayoutFactory.phone()
            else -> LayoutFactory.letters(l, P.LAYOUT.get(), P.NUMBER_ROW.get(), globe, fieldKind, objs)
        }
        val kb = root.kb
        kb.theme = curTheme
        kb.kbLayout = lay
        kb.spaceLabel = if (mode == M_NUM || mode == M_PHONE) "" else l.name
        kb.shift = shift
        kb.refresh()
        root.requestLayout()
    }

    private fun setMode(m: Int) {
        mode = m
        loadLayout()
    }

    private fun parseField(ei: EditorInfo) {
        val t = ei.inputType
        val cls = t and InputType.TYPE_MASK_CLASS
        val v = t and InputType.TYPE_MASK_VARIATION
        val numeric = cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_DATETIME
        val phone = cls == InputType.TYPE_CLASS_PHONE
        password = (cls == InputType.TYPE_CLASS_TEXT && (v == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
            v == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD || v == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD)) ||
            (cls == InputType.TYPE_CLASS_NUMBER && v == InputType.TYPE_NUMBER_VARIATION_PASSWORD)
        fieldKind = if (cls == InputType.TYPE_CLASS_TEXT) {
            when (v) {
                InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS, InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS -> 1
                InputType.TYPE_TEXT_VARIATION_URI -> 2
                else -> 0
            }
        } else {
            0
        }
        noSuggest = password || fieldKind != 0 || cls != InputType.TYPE_CLASS_TEXT ||
            (t and InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS) != 0
        mode = if (numeric) M_NUM else if (phone) M_PHONE else M_LETTERS
    }

    private fun enterIconFor(i: EditorInfo?): Int {
        if (i == null) return KbIcons.ENTER
        if ((i.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0) return KbIcons.ENTER
        return when (i.imeOptions and EditorInfo.IME_MASK_ACTION) {
            EditorInfo.IME_ACTION_SEND -> KbIcons.SEND
            EditorInfo.IME_ACTION_SEARCH -> KbIcons.SEARCH
            EditorInfo.IME_ACTION_GO -> KbIcons.GO
            EditorInfo.IME_ACTION_NEXT, EditorInfo.IME_ACTION_PREVIOUS -> KbIcons.NEXT
            EditorInfo.IME_ACTION_DONE -> KbIcons.DONE
            else -> KbIcons.ENTER
        }
    }

    // ------------------------------------------------------------------ statistics

    private fun stat(p: IntP, n: Int = 1) {
        pending[p] = (pending[p] ?: 0) + n
        pendingCount++
        if (pendingCount >= 80) flushStats()
    }

    private fun flushStats() {
        if (pending.isEmpty()) return
        val ed = Store.sp.edit()
        for ((p, n) in pending) ed.putInt(p.key, Store.sp.getInt(p.key, 0) + n)
        ed.apply()
        pending.clear()
        pendingCount = 0
    }

    // ------------------------------------------------------------------ text helpers

    private fun markOwn() {
        ownEditAt = SystemClock.uptimeMillis()
    }

    private fun commit(s: String) {
        val ic = currentInputConnection ?: return
        markOwn()
        if ((info?.inputType ?: 0) == InputType.TYPE_NULL) {
            for (ch in s) sendKeyChar(ch)
        } else {
            ic.commitText(s, 1)
        }
    }

    private fun learnAllowed(): Boolean =
        P.LEARN.get() && !P.INCOGNITO.get() && !noSuggest && !password

    private fun req(w: String): Req = Req(
        w, prev, sentenceStart, langs, lang,
        P.AUTOCORRECT.get(), P.NEXTWORD.get(), P.EMOJI_PRED.get(), shift != 0
    )

    private fun isWordChar(ch: Char): Boolean {
        if (ch.isLetterOrDigit()) return true
        return (ch == '\'' || ch == '\u2019') && word.isNotEmpty() && word.last().isLetter()
    }

    private fun setShift(s: Int) {
        shift = s
        if (::root.isInitialized) root.kb.shift = s
    }

    private fun updateShift() {
        if (!::root.isInitialized) return
        if (shift == 1 || shift == 2) {
            root.kb.shift = shift
            return
        }
        val ic = currentInputConnection
        val i = info
        if (inlineSt != null || !P.AUTOCAP.get() || ic == null || i == null || mode != M_LETTERS || password ||
            (i.inputType and InputType.TYPE_MASK_CLASS) != InputType.TYPE_CLASS_TEXT
        ) {
            setShift(0)
            return
        }
        setShift(if (ic.getCursorCapsMode(i.inputType) != 0) 3 else 0)
    }

    private fun toggleShift() {
        val now = SystemClock.uptimeMillis()
        val s = when (shift) {
            0 -> 1
            1 -> if (now - lastShiftTap < 400L) 2 else 0
            else -> 0
        }
        lastShiftTap = now
        setShift(s)
    }

    /** Re-reads word / previous word / sentence start from the editor. */
    private fun refreshContext() {
        val ic = currentInputConnection ?: return
        val b = ic.getTextBeforeCursor(80, 0)?.toString() ?: ""
        val a = ic.getTextAfterCursor(1, 0)?.toString() ?: ""
        afterWord = a.isNotEmpty() && a[0].isLetterOrDigit()

        var i = b.length
        while (i > 0) {
            val ch = b[i - 1]
            val ok = ch.isLetterOrDigit() || ((ch == '\'' || ch == '\u2019') && i > 1 && b[i - 2].isLetter())
            if (!ok) break
            i--
        }
        var w = b.substring(i)
        var elided = ""
        if (Langs.get(lang).elision) {
            val k = w.indexOfFirst { it == '\'' || it == '\u2019' }
            if (k >= 0) {
                val last = w.indexOfLast { it == '\'' || it == '\u2019' }
                elided = w.substring(0, k)
                w = w.substring(last + 1)
                i += last + 1
            }
        }
        word = w

        var j = i
        var boundary = false
        while (j > 0 && !b[j - 1].isLetterOrDigit()) {
            val ch = b[j - 1]
            if (ch == '.' || ch == '!' || ch == '?' || ch == '\n' || ch == '\u00BF' || ch == '\u00A1') boundary = true
            j--
        }
        var sStart = boundary || j == 0
        if (j == 0 && b.length >= 80) sStart = false
        var k = j
        while (k > 0 && (b[k - 1].isLetterOrDigit() || b[k - 1] == '\'')) k--
        prev = if (sStart) "" else b.substring(k, j)
        if (elided.isNotEmpty() && w.isNotEmpty() && prev.isEmpty()) prev = ""
        sentenceStart = sStart && elided.isEmpty()
    }

    private fun afterTextChanged(refresh: Boolean) {
        if (refresh) refreshContext()
        updateShift()
        requestSuggestions()
    }

    // ------------------------------------------------------------------ suggestions

    private fun requestSuggestions() {
        val my = ++gen
        if (!::root.isInitialized || inlineSt != null) return
        if (noSuggest || !P.SUGGEST.get() || afterWord || word.any { it.isDigit() }) {
            showSuggestions(emptyList())
            return
        }
        val r = req(word)
        worker.execute {
            val res = try {
                predictor.suggest(r)
            } catch (e: Throwable) {
                null
            }
            ui.post {
                if (my == gen && res != null) showSuggestions(res.items)
            }
        }
    }

    private fun showSuggestions(list: List<Suggestion>) {
        if (!::root.isInitialized) return
        root.toolbar.setItems(list)
        updateClipChip()
    }

    override fun onSuggestion(s: Suggestion) {
        val ic = currentInputConnection ?: return
        lastFix = null
        when (s.kind) {
            Suggestion.ALT -> {
                replaceLastGlide(s.text)
                return
            }
            Suggestion.EMOJI -> {
                if (word.isNotEmpty()) {
                    commit(" ")
                    finishWord()
                }
                commit(s.text + " ")
                spaceAuto = true
            }
            Suggestion.LITERAL -> {
                val w = word
                if (w.isNotEmpty()) {
                    if (learnAllowed()) predictor.learn(prev, w, sentenceStart, 2)
                    predictor.block(w)
                    commit(" ")
                    finishWord()
                    spaceAuto = true
                }
            }
            else -> {
                val typed = word.length
                if (typed > 0) {
                    markOwn()
                    ic.deleteSurroundingText(typed, 0)
                }
                commit(s.text + " ")
                word = s.text
                stat(P.ST_PRED)
                stat(P.ST_SAVED, maxOf(0, s.text.length + 1 - typed))
                finishWord()
                spaceAuto = true
            }
        }
        lastWasSpace = false
        afterTextChanged(true)
    }

    private fun updateClipChip() {
        if (!::root.isInitialized) return
        val t = lastClipText
        val fresh = t != null && !clipUsed && !password && word.isEmpty() &&
            SystemClock.uptimeMillis() - lastClipAt < 20000L
        root.toolbar.clipText = if (fresh) t else null
    }

    override fun onPaste() {
        val t = lastClipText ?: return
        commit(t)
        clipUsed = true
        spaceAuto = false
        lastWasSpace = false
        afterTextChanged(true)
        updateClipChip()
    }

    private fun readClip(fresh: Boolean) {
        if (!P.CLIP_ON.get()) return
        try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = cm.primaryClip ?: return
            if (clip.itemCount == 0) return
            val t = clip.getItemAt(0).coerceToText(this).toString()
            if (t.isBlank()) return
            ClipStore.add(this, t)
            if (fresh && t != lastClipText) {
                lastClipText = t
                lastClipAt = SystemClock.uptimeMillis()
                clipUsed = false
                updateClipChip()
                ui.postDelayed({ updateClipChip() }, 20500L)
            }
        } catch (e: Exception) {
            // clipboard not readable right now
        }
    }

    // ------------------------------------------------------------------ keys

    override fun onPress(key: KeyDef) {
        sounds.play(key.type, true)
        haptics.tick()
    }

    override fun onRelease(key: KeyDef) {
        sounds.play(key.type, false)
        if (P.HAPTIC.get() >= 3) haptics.tick(true)
    }

    override fun onLongPressKey(key: KeyDef): Boolean {
        return when (key.type) {
            KType.EMOJI, KType.GLOBE -> {
                haptics.tick()
                showImePicker()
                true
            }
            KType.SPACE -> {
                haptics.tick()
                if (key.alts.isEmpty()) {
                    showImePicker()
                    true
                } else {
                    false
                }
            }
            else -> {
                haptics.tick()
                false
            }
        }
    }

    override fun onKey(key: KeyDef, text: String) {
        when (key.code) {
            Code.SHIFT -> toggleShift()
            Code.BACKSPACE -> backspace()
            Code.ENTER -> enter()
            Code.SPACE -> if (text.startsWith("lang:")) switchLang(text.substring(5)) else space()
            Code.SYMBOLS -> setMode(M_SYM1)
            Code.ABC -> setMode(M_LETTERS)
            Code.SYMBOLS2 -> setMode(M_SYM2)
            Code.EMOJI -> openEmoji()
            Code.GLOBE -> nextLang()
            else -> typeText(text)
        }
    }

    private fun typeText(t: String) {
        if (t.isEmpty()) return
        val inl = inlineSt
        if (inl != null) {
            inl.sb.append(t)
            onInlineChanged()
            return
        }
        if (t.length == 1) {
            if (isWordChar(t[0])) handleLetter(t) else handleSeparator(t)
        } else {
            lastFix = null
            lastGlide = null
            if (word.isNotEmpty()) finishWord()
            commit(t)
            spaceAuto = false
            lastWasSpace = false
            afterTextChanged(true)
        }
    }

    private fun handleLetter(t: String) {
        lastFix = null
        lastGlide = null
        commit(t)
        val ch = t[0]
        if ((ch == '\'' || ch == '\u2019') && Langs.get(lang).elision) {
            prev = ""
            word = ""
            sentenceStart = false
        } else {
            word += t
        }
        spaceAuto = false
        lastWasSpace = false
        stat(P.ST_CHARS)
        if (shift == 1 || shift == 3) setShift(0)
        afterTextChanged(false)
    }

    private fun handleSeparator(t: String) {
        val ic = currentInputConnection ?: return
        lastGlide = null
        if (word.isNotEmpty()) applyFix(t)
        var out = t
        if (spaceAuto && t.length == 1 && ".,;:!?)".indexOf(t[0]) >= 0) {
            markOwn()
            ic.deleteSurroundingText(1, 0)
            if (t != ")") out = "$t "
        }
        commit(out)
        finishWord()
        spaceAuto = false
        lastWasSpace = false
        stat(P.ST_CHARS)
        afterTextChanged(true)
    }

    private fun space() {
        val inl = inlineSt
        if (inl != null) {
            inl.sb.append(' ')
            onInlineChanged()
            return
        }
        val ic = currentInputConnection ?: return
        val now = SystemClock.uptimeMillis()
        lastGlide = null
        if (P.DBLSPACE.get() && lastWasSpace && now - lastSpaceAt < 600L && word.isEmpty() && !noSuggest) {
            val b = ic.getTextBeforeCursor(2, 0)?.toString() ?: ""
            if (b.length == 2 && b[1] == ' ' && b[0].isLetterOrDigit()) {
                markOwn()
                ic.deleteSurroundingText(1, 0)
                commit(". ")
                lastWasSpace = false
                spaceAuto = false
                lastFix = null
                afterTextChanged(true)
                return
            }
        }
        if (word.isNotEmpty()) applyFix(" ") else lastFix = null
        commit(" ")
        finishWord()
        lastWasSpace = true
        lastSpaceAt = now
        spaceAuto = false
        afterTextChanged(true)
    }

    /** Applies a text shortcut or an autocorrection to the word being typed. */
    private fun applyFix(sep: String): Boolean {
        lastFix = null
        if (noSuggest || password || afterWord) return false
        val ic = currentInputConnection ?: return false
        val w = word
        var repl: String? = shortcuts[w.lowercase()]
        if (repl == null) repl = predictor.autoFix(req(w))
        if (repl == null || repl == w) return false
        markOwn()
        ic.beginBatchEdit()
        ic.deleteSurroundingText(w.length, 0)
        commit(repl)
        ic.endBatchEdit()
        lastFix = Fix(w, repl, sep)
        word = repl
        stat(P.ST_CORR)
        return true
    }

    private fun finishWord() {
        val w = word
        if (w.isEmpty()) return
        if (learnAllowed()) predictor.learn(prev, w, sentenceStart, 1)
        stat(P.ST_WORDS)
        prev = w
        word = ""
        sentenceStart = false
    }

    override fun backspace() {
        val inl = inlineSt
        if (inl != null) {
            if (inl.sb.isNotEmpty()) inl.sb.deleteCharAt(inl.sb.length - 1)
            onInlineChanged()
            return
        }
        val ic = currentInputConnection ?: return
        val fix = lastFix
        if (fix != null) {
            // undo the autocorrection and keep the word exactly as typed
            lastFix = null
            markOwn()
            ic.beginBatchEdit()
            ic.deleteSurroundingText(fix.repl.length + fix.sep.length, 0)
            commit(fix.orig)
            ic.endBatchEdit()
            word = fix.orig
            predictor.block(fix.orig)
            if (learnAllowed()) predictor.learn(prev, fix.orig, sentenceStart, 2)
            spaceAuto = false
            lastWasSpace = false
            afterTextChanged(true)
            return
        }
        lastGlide = null
        val needRefresh = word.length <= 1
        markOwn()
        val sel = ic.getSelectedText(0)
        if (sel != null && sel.isNotEmpty()) {
            ic.commitText("", 1)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
        }
        if (word.isNotEmpty()) word = word.dropLast(1)
        spaceAuto = false
        lastWasSpace = false
        afterTextChanged(needRefresh)
    }

    override fun onBackspaceRepeat(n: Int) {
        if (n > 12) deleteWord() else backspace()
    }

    override fun onBackspaceSwipeStep() {
        lastFix = null
        deleteWord()
    }

    private fun deleteWord() {
        val ic = currentInputConnection ?: return
        val b = ic.getTextBeforeCursor(40, 0)?.toString() ?: return
        if (b.isEmpty()) return
        var i = b.length
        while (i > 0 && b[i - 1].isWhitespace()) i--
        while (i > 0 && !b[i - 1].isWhitespace()) i--
        val n = b.length - i
        if (n > 0) {
            markOwn()
            ic.deleteSurroundingText(n, 0)
        }
        word = ""
        spaceAuto = false
        lastWasSpace = false
        afterTextChanged(true)
    }

    private fun enter() {
        val inl = inlineSt
        if (inl != null) {
            onInlineSubmit()
            return
        }
        val ic = currentInputConnection ?: return
        if (word.isNotEmpty()) {
            applyFix("\n")
            finishWord()
        }
        lastFix = null
        lastGlide = null
        val opts = info?.imeOptions ?: 0
        val action = opts and EditorInfo.IME_MASK_ACTION
        val noEnter = (opts and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        markOwn()
        if (!noEnter && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            ic.performEditorAction(action)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        }
        spaceAuto = false
        lastWasSpace = false
        afterTextChanged(true)
    }

    override fun onSpaceSwipe(steps: Int) {
        // no markOwn(): the resulting selection change resyncs the word context
        sendDownUpKeyEvents(if (steps > 0) KeyEvent.KEYCODE_DPAD_RIGHT else KeyEvent.KEYCODE_DPAD_LEFT)
        haptics.tick(true)
        lastFix = null
        lastGlide = null
        spaceAuto = false
        lastWasSpace = false
    }

    // ------------------------------------------------------------------ swipe typing

    override fun onGlideEnd(xs: FloatArray, ys: FloatArray, n: Int) {
        if (!::root.isInitialized || password || inlineSt != null) return
        val gk = root.kb.glideKeys() ?: return
        val px = xs.copyOf(n)
        val py = ys.copyOf(n)
        val ctxWord = if (word.isNotEmpty()) word else prev
        val ls = langs
        val la = lang
        worker.execute {
            val res = try {
                predictor.glide(px, py, n, gk, ls, la, ctxWord)
            } catch (e: Throwable) {
                emptyList()
            }
            ui.post { if (res.isNotEmpty()) commitGlide(res) }
        }
    }

    private fun commitGlide(res: List<String>) {
        val ic = currentInputConnection ?: return
        if (word.isNotEmpty()) {
            commit(" ")
            finishWord()
        } else if (!spaceAuto && !lastWasSpace) {
            val b = ic.getTextBeforeCursor(1, 0)?.toString() ?: ""
            if (b.isNotEmpty() && b[0].isLetterOrDigit()) commit(" ")
        }
        var w = res[0]
        if (shift == 2) w = w.uppercase()
        else if (shift != 0 && w.isNotEmpty()) w = w.replaceFirstChar { it.uppercaseChar() }
        commit("$w ")
        word = w
        finishWord()
        stat(P.ST_GLIDE)
        spaceAuto = true
        lastWasSpace = false
        lastFix = null
        lastGlide = GlideInfo(w)
        if (shift == 1 || shift == 3) setShift(0)
        refreshContext()
        updateShift()
        val alts = ArrayList<Suggestion>()
        alts.add(Suggestion(w, Suggestion.ALT))
        for (i in 1 until minOf(res.size, 3)) alts.add(Suggestion(res[i], Suggestion.ALT))
        gen++
        showSuggestions(alts)
    }

    private fun replaceLastGlide(text: String) {
        val ic = currentInputConnection ?: return
        val g = lastGlide ?: return
        markOwn()
        ic.deleteSurroundingText(g.word.length + 1, 0)
        commit("$text ")
        g.word = text
        if (learnAllowed()) predictor.learn(prev, text, false, 1)
    }

    // ------------------------------------------------------------------ languages

    private fun switchLang(id: String) {
        if (!langs.contains(id)) return
        lang = id
        P.ACTIVE.set(id)
        loadLayout()
        requestSuggestions()
    }

    private fun nextLang() {
        if (langs.size > 1) {
            val i = langs.indexOf(lang)
            switchLang(langs[(i + 1) % langs.size])
        } else {
            showImePicker()
        }
    }

    private fun showImePicker() {
        try {
            (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        } catch (e: Exception) {
            // ignore
        }
    }

    // ------------------------------------------------------------------ toolbar

    override fun onToggleTools() {
        val tb = root.toolbar
        tb.mode = if (tb.mode == ToolbarView.M_TOOLS) ToolbarView.M_SUGGEST else ToolbarView.M_TOOLS
    }

    override fun onTool(id: String) {
        when (id) {
            "clipboard" -> showPanel(ClipPanel(this, this))
            "emoji" -> openEmoji()
            "gif" -> showPanel(GifPanel(this, this, false))
            "sticker" -> showPanel(GifPanel(this, this, true))
            "translate" -> showPanel(ToolsPanel(this, this, false))
            "ai" -> showPanel(ToolsPanel(this, this, true))
            "search" -> {
                root.toolbar.mode = ToolbarView.M_SUGGEST
                openInline(Tx.t("Cerca sul web", "Search the web"), null) { q -> webSearch(q) }
            }
            "voice" -> {
                root.toolbar.mode = ToolbarView.M_SUGGEST
                onMic()
            }
            "onehand" -> {
                val next = when (P.ONE_HAND.get()) {
                    "off" -> "left"
                    "left" -> "right"
                    else -> "off"
                }
                P.ONE_HAND.set(next)
            }
            "resize" -> cycleSize()
            "incognito" -> {
                val on = !P.INCOGNITO.get()
                P.INCOGNITO.set(on)
                toast(if (on) Tx.t("Incognito attivo: niente apprendimento", "Incognito on: nothing is learned")
                else Tx.t("Incognito disattivato", "Incognito off"))
            }
            "theme" -> cycleTheme()
            "settings" -> openSettings()
        }
    }

    private fun cycleSize() {
        val steps = floatArrayOf(0.85f, 1.0f, 1.15f, 1.3f)
        val cur = P.SIZE.get()
        var idx = 0
        var bd = 9f
        for (i in steps.indices) {
            val d = Math.abs(steps[i] - cur)
            if (d < bd) {
                bd = d
                idx = i
            }
        }
        val n = steps[(idx + 1) % steps.size]
        P.SIZE.set(n)
        toast(Tx.t("Altezza ", "Height ") + (n * 100).toInt() + "%")
    }

    private fun cycleTheme() {
        val ids = Themes.PRESETS.map { it.id }
        val cur = ids.indexOf(P.THEME.get())
        val next = ids[(cur + 1) % ids.size]
        P.THEME.set(next)
        toast(Themes.PRESETS.first { it.id == next }.name)
    }

    private fun webSearch(q: String) {
        if (q.isBlank()) return
        val url = "https://duckduckgo.com/?q=" + URLEncoder.encode(q, "UTF-8")
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            requestHideSelf(0)
        } catch (e: Exception) {
            toast(Tx.t("Nessun browser trovato", "No browser found"))
        }
    }

    private fun showPanel(v: View) {
        panel = v
        root.setPanel(v)
        root.toolbar.mode = ToolbarView.M_SUGGEST
    }

    private fun openEmoji() {
        showPanel(EmojiPanel(this, this))
    }

    // ------------------------------------------------------------------ inlineSt input (search fields)

    private fun onInlineChanged() {
        val inl = inlineSt ?: return
        val q = inl.sb.toString()
        root.toolbar.inlineText = q
        val live = inl.live
        if (live != null) {
            root.toolbar.inlineResults = try {
                live(q)
            } catch (e: Exception) {
                emptyList()
            }
        }
    }

    override fun onInlineBack() {
        closeInline(false)
    }

    override fun onInlineSubmit() {
        closeInline(true)
    }

    override fun onInlineResult(i: Int) {
        val r = root.toolbar.inlineResults.getOrNull(i) ?: return
        insert(r)
        EmojiData.addRecent(r)
    }

    private fun closeInline(submit: Boolean) {
        val inl = inlineSt ?: return
        inlineSt = null
        val q = inl.sb.toString()
        root.toolbar.inlineResults = emptyList()
        root.toolbar.inlineText = ""
        root.toolbar.mode = ToolbarView.M_SUGGEST
        val sp = savedPanel
        savedPanel = null
        if (sp != null) {
            panel = sp
            root.setPanel(sp)
        }
        if (modeBeforeInline >= 0) {
            mode = modeBeforeInline
            modeBeforeInline = -1
            loadLayout()
        }
        if (submit) inl.submit(q)
        requestSuggestions()
    }

    // ------------------------------------------------------------------ Host (panels)

    override fun insert(text: String) {
        commit(text)
        lastFix = null
        spaceAuto = false
        lastWasSpace = false
        afterTextChanged(true)
    }

    override fun closePanel() {
        panel = null
        if (::root.isInitialized) root.setPanel(null)
    }

    override fun fieldText(): String {
        val ic = currentInputConnection ?: return ""
        val sel = ic.getSelectedText(0)
        if (sel != null && sel.isNotEmpty()) return sel.toString()
        val b = ic.getTextBeforeCursor(2000, 0)?.toString() ?: ""
        val a = ic.getTextAfterCursor(2000, 0)?.toString() ?: ""
        return b + a
    }

    override fun replaceField(text: String) {
        val ic = currentInputConnection ?: return
        markOwn()
        ic.beginBatchEdit()
        val sel = ic.getSelectedText(0)
        if (sel == null || sel.isEmpty()) {
            val b = ic.getTextBeforeCursor(5000, 0)?.length ?: 0
            val a = ic.getTextAfterCursor(5000, 0)?.length ?: 0
            ic.deleteSurroundingText(b, a)
        }
        ic.commitText(text, 1)
        ic.endBatchEdit()
        word = ""
        spaceAuto = false
        lastWasSpace = false
        afterTextChanged(true)
    }

    override fun openInline(hint: String, live: ((String) -> List<String>)?, onSubmit: (String) -> Unit) {
        savedPanel = panel
        panel = null
        root.setPanel(null)
        inlineSt = Inline(live, onSubmit)
        if (mode != M_LETTERS) {
            modeBeforeInline = mode
            mode = M_LETTERS
            loadLayout()
        }
        val tb = root.toolbar
        tb.inlineHint = hint
        tb.inlineText = ""
        tb.inlineResults = emptyList()
        tb.mode = ToolbarView.M_INLINE
        setShift(0)
    }

    override fun commitGif(url: String) {
        Net.async({
            val data = Net.bytes(url, 8_000_000)
            val dir = File(cacheDir, "gif")
            dir.mkdirs()
            val f = File(dir, "g" + Integer.toHexString(url.hashCode()) + ".gif")
            f.writeBytes(data)
            f
        }, { f -> sendGif(f, url) }, { insert("$url ") })
    }

    private fun sendGif(f: File, url: String) {
        val ic = currentInputConnection
        val ei = info
        if (ic == null || ei == null) return
        val supported = EditorInfoCompat.getContentMimeTypes(ei).any { ClipDescription.compareMimeTypes("image/gif", it) }
        if (!supported) {
            insert("$url ")
            return
        }
        try {
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
            val desc = ClipDescription("GIF", arrayOf("image/gif"))
            val ci = InputContentInfoCompat(uri, desc, Uri.parse(url))
            var flags = 0
            if (Build.VERSION.SDK_INT >= 25) flags = flags or InputConnectionCompat.INPUT_CONTENT_GRANT_READ_URI_PERMISSION
            val ok = InputConnectionCompat.commitContent(ic, ei, ci, flags, null)
            if (!ok) insert("$url ")
        } catch (e: Exception) {
            insert("$url ")
        }
    }

    override fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    override fun openSettings() {
        try {
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            requestHideSelf(0)
        } catch (e: Exception) {
            // ignore
        }
    }

    override fun kbTheme(): KbTheme {
        val t = curTheme
        if (t != null) return t
        val n = Themes.build(this)
        curTheme = n
        return n
    }

    override fun panelWidth(): Int = if (::root.isInitialized) root.kb.width else 0

    // ------------------------------------------------------------------ voice typing

    private fun localeTag(id: String): String = when (id) {
        "it" -> "it-IT"
        "en" -> "en-US"
        "es" -> "es-ES"
        "fr" -> "fr-FR"
        "de" -> "de-DE"
        "pt" -> "pt-PT"
        else -> id
    }

    override fun onMic() {
        if (voice != null) {
            stopVoice()
            return
        }
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            toast(Tx.t("Concedi il permesso del microfono a Creamy Keyboard", "Grant the microphone permission to Creamy Keyboard"))
            try {
                startActivity(
                    Intent(this, MainActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        .putExtra("ask_mic", true)
                )
                requestHideSelf(0)
            } catch (e: Exception) {
                // ignore
            }
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            toast(Tx.t("Riconoscimento vocale non disponibile", "Speech recognition not available"))
            return
        }
        val sr = SpeechRecognizer.createSpeechRecognizer(this)
        voice = sr
        sr.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}

            override fun onError(error: Int) {
                stopVoice()
            }

            override fun onResults(results: Bundle?) {
                val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                stopVoice()
                if (!t.isNullOrBlank()) insertDictation(t)
            }

            override fun onPartialResults(partialResults: Bundle?) {
                val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (t != null && ::root.isInitialized) root.toolbar.voiceText = t
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, localeTag(lang))
        root.toolbar.voiceText = ""
        root.toolbar.mode = ToolbarView.M_VOICE
        sr.startListening(i)
    }

    private fun stopVoice() {
        val v = voice ?: return
        voice = null
        try {
            v.destroy()
        } catch (e: Exception) {
            // ignore
        }
        if (::root.isInitialized && root.toolbar.mode == ToolbarView.M_VOICE) root.toolbar.mode = ToolbarView.M_SUGGEST
    }

    private fun insertDictation(t: String) {
        if (word.isNotEmpty()) finishWord()
        var text = t.trim()
        if (shift != 0 && text.isNotEmpty()) text = text.replaceFirstChar { it.uppercaseChar() }
        commit("$text ")
        if (shift == 1 || shift == 3) setShift(0)
        spaceAuto = true
        lastWasSpace = false
        afterTextChanged(true)
    }
}

package dev.creamy.keyboard

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.text.Html
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.ByteBuffer
import java.util.Locale
import java.util.concurrent.Executors

object Net {
    private val io = Executors.newFixedThreadPool(4)
    private val main = Handler(Looper.getMainLooper())

    /** Runs [work] on a background thread and delivers the result on the main thread. */
    fun <T> async(work: () -> T, ok: (T) -> Unit, err: (String) -> Unit) {
        io.execute {
            try {
                val r = work()
                main.post { ok(r) }
            } catch (e: Exception) {
                val m = e.message ?: e.javaClass.simpleName
                main.post { err(m) }
            }
        }
    }

    fun get(url: String, headers: Map<String, String> = emptyMap()): String = request("GET", url, null, headers)

    fun post(url: String, body: String, headers: Map<String, String>): String = request("POST", url, body, headers)

    private fun request(method: String, url: String, body: String?, headers: Map<String, String>): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = method
            c.connectTimeout = 10000
            c.readTimeout = 30000
            for ((k, v) in headers) c.setRequestProperty(k, v)
            if (body != null) {
                c.doOutput = true
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) throw RuntimeException("HTTP $code: ${text.take(160)}")
            return text
        } finally {
            c.disconnect()
        }
    }

    fun bytes(url: String, max: Int = 6_000_000): ByteArray {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 10000
            c.readTimeout = 30000
            if (c.responseCode !in 200..299) throw RuntimeException("HTTP ${c.responseCode}")
            val out = ByteArrayOutputStream()
            val buf = ByteArray(16384)
            c.inputStream.use { ins ->
                while (true) {
                    val n = ins.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    if (out.size() > max) throw RuntimeException("file too large")
                }
            }
            return out.toByteArray()
        } finally {
            c.disconnect()
        }
    }

    /** First frame of a (possibly animated) image. */
    fun decode(data: ByteArray): Bitmap? {
        return try {
            if (Build.VERSION.SDK_INT >= 28) {
                ImageDecoder.decodeBitmap(ImageDecoder.createSource(ByteBuffer.wrap(data)))
            } else {
                BitmapFactory.decodeByteArray(data, 0, data.size)
            }
        } catch (e: Throwable) {
            null
        }
    }
}

class Gif(val thumb: String, val full: String, val w: Int, val h: Int)

object Giphy {
    fun fetch(query: String?, sticker: Boolean, ok: (List<Gif>) -> Unit, err: (String) -> Unit) {
        val key = P.GIPHY.get().trim()
        if (key.isEmpty()) {
            err("no_key")
            return
        }
        val kind = if (sticker) "stickers" else "gifs"
        val url = if (query.isNullOrBlank()) {
            "https://api.giphy.com/v1/$kind/trending?api_key=$key&limit=30&rating=pg-13"
        } else {
            "https://api.giphy.com/v1/$kind/search?api_key=$key&q=${URLEncoder.encode(query, "UTF-8")}" +
                "&limit=30&rating=pg-13&lang=${Locale.getDefault().language}"
        }
        Net.async({ parse(Net.get(url)) }, ok, err)
    }

    private fun parse(s: String): List<Gif> {
        val arr = JSONObject(s).getJSONArray("data")
        val out = ArrayList<Gif>()
        for (i in 0 until arr.length()) {
            val im = arr.getJSONObject(i).getJSONObject("images")
            val th = im.optJSONObject("fixed_height_small") ?: im.optJSONObject("fixed_height") ?: continue
            val full = im.optJSONObject("downsized") ?: im.optJSONObject("original") ?: th
            out.add(
                Gif(
                    th.getString("url"), full.getString("url"),
                    th.optString("width", "100").toIntOrNull() ?: 100,
                    th.optString("height", "100").toIntOrNull() ?: 100
                )
            )
        }
        return out
    }
}

object Translator {
    val LANGS = listOf("it", "en", "es", "fr", "de", "pt", "nl", "ru", "ja", "zh-CN", "ko", "ar", "tr", "pl", "sv")

    private fun chunks(text: String, max: Int): List<String> {
        val out = ArrayList<String>()
        val cur = StringBuilder()
        for (piece in text.split(Regex("(?<=[.!?\n])\\s*"))) {
            if (piece.isEmpty()) continue
            if (cur.length + piece.length > max && cur.isNotEmpty()) {
                out.add(cur.toString())
                cur.setLength(0)
            }
            if (piece.length > max) {
                var s = 0
                while (s < piece.length) {
                    out.add(piece.substring(s, minOf(piece.length, s + max)))
                    s += max
                }
            } else {
                cur.append(piece).append(' ')
            }
        }
        if (cur.isNotEmpty()) out.add(cur.toString().trim())
        return out
    }

    /** Free MyMemory translation API (no key needed). */
    fun translate(text: String, from: String, to: String, ok: (String) -> Unit, err: (String) -> Unit) {
        Net.async({
            val sb = StringBuilder()
            for (part in chunks(text, 450)) {
                val url = "https://api.mymemory.translated.net/get?q=${URLEncoder.encode(part, "UTF-8")}" +
                    "&langpair=${URLEncoder.encode("$from|$to", "UTF-8")}"
                val j = JSONObject(Net.get(url))
                val t = j.getJSONObject("responseData").getString("translatedText")
                if (sb.isNotEmpty()) sb.append(' ')
                sb.append(Html.fromHtml(t, Html.FROM_HTML_MODE_LEGACY).toString())
            }
            sb.toString()
        }, ok, err)
    }
}

/** Optional AI helper (rewrite / tone / compose). Needs the user's own API key. */
object Ai {
    fun run(system: String, text: String, ok: (String) -> Unit, err: (String) -> Unit) {
        val key = P.AI_KEY.get().trim()
        if (key.isEmpty()) {
            err("no_key")
            return
        }
        Net.async({
            if (P.AI_PROVIDER.get() == "anthropic") {
                val body = JSONObject()
                    .put("model", P.AI_MODEL.get())
                    .put("max_tokens", 1024)
                    .put("system", system)
                    .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", text)))
                    .toString()
                val r = JSONObject(
                    Net.post(
                        "https://api.anthropic.com/v1/messages", body,
                        mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01", "content-type" to "application/json")
                    )
                )
                r.getJSONArray("content").getJSONObject(0).getString("text").trim()
            } else {
                val base = P.AI_URL.get().ifBlank { "https://api.openai.com/v1" }.trimEnd('/')
                val msgs = JSONArray()
                    .put(JSONObject().put("role", "system").put("content", system))
                    .put(JSONObject().put("role", "user").put("content", text))
                val body = JSONObject().put("model", P.AI_MODEL.get()).put("messages", msgs).toString()
                val r = JSONObject(
                    Net.post(
                        "$base/chat/completions", body,
                        mapOf("Authorization" to "Bearer $key", "content-type" to "application/json")
                    )
                )
                r.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content").trim()
            }
        }, ok, err)
    }
}

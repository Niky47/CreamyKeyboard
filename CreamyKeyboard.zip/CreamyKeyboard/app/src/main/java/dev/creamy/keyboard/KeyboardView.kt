package dev.creamy.keyboard

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Build
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import androidx.core.graphics.ColorUtils
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

class KeyRect(val def: KeyDef, val r: RectF, val hit: RectF) {
    val spring = Spring(0f, 0f, 700f, 0.5f)
}

/**
 * The key area. Everything is drawn by hand: Material 3 Expressive keys that squish with a spring,
 * cookie-shaped key previews, long-press accent popups, swipe typing and space-bar cursor control.
 */
class KeyboardView(ctx: Context) : View(ctx) {

    interface Listener {
        fun onPress(key: KeyDef)
        fun onRelease(key: KeyDef)
        fun onKey(key: KeyDef, text: String)
        fun onBackspaceRepeat(n: Int)
        fun onBackspaceSwipeStep()
        fun onSpaceSwipe(steps: Int)
        fun onGlideEnd(xs: FloatArray, ys: FloatArray, n: Int)
        fun onLongPressKey(key: KeyDef): Boolean
    }

    var listener: Listener? = null
    var theme: KbTheme? = null
    var kbLayout: KbLayout? = null
    var shift = 0
        set(v) {
            field = v
            invalidate()
        }
    var enterIcon = KbIcons.ENTER
        set(v) {
            field = v
            invalidate()
        }
    var spaceLabel = ""
        set(v) {
            field = v
            invalidate()
        }
    var glideOn = true
    var previewOn = true
    var hintsOn = true
    var trailOn = true
    var spaceCursorOn = true
    var backSwipeOn = true
    var longPressMs = 350L
    var onOverlay: (() -> Unit)? = null

    companion object {
        private const val M_TAP = 0
        private const val M_POPUP = 1
        private const val M_GLIDE = 2
        private const val M_SPACE = 3
        private const val M_BACK = 4
        private const val M_REPEAT = 5
        private const val M_DONE = 6
        private const val TOP_PAD = 4f
        private const val BOT_PAD = 6f
        private const val SIDE_PAD = 4f
    }

    private class Ptr {
        var key: KeyRect? = null
        var mode = M_TAP
        var dx = 0f
        var dy = 0f
        var lx = 0f
        var ly = 0f
        var lp: Runnable? = null
        var rep: Runnable? = null
        var repN = 0
        var accum = 0f
        var bubble: Bubble? = null
        var gx = FloatArray(0)
        var gy = FloatArray(0)
        var gn = 0
    }

    private class Bubble(val k: KeyRect) {
        val sp = Spring(0f, 1f, 800f, 0.55f)
        var closing = false
    }

    private class Popup(
        val key: KeyRect, val items: List<String>, val outs: List<String>, val rects: List<RectF>,
        val bounds: RectF, val rows: Int, val ptr: Ptr, val type: KType
    ) {
        var sel = 0
    }

    private class TrailPt(val x: Float, val y: Float, val t: Long)

    private val density = ctx.resources.displayMetrics.density
    private fun dp(v: Float): Float = v * density

    private val keys = ArrayList<KeyRect>()
    private val ptrs = arrayOfNulls<Ptr>(16)
    private val bubbles = ArrayList<Bubble>()
    private val trail = ArrayList<TrailPt>()
    private var popup: Popup? = null
    private var shiftHeld = false
    private var typedDuringShift = false
    private var animating = false
    private var lastFrame = 0L

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val path = Path()

    private val tfBold: Typeface = if (Build.VERSION.SDK_INT >= 28) {
        Typeface.create(Typeface.create("sans-serif-rounded", Typeface.NORMAL), 650, false)
    } else {
        Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
    private val tfReg: Typeface = if (Build.VERSION.SDK_INT >= 28) {
        Typeface.create(Typeface.create("sans-serif-rounded", Typeface.NORMAL), 450, false)
    } else {
        Typeface.DEFAULT
    }

    init {
        txt.textAlign = Paint.Align.CENTER
    }

    // ---------------------------------------------------------------- layout

    /** Call after changing [theme] or [kbLayout]. */
    fun refresh() {
        cancelAll()
        requestLayout()
        relayout()
        invalidate()
    }

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        val th = theme
        val rows = kbLayout?.rows?.size ?: 4
        val kh = dp(th?.keyH ?: 54f)
        val rg = dp(th?.rowGap ?: 6f)
        val h = (rows * kh + (rows - 1) * rg + dp(TOP_PAD) + dp(BOT_PAD)).toInt()
        setMeasuredDimension(MeasureSpec.getSize(wSpec), h)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        relayout()
    }

    private fun relayout() {
        keys.clear()
        val lay = kbLayout ?: return
        val th = theme ?: return
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val gap = dp(th.keyGap)
        val rgap = dp(th.rowGap)
        val padX = dp(SIDE_PAD)
        val n = lay.rows.size
        val rowH = (h - dp(TOP_PAD) - dp(BOT_PAD) - rgap * (n - 1)) / n
        var y = dp(TOP_PAD)
        for (row in lay.rows) {
            var total = 0f
            for (k in row) total += k.weight
            val availW = w - 2 * padX - gap * (row.size - 1)
            var x = padX
            for (k in row) {
                val kw = availW * k.weight / total
                if (k.type != KType.SPACER) {
                    val r = RectF(x, y, x + kw, y + rowH)
                    val hit = RectF(x - gap / 2f, y - rgap / 2f, x + kw + gap / 2f, y + rowH + rgap / 2f)
                    keys.add(KeyRect(k, r, hit))
                }
                x += kw + gap
            }
            y += rowH + rgap
        }
    }

    /** Letter key centres, used by the swipe-typing decoder. */
    fun glideKeys(): GlideKeys? {
        val cs = ArrayList<Char>()
        val xs = ArrayList<Float>()
        val ys = ArrayList<Float>()
        var wsum = 0f
        for (k in keys) {
            val l = k.def.label
            if (k.def.type == KType.LETTER && l.length == 1 && l[0] in 'a'..'z') {
                cs.add(l[0])
                xs.add(k.r.centerX())
                ys.add(k.r.centerY())
                wsum += k.r.width()
            }
        }
        if (cs.isEmpty()) return null
        return GlideKeys(cs.toCharArray(), xs.toFloatArray(), ys.toFloatArray(), wsum / cs.size)
    }

    // ---------------------------------------------------------------- drawing

    private val effShift: Boolean get() = shift != 0 || shiftHeld

    override fun onDraw(c: Canvas) {
        val th = theme ?: return
        for (k in keys) drawKey(c, th, k)
    }

    private fun drawKey(c: Canvas, th: KbTheme, k: KeyRect) {
        val def = k.def
        val p = k.spring.value
        val pc = p.coerceIn(0f, 1f)
        val r = k.r
        val cx = r.centerX()
        val cy = r.centerY()
        val w = r.width()
        val h = r.height()

        var fill: Int
        var tc: Int
        val shiftOn = def.type == KType.SHIFT && effShift
        when (def.type) {
            KType.ENTER -> {
                fill = th.accent
                tc = th.accentText
            }
            KType.SHIFT -> {
                if (shift == 2) {
                    fill = th.accent
                    tc = th.accentText
                } else if (shiftOn) {
                    fill = th.pressFill
                    tc = th.pressText
                } else {
                    fill = th.func
                    tc = th.funcText
                }
            }
            KType.BACKSPACE, KType.MODE, KType.EMOJI, KType.GLOBE -> {
                fill = th.func
                tc = th.funcText
            }
            else -> {
                fill = th.key
                tc = th.keyText
            }
        }
        if (def.type != KType.ENTER && !shiftOn && pc > 0f) {
            fill = ColorUtils.blendARGB(fill, th.pressFill, pc)
            tc = ColorUtils.blendARGB(tc, th.pressText, pc)
        }

        var sc = 1f
        var dy = 0f
        when (th.press) {
            "jelly" -> sc = 1f - 0.10f * p
            "scale" -> sc = 1f - 0.07f * pc
            "sink" -> {
                sc = 1f - 0.03f * pc
                dy = dp(2f) * pc
            }
        }
        val ww = w * sc
        val hh = h * sc

        paint.style = Paint.Style.FILL
        paint.color = fill
        if (def.type == KType.ENTER) {
            val radii = Shapes.resolve(th.enterShape, th.waves, th.amp)
            val maxW = min(w, h * 1.5f)
            if (radii != null) {
                Shapes.fill(path, radii, cx, cy + dy, maxW / 2f * sc, h / 2f * sc, p * 0.26f)
                c.drawPath(path, paint)
            } else {
                rect.set(cx - maxW / 2f * sc, cy - h / 2f * sc + dy, cx + maxW / 2f * sc, cy + h / 2f * sc + dy)
                val er = when (th.enterShape) {
                    "pill" -> rect.height() / 2f
                    "square" -> dp(4f)
                    else -> dp(th.radius)
                }
                c.drawRoundRect(rect, er, er, paint)
            }
        } else {
            val restR = if (def.type == KType.LETTER || def.type == KType.SYMBOL) {
                dp(th.radius)
            } else {
                when (th.funcShape) {
                    "pill" -> min(w, h) / 2f
                    "square" -> dp(4f)
                    else -> dp(th.radius)
                }
            }
            val pressR = if (th.press == "jelly") max(restR, min(w, h) * 0.5f) else restR
            val rad = min(restR + (pressR - restR) * p.coerceIn(0f, 1.15f), min(ww, hh) / 2f)
            rect.set(cx - ww / 2f, cy - hh / 2f + dy, cx + ww / 2f, cy + hh / 2f + dy)
            c.drawRoundRect(rect, rad, rad, paint)
            if (th.borders) {
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = dp(1f)
                paint.color = ColorUtils.setAlphaComponent(th.outline, 120)
                c.drawRoundRect(rect, rad, rad, paint)
                paint.style = Paint.Style.FILL
            }
        }

        val icon = when (def.type) {
            KType.SHIFT -> if (shift == 2) KbIcons.CAPS else if (shiftOn) KbIcons.SHIFT_ON else KbIcons.SHIFT
            KType.BACKSPACE -> KbIcons.BACKSPACE
            KType.ENTER -> enterIcon
            KType.EMOJI -> KbIcons.EMOJI
            KType.GLOBE -> KbIcons.GLOBE
            else -> 0
        }
        if (icon != 0) {
            KbIcons.draw(c, icon, cx, cy + dy, min(h, dp(54f)) * 0.44f * sc, tc)
            return
        }

        val label: String
        var size: Float
        when (def.type) {
            KType.SPACE -> {
                label = spaceLabel
                size = h * 0.26f
                tc = ColorUtils.setAlphaComponent(tc, 150)
            }
            KType.MODE -> {
                label = def.label
                size = h * 0.30f
            }
            KType.LETTER -> {
                label = if (effShift) def.label.uppercase() else def.label
                size = h * 0.40f
            }
            else -> {
                label = def.label
                size = h * 0.38f
            }
        }
        if (label.isEmpty()) return
        txt.typeface = if (th.bold) tfBold else tfReg
        txt.textSize = size * th.labelScale * sc
        txt.color = tc
        txt.textAlign = Paint.Align.CENTER
        val fm = txt.fontMetrics
        c.drawText(label, cx, cy + dy - (fm.ascent + fm.descent) / 2f, txt)

        val hint = def.hint
        if (hintsOn && hint != null && def.type == KType.LETTER) {
            txt.textSize = h * 0.22f
            txt.color = th.hint
            c.drawText(hint, r.right - dp(8f), r.top + h * 0.28f, txt)
        }
    }

    /** Previews, accent popups and the swipe trail: drawn by [OverlayView] above the whole keyboard. */
    fun drawOverlay(c: Canvas, ox: Float, oy: Float) {
        val th = theme ?: return
        c.save()
        c.translate(ox, oy)

        if (trail.size >= 2) {
            val now = SystemClock.uptimeMillis()
            paint.style = Paint.Style.STROKE
            paint.strokeCap = Paint.Cap.ROUND
            for (i in 1 until trail.size) {
                val a = trail[i]
                val b = trail[i - 1]
                val age = (now - a.t) / 450f
                if (age >= 1f) continue
                paint.color = ColorUtils.setAlphaComponent(th.trail, (255 * (1f - age) * 0.85f).toInt())
                paint.strokeWidth = dp(7f) * (1f - age * 0.6f)
                c.drawLine(b.x, b.y, a.x, a.y, paint)
            }
            paint.style = Paint.Style.FILL
        }

        for (b in bubbles) {
            val k = b.k
            val v = b.sp.value
            if (v < 0.02f) continue
            val sz = max(k.r.width() * 1.35f, dp(60f))
            val cx = k.r.centerX().coerceIn(sz / 2f + dp(2f), max(sz / 2f + dp(2f), width - sz / 2f - dp(2f)))
            val cy = k.r.top - sz * 0.52f
            val radii = Shapes.wavy(th.waves, th.amp * 1.4f)
            paint.style = Paint.Style.FILL
            paint.color = th.pressFill
            Shapes.fill(path, radii, cx, cy, sz / 2f * v, sz / 2f * v, (1f - v) * 0.6f)
            c.drawPath(path, paint)
            val l = k.def.label
            val label = if (effShift && k.def.type == KType.LETTER) l.uppercase() else l
            txt.typeface = tfBold
            txt.textSize = sz * 0.5f * v
            txt.color = th.pressText
            txt.textAlign = Paint.Align.CENTER
            val fm = txt.fontMetrics
            c.drawText(label, cx, cy - (fm.ascent + fm.descent) / 2f, txt)
        }

        val pp = popup
        if (pp != null) {
            rect.set(pp.bounds)
            rect.inset(-dp(5f), -dp(5f))
            paint.style = Paint.Style.FILL
            paint.color = th.panel
            c.drawRoundRect(rect, dp(22f), dp(22f), paint)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = dp(1f)
            paint.color = ColorUtils.setAlphaComponent(th.outline, 110)
            c.drawRoundRect(rect, dp(22f), dp(22f), paint)
            paint.style = Paint.Style.FILL
            for (i in pp.items.indices) {
                val ir = pp.rects[i]
                val sel = i == pp.sel
                if (sel) {
                    paint.color = th.accent
                    rect.set(ir)
                    rect.inset(dp(1.5f), dp(1.5f))
                    c.drawRoundRect(rect, dp(17f), dp(17f), paint)
                }
                txt.typeface = tfBold
                txt.textSize = min(ir.height() * 0.46f, dp(23f))
                txt.color = if (sel) th.accentText else th.keyText
                txt.textAlign = Paint.Align.CENTER
                val fm = txt.fontMetrics
                c.drawText(pp.items[i], ir.centerX(), ir.centerY() - (fm.ascent + fm.descent) / 2f, txt)
            }
        }
        c.restore()
    }

    // ---------------------------------------------------------------- animation

    private val frame = object : Runnable {
        override fun run() {
            val now = SystemClock.uptimeMillis()
            val dt = ((now - lastFrame) / 1000f).coerceIn(0f, 0.05f)
            lastFrame = now
            var busy = false
            for (k in keys) {
                if (!k.spring.settled()) {
                    k.spring.step(dt)
                    busy = true
                }
            }
            val iter = bubbles.iterator()
            while (iter.hasNext()) {
                val b = iter.next()
                if (!b.sp.settled()) {
                    b.sp.step(dt)
                    busy = true
                }
                if (b.closing && b.sp.value < 0.03f) iter.remove()
            }
            if (trail.isNotEmpty()) {
                trail.removeAll { now - it.t > 450 }
                if (trail.isNotEmpty()) busy = true
            }
            invalidate()
            onOverlay?.invoke()
            if (busy) postOnAnimation(this) else animating = false
        }
    }

    private fun kick() {
        if (!animating) {
            animating = true
            lastFrame = SystemClock.uptimeMillis()
            postOnAnimation(frame)
        }
    }

    // ---------------------------------------------------------------- touch

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                val i = e.actionIndex
                down(e.getPointerId(i), e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until e.pointerCount) move(e.getPointerId(i), e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                up(e.getPointerId(e.actionIndex), false)
            }
            MotionEvent.ACTION_CANCEL -> {
                for (id in ptrs.indices) if (ptrs[id] != null) up(id, true)
            }
        }
        return true
    }

    private fun findKey(x: Float, y: Float): KeyRect? {
        var best: KeyRect? = null
        var bd = Float.MAX_VALUE
        for (k in keys) {
            if (k.hit.contains(x, y)) return k
            val dx = max(max(k.r.left - x, 0f), x - k.r.right)
            val dy = max(max(k.r.top - y, 0f), y - k.r.bottom)
            val dd = dx * dx + dy * dy
            if (dd < bd) {
                bd = dd
                best = k
            }
        }
        val lim = dp(22f)
        return if (bd < lim * lim) best else null
    }

    private fun down(id: Int, x: Float, y: Float) {
        if (id < 0 || id >= ptrs.size) return
        if (ptrs[id] != null) up(id, true)
        val k = findKey(x, y) ?: return
        val p = Ptr()
        p.dx = x
        p.dy = y
        p.lx = x
        p.ly = y
        ptrs[id] = p
        pressKey(p, k)
    }

    private fun pressKey(p: Ptr, k: KeyRect) {
        p.key = k
        p.mode = M_TAP
        k.spring.target = 1f
        val def = k.def
        if (def.type == KType.SHIFT) {
            shiftHeld = true
            typedDuringShift = false
        }
        listener?.onPress(def)
        if (previewOn && (def.type == KType.LETTER || def.type == KType.SYMBOL)) {
            val b = Bubble(k)
            bubbles.add(b)
            p.bubble = b
        }
        if (def.type == KType.BACKSPACE) {
            listener?.onKey(def, "")
            scheduleRepeat(p)
        } else {
            scheduleLong(p, k)
        }
        kick()
    }

    private fun scheduleRepeat(p: Ptr) {
        val r = object : Runnable {
            override fun run() {
                if (p.mode != M_TAP && p.mode != M_REPEAT) return
                p.mode = M_REPEAT
                p.repN++
                listener?.onBackspaceRepeat(p.repN)
                val delay = if (p.repN < 6) 70L else if (p.repN < 14) 45L else 32L
                postDelayed(this, delay)
            }
        }
        p.rep = r
        postDelayed(r, 380L)
    }

    private fun scheduleLong(p: Ptr, k: KeyRect) {
        val t = k.def.type
        if (k.def.alts.isEmpty() && t != KType.EMOJI && t != KType.GLOBE && t != KType.SPACE) return
        val r = Runnable { onLong(p, k) }
        p.lp = r
        postDelayed(r, longPressMs)
    }

    private fun onLong(p: Ptr, k: KeyRect) {
        if (p.key !== k || p.mode != M_TAP) return
        val consumed = listener?.onLongPressKey(k.def) == true
        if (consumed) {
            p.mode = M_DONE
            k.spring.target = 0f
            closeBubble(p)
            kick()
            return
        }
        if (k.def.alts.isNotEmpty()) {
            closeBubble(p)
            openPopup(k, p)
            p.mode = M_POPUP
            onOverlay?.invoke()
        }
    }

    private fun cancelCallbacks(p: Ptr) {
        p.lp?.let { removeCallbacks(it) }
        p.rep?.let { removeCallbacks(it) }
        p.lp = null
        p.rep = null
    }

    private fun closeBubble(p: Ptr) {
        val b = p.bubble ?: return
        b.closing = true
        b.sp.target = 0f
        p.bubble = null
        kick()
    }

    private fun move(id: Int, x: Float, y: Float) {
        if (id < 0 || id >= ptrs.size) return
        val p = ptrs[id] ?: return
        when (p.mode) {
            M_GLIDE -> {
                addGlide(p, x, y)
                return
            }
            M_POPUP -> {
                updatePopup(p, x, y)
                return
            }
            M_SPACE -> {
                spaceMove(p, x)
                return
            }
            M_BACK -> {
                backMove(p, x)
                return
            }
            M_REPEAT, M_DONE -> return
        }
        p.lx = x
        p.ly = y
        val k0 = p.key ?: return
        val def = k0.def
        if (def.type == KType.SPACE && spaceCursorOn && abs(x - p.dx) > dp(26f)) {
            cancelCallbacks(p)
            closeBubble(p)
            p.mode = M_SPACE
            p.accum = 0f
            p.lx = x
            return
        }
        if (def.type == KType.BACKSPACE && backSwipeOn && p.dx - x > dp(36f)) {
            cancelCallbacks(p)
            p.mode = M_BACK
            p.accum = 0f
            p.lx = x
            return
        }
        val nk = findKey(x, y)
        if (nk != null && nk !== k0) {
            if (glideOn && def.type == KType.LETTER && nk.def.type == KType.LETTER && hypot(x - p.dx, y - p.dy) > dp(12f)) {
                startGlide(p, x, y)
            } else if (!k0.hit.contains(x, y)) {
                cancelCallbacks(p)
                k0.spring.target = 0f
                if (def.type == KType.SHIFT) shiftHeld = false
                closeBubble(p)
                pressKey(p, nk)
            }
        }
    }

    private fun spaceMove(p: Ptr, x: Float) {
        p.accum += x - p.lx
        p.lx = x
        val step = dp(16f)
        while (p.accum >= step) {
            listener?.onSpaceSwipe(1)
            p.accum -= step
        }
        while (p.accum <= -step) {
            listener?.onSpaceSwipe(-1)
            p.accum += step
        }
    }

    private fun backMove(p: Ptr, x: Float) {
        p.accum += p.lx - x
        p.lx = x
        val step = dp(44f)
        while (p.accum >= step) {
            listener?.onBackspaceSwipeStep()
            p.accum -= step
        }
        if (p.accum < 0f) p.accum = 0f
    }

    private fun startGlide(p: Ptr, x: Float, y: Float) {
        cancelCallbacks(p)
        p.mode = M_GLIDE
        p.gx = FloatArray(600)
        p.gy = FloatArray(600)
        p.gn = 0
        p.key?.let { it.spring.target = 0f }
        closeBubble(p)
        trail.clear()
        addGlide(p, p.dx, p.dy)
        addGlide(p, x, y)
        kick()
    }

    private fun addGlide(p: Ptr, x: Float, y: Float) {
        if (p.gn > 0) {
            val lx = p.gx[p.gn - 1]
            val ly = p.gy[p.gn - 1]
            if (hypot(x - lx, y - ly) < dp(2.5f)) return
        }
        if (p.gn >= p.gx.size) return
        p.gx[p.gn] = x
        p.gy[p.gn] = y
        p.gn++
        if (trailOn) {
            trail.add(TrailPt(x, y, SystemClock.uptimeMillis()))
            kick()
        }
        onOverlay?.invoke()
    }

    private fun up(id: Int, cancel: Boolean) {
        if (id < 0 || id >= ptrs.size) return
        val p = ptrs[id] ?: return
        ptrs[id] = null
        cancelCallbacks(p)
        val k = p.key
        if (k != null) k.spring.target = 0f
        when (p.mode) {
            M_TAP -> {
                if (k != null) {
                    if (k.def.type == KType.SHIFT) {
                        shiftHeld = false
                        if (!cancel && !typedDuringShift) listener?.onKey(k.def, "")
                    } else if (!cancel && k.def.type != KType.BACKSPACE) {
                        commitKey(k)
                    }
                    if (!cancel) listener?.onRelease(k.def)
                }
            }
            M_POPUP -> {
                val pp = popup
                if (!cancel && pp != null && pp.ptr === p && k != null) {
                    val out = pp.outs.getOrNull(pp.sel)
                    if (out != null) {
                        if (k.def.type == KType.LETTER || k.def.type == KType.SYMBOL) {
                            if (shiftHeld) typedDuringShift = true
                        }
                        listener?.onKey(k.def, out)
                    }
                }
                popup = null
                if (k != null && !cancel) listener?.onRelease(k.def)
            }
            M_GLIDE -> {
                if (!cancel && p.gn >= 3) listener?.onGlideEnd(p.gx, p.gy, p.gn)
            }
            M_SPACE, M_BACK, M_REPEAT -> {
                if (k != null && !cancel) listener?.onRelease(k.def)
            }
            else -> {}
        }
        closeBubble(p)
        if (popup != null && popup?.ptr === p) popup = null
        kick()
        onOverlay?.invoke()
    }

    private fun commitKey(k: KeyRect) {
        val def = k.def
        val text = when (def.type) {
            KType.LETTER -> if (effShift) def.label.uppercase() else def.label
            else -> def.out ?: def.label
        }
        if ((def.type == KType.LETTER || def.type == KType.SYMBOL) && shiftHeld) typedDuringShift = true
        listener?.onKey(def, text)
    }

    // ---------------------------------------------------------------- popups

    private fun openPopup(k: KeyRect, p: Ptr) {
        val def = k.def
        val eff = effShift
        val items = ArrayList<String>()
        val outs = ArrayList<String>()
        for ((i, a) in def.alts.withIndex()) {
            val s = if (eff && def.type == KType.LETTER && a.length == 1 && a[0].isLetter()) a.uppercase() else a
            items.add(s)
            outs.add(def.altOut?.getOrNull(i) ?: s)
        }
        val n = items.size
        var maxLen = 1
        for (s in items) if (s.length > maxLen) maxLen = s.length
        val iw = max(dp(42f), maxLen * dp(9.5f) + dp(24f))
        val ih = min(k.r.height(), dp(54f))
        val isSpace = def.type == KType.SPACE
        val perRow = if (n > 7 && !isSpace) (n + 1) / 2 else n
        val rows = (n + perRow - 1) / perRow
        val totalW = perRow * iw
        val gap = dp(6f)
        val margin = dp(4f)
        val rects = ArrayList<RectF>()

        val growRight: Boolean
        val start: Float
        if (isSpace) {
            growRight = true
            start = max(margin, min(k.r.centerX() - totalW / 2f, width - totalW - margin))
        } else if (k.r.centerX() - iw / 2f + totalW <= width - margin) {
            growRight = true
            start = max(margin, k.r.centerX() - iw / 2f)
        } else {
            growRight = false
            start = min(width - margin, k.r.centerX() + iw / 2f)
        }
        for (i in 0 until n) {
            val row = i / perRow
            val col = i % perRow
            val l = if (growRight) start + col * iw else start - (col + 1) * iw
            val bottom = k.r.top - gap - row * (ih + dp(4f))
            rects.add(RectF(l, bottom - ih, l + iw, bottom))
        }
        val bounds = RectF(rects[0])
        for (r in rects) bounds.union(r)
        val pp = Popup(k, items, outs, rects, bounds, rows, p, def.type)
        pp.sel = if (isSpace) -1 else 0
        popup = pp
    }

    private fun updatePopup(p: Ptr, x: Float, y: Float) {
        val pp = popup ?: return
        if (pp.ptr !== p) return
        var best = -1
        var bd = Float.MAX_VALUE
        for (i in pp.rects.indices) {
            val r = pp.rects[i]
            val dx = max(max(r.left - x, 0f), x - r.right)
            val dy = if (pp.rows > 1) max(max(r.top - y, 0f), y - r.bottom) else 0f
            val dd = dx * dx + dy * dy
            if (dd < bd) {
                bd = dd
                best = i
            }
        }
        if (best != pp.sel) {
            pp.sel = best
            onOverlay?.invoke()
        }
    }

    /** Drops every pending touch/animation state (used when the keyboard is hidden or rebuilt). */
    fun cancelAll() {
        for (i in ptrs.indices) {
            val p = ptrs[i]
            if (p != null) cancelCallbacks(p)
            ptrs[i] = null
        }
        bubbles.clear()
        trail.clear()
        popup = null
        shiftHeld = false
        for (k in keys) {
            k.spring.value = 0f
            k.spring.target = 0f
            k.spring.v = 0f
        }
        onOverlay?.invoke()
    }

    override fun onDetachedFromWindow() {
        cancelAll()
        super.onDetachedFromWindow()
    }
}

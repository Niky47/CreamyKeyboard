package dev.creamy.keyboard

import android.content.Context
import android.graphics.Paint

/** Emoji catalogue loaded from assets/emoji.txt (category headers "@ icon Name", lines "emoji kw|kw"). */
object EmojiData {
    class Item(val e: String, val kw: String)
    class Cat(val icon: String, val name: String, val items: List<Item>)

    var cats: List<Cat> = emptyList()
        private set

    private val byKw = HashMap<String, String>()
    private val tone = HashSet<String>()
    private var loaded = false

    private const val TONE_BASES =
        "👋🤚🖐✋🖖👌🤌🤏✌🤞🤟🤘🤙👈👉👆👇☝👍👎✊👊🤛🤜👏🙌👐🤲🙏✍💅🤳💪👶🧒👦👧🧑👨👩🧓👴👵🙋🤦🤷💃🕺🏃🚶🧘🤝"

    @Synchronized
    fun load(ctx: Context) {
        if (loaded) return
        loaded = true

        var i = 0
        while (i < TONE_BASES.length) {
            val cp = TONE_BASES.codePointAt(i)
            tone.add(String(Character.toChars(cp)))
            i += Character.charCount(cp)
        }

        val paint = Paint()
        val out = ArrayList<Cat>()
        var curIcon = ""
        var curName = ""
        var cur = ArrayList<Item>()
        try {
            val lines = ctx.assets.open("emoji.txt").bufferedReader(Charsets.UTF_8).use { it.readLines() }
            for (line in lines) {
                if (line.startsWith("@ ")) {
                    if (cur.isNotEmpty()) out.add(Cat(curIcon, curName, cur))
                    val parts = line.substring(2).split(" ", limit = 2)
                    curIcon = parts[0]
                    curName = if (parts.size > 1) parts[1] else ""
                    cur = ArrayList()
                } else if (line.isNotBlank()) {
                    val sp = line.indexOf(' ')
                    val e = if (sp < 0) line.trim() else line.substring(0, sp)
                    val kw = if (sp < 0) "" else line.substring(sp + 1).trim().lowercase()
                    if (!paint.hasGlyph(e)) continue
                    cur.add(Item(e, kw))
                    for (k in kw.split("|")) {
                        val kk = k.trim()
                        if (kk.isNotEmpty() && !byKw.containsKey(kk)) byKw[kk] = e
                    }
                }
            }
            if (cur.isNotEmpty()) out.add(Cat(curIcon, curName, cur))
        } catch (e: Exception) {
            // no emoji file: panel stays empty
        }
        cats = out
    }

    fun search(q: String, limit: Int = 40): List<String> {
        val s = q.trim().lowercase()
        if (s.isEmpty()) return recent()
        val res = LinkedHashSet<String>()
        for (c in cats) {
            for (item in c.items) {
                for (k in item.kw.split("|")) {
                    if (k.startsWith(s)) {
                        res.add(item.e)
                        break
                    }
                }
            }
        }
        if (res.size < limit) {
            for (c in cats) for (item in c.items) if (item.kw.contains(s)) res.add(item.e)
        }
        return res.take(limit)
    }

    /** Emoji for an exact keyword (used for emoji prediction). */
    fun lookup(word: String): String? = byKw[word.lowercase()]

    fun supportsTone(e: String): Boolean = tone.contains(e.replace("\uFE0F", ""))

    fun withTone(e: String, t: Int): String =
        e.replace("\uFE0F", "") + String(Character.toChars(0x1F3FB + t))

    fun recent(): List<String> = P.EMOJI_RECENT.get().split(" ").filter { it.isNotEmpty() }

    fun addRecent(e: String) {
        val list = ArrayList<String>()
        list.add(e)
        for (r in recent()) if (r != e) list.add(r)
        P.EMOJI_RECENT.set(list.take(32).joinToString(" "))
    }
}

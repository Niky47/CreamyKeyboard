package dev.creamy.keyboard

import android.content.Context
import java.io.File
import java.text.Normalizer
import kotlin.math.hypot
import kotlin.math.ln
import kotlin.math.min

class Suggestion(val text: String, val kind: Int) {
    companion object {
        const val LITERAL = 0
        const val WORD = 1
        const val CORR = 2
        const val NEXT = 3
        const val EMOJI = 4
        const val CLIP = 5
        const val ALT = 6
    }
}

class Req(
    val word: String,
    val prev: String,
    val sentenceStart: Boolean,
    val langs: List<String>,
    val active: String,
    val autoCorrect: Boolean,
    val nextWord: Boolean,
    val emoji: Boolean,
    val cap: Boolean
)

class SuggestResult(val items: List<Suggestion>, val fix: String?)

/** Letter centres of the current layout, used to decode swipe typing. */
class GlideKeys(val chars: CharArray, val xs: FloatArray, val ys: FloatArray, val kw: Float)

object Fold {
    /** Lower-case + strip accents ("perché" -> "perche"). */
    fun fold(s: String): String {
        val low = s.lowercase()
        var ascii = true
        for (ch in low) {
            if (ch.code > 127) {
                ascii = false
                break
            }
        }
        if (ascii) return low
        val nfd = Normalizer.normalize(low, Normalizer.Form.NFD)
        val sb = StringBuilder(nfd.length)
        for (ch in nfd) {
            when {
                Character.getType(ch) == Character.NON_SPACING_MARK.toInt() -> {}
                ch == 'ß' -> sb.append("ss")
                ch == 'ł' -> sb.append('l')
                ch == 'ø' -> sb.append('o')
                ch == 'đ' -> sb.append('d')
                ch == 'æ' -> sb.append("ae")
                ch == 'œ' -> sb.append("oe")
                ch == '’' -> sb.append('\'')
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    fun core(fw: String): String {
        val sb = StringBuilder(fw.length)
        for (ch in fw) if (ch in 'a'..'z') sb.append(ch)
        return sb.toString()
    }
}

class Entry(val w: String, val lw: String, val fw: String, val core: String, val f: Int)

class Lexicon(val id: String) {
    val entries = ArrayList<Entry>()
    val byLower = HashMap<String, Entry>()
    val next = HashMap<String, ArrayList<String>>()
    val fixes = HashMap<String, String>()
    var starters: List<String> = emptyList()

    fun add(word: String, freq: Int) {
        val lw = word.lowercase()
        if (byLower.containsKey(lw)) return
        val fw = Fold.fold(word)
        val e = Entry(word, lw, fw, Fold.core(fw), freq)
        entries.add(e)
        byLower[lw] = e
    }

    /**
     * Line formats: plain words in frequency order, "word count", "^ starters",
     * "> prev next next ...", "= wrong>right ...", "# comment".
     */
    fun load(lines: List<String>) {
        var rank = 0
        val ws = Regex("\\s+")
        for (raw in lines) {
            val line = raw.trim()
            if (line.isEmpty() || line[0] == '#') continue
            when (line[0]) {
                '^' -> starters = line.substring(1).trim().split(ws).filter { it.isNotEmpty() }
                '>' -> {
                    val t = line.substring(1).trim().split(ws)
                    if (t.size >= 2) {
                        val l = next.getOrPut(t[0].lowercase()) { ArrayList() }
                        for (i in 1 until t.size) l.add(t[i])
                    }
                }
                '=' -> {
                    for (p in line.substring(1).trim().split(ws)) {
                        val i = p.indexOf('>')
                        if (i > 0) fixes[p.substring(0, i).lowercase()] = p.substring(i + 1)
                    }
                }
                else -> {
                    val t = line.split(ws)
                    if (t.size == 2 && t[1].all { it.isDigit() }) {
                        val c = t[1].toLongOrNull() ?: 1L
                        add(t[0], min(c, 2_000_000_000L).toInt())
                    } else {
                        for (w in t) {
                            add(w, 1_000_000 / (rank + 8))
                            rank++
                        }
                    }
                }
            }
        }
    }
}

/** What the keyboard learned from the user: word counts, capitalisation and word pairs. */
class UserModel(private val file: File) {
    private val uni = HashMap<String, Int>()
    private val uniF = HashMap<String, String>()
    private val form = HashMap<String, String>()
    private val bi = HashMap<String, HashMap<String, Int>>()
    private var dirty = 0
    private var loaded = false

    @Synchronized
    fun load() {
        if (loaded) return
        loaded = true
        try {
            if (!file.exists()) return
            file.forEachLine { line ->
                val t = line.split('\t')
                if (t.size >= 3 && t[0] == "U") {
                    val c = t[2].toIntOrNull()
                    if (c != null) {
                        uni[t[1]] = c
                        uniF[t[1]] = Fold.fold(t[1])
                        if (t.size >= 4 && t[3].isNotEmpty()) form[t[1]] = t[3]
                    }
                } else if (t.size >= 4 && t[0] == "B") {
                    val c = t[3].toIntOrNull()
                    if (c != null) bi.getOrPut(t[1]) { HashMap() }[t[2]] = c
                }
            }
        } catch (e: Exception) {
            // corrupted file: start fresh
        }
    }

    @Synchronized
    fun save() {
        if (dirty == 0) return
        try {
            val sb = StringBuilder()
            for ((w, c) in uni) {
                sb.append("U\t").append(w).append('\t').append(c).append('\t').append(form[w] ?: "").append('\n')
            }
            for ((p, m) in bi) for ((n, c) in m) {
                sb.append("B\t").append(p).append('\t').append(n).append('\t').append(c).append('\n')
            }
            file.writeText(sb.toString())
            dirty = 0
        } catch (e: Exception) {
            // best effort
        }
    }

    @Synchronized
    fun learn(prev: String, word: String, boost: Int, keepForm: Boolean) {
        val lw = word.lowercase()
        if (lw.length < 2 || !lw.any { it.isLetter() }) return
        uni[lw] = (uni[lw] ?: 0) + boost
        uniF[lw] = Fold.fold(lw)
        if (keepForm && word.any { it.isUpperCase() }) form[lw] = word
        if (prev.isNotEmpty()) {
            val m = bi.getOrPut(prev.lowercase()) { HashMap() }
            m[lw] = (m[lw] ?: 0) + boost
        }
        dirty++
        if (uni.size > 30000) prune()
        if (dirty >= 60) save()
    }

    private fun prune() {
        val it2 = uni.entries.iterator()
        while (it2.hasNext() && uni.size > 24000) {
            val e = it2.next()
            if (e.value <= 1) {
                uniF.remove(e.key)
                form.remove(e.key)
                it2.remove()
            }
        }
    }

    @Synchronized fun count(lw: String): Int = uni[lw] ?: 0

    @Synchronized fun formOf(lw: String): String? = form[lw]

    @Synchronized fun bigram(pl: String, lw: String): Int = bi[pl]?.get(lw) ?: 0

    @Synchronized
    fun prefix(fp: String, limit: Int): List<Pair<String, Int>> {
        val out = ArrayList<Pair<String, Int>>()
        for ((w, c) in uni) {
            if (c < 2) continue
            val f = uniF[w] ?: continue
            if (f.length >= fp.length && f.startsWith(fp)) out.add(Pair(w, c))
        }
        out.sortByDescending { it.second }
        return if (out.size > limit) ArrayList(out.subList(0, limit)) else out
    }

    @Synchronized
    fun nextAfter(pl: String): List<Pair<String, Int>> {
        val m = bi[pl] ?: return emptyList()
        val out = ArrayList<Pair<String, Int>>()
        for ((w, c) in m) out.add(Pair(w, c))
        out.sortByDescending { it.second }
        return if (out.size > 6) ArrayList(out.subList(0, 6)) else out
    }

    @Synchronized
    fun snapshot(): List<Triple<String, String, Int>> {
        val out = ArrayList<Triple<String, String, Int>>()
        for ((w, c) in uni) if (c >= 2) out.add(Triple(w, form[w] ?: w, c))
        return out
    }

    @Synchronized
    fun clear() {
        uni.clear()
        uniF.clear()
        form.clear()
        bi.clear()
        dirty = 0
        loaded = true
        try {
            file.delete()
        } catch (e: Exception) {
            // ignore
        }
    }

    @Synchronized fun size(): Int = uni.size
}

private class Cand(val lw: String, val text: String, var score: Double, val cost: Double, val kind: Int)

/** QWERTY geometry, used to make "neighbour key" typos cheaper than random ones. */
private object Adj {
    private val kx = FloatArray(26)
    private val ky = FloatArray(26)

    init {
        val rows = listOf("qwertyuiop", "asdfghjkl", "zxcvbnm")
        val off = floatArrayOf(0f, 0.5f, 1.5f)
        for (r in rows.indices) {
            for (c in rows[r].indices) {
                val ch = rows[r][c]
                kx[ch - 'a'] = c + off[r]
                ky[ch - 'a'] = r.toFloat()
            }
        }
    }

    fun near(a: Char, b: Char): Boolean {
        if (a !in 'a'..'z' || b !in 'a'..'z') return false
        val dx = kx[a - 'a'] - kx[b - 'a']
        val dy = ky[a - 'a'] - ky[b - 'a']
        return dx * dx + dy * dy <= 1.7f
    }
}

class Predictor(private val ctx: Context) {
    private val lex = HashMap<String, Lexicon>()
    val user = UserModel(File(ctx.filesDir, "user_model.tsv"))
    private val blocked = HashSet<String>()

    /** Call on a background thread: loads dictionaries, learned data and emoji. */
    fun warm(langs: List<String>) {
        user.load()
        EmojiData.load(ctx)
        for (id in langs) lexicon(id)
    }

    @Synchronized
    fun lexicon(id: String): Lexicon {
        val cached = lex[id]
        if (cached != null) return cached
        val l = Lexicon(id)
        try {
            l.load(ctx.assets.open("dict/$id.txt").bufferedReader(Charsets.UTF_8).use { it.readLines() })
        } catch (e: Exception) {
            // no bundled dictionary for this language
        }
        try {
            val f = File(ctx.filesDir, "dict/$id.txt")
            if (f.exists()) l.load(f.readLines())
        } catch (e: Exception) {
            // ignore broken imported list
        }
        lex[id] = l
        return l
    }

    @Synchronized
    fun reloadLexicons() {
        lex.clear()
    }

    fun block(word: String) {
        blocked.add(word.lowercase())
    }

    fun learn(prev: String, word: String, sentenceStart: Boolean, boost: Int) {
        user.learn(prev, word, boost, !sentenceStart)
    }

    private fun known(lw: String, langs: List<String>): Boolean {
        for (id in langs) if (lexicon(id).byLower.containsKey(lw)) return true
        return user.count(lw) >= 2
    }

    private fun matchCase(s: String, typed: String): String {
        if (typed.isEmpty() || s.isEmpty()) return s
        var letters = 0
        var upper = 0
        for (ch in typed) {
            if (ch.isLetter()) {
                letters++
                if (ch.isUpperCase()) upper++
            }
        }
        if (letters >= 2 && upper == letters) return s.uppercase()
        if (typed[0].isUpperCase()) return s.replaceFirstChar { it.uppercaseChar() }
        return s
    }

    private fun wedit(a: String, b: String, bound: Double): Double {
        val n = a.length
        val m = b.length
        if (Math.abs(n - m) > bound + 1.0) return 99.0
        var prev2 = DoubleArray(m + 1)
        var prev = DoubleArray(m + 1) { it.toDouble() }
        var cur = DoubleArray(m + 1)
        for (i in 1..n) {
            cur[0] = i.toDouble()
            var rowMin = cur[0]
            for (j in 1..m) {
                val ca = a[i - 1]
                val cb = b[j - 1]
                val sub = if (ca == cb) 0.0 else if (Adj.near(ca, cb)) 0.45 else 1.0
                var v = min(prev[j - 1] + sub, min(prev[j] + 1.0, cur[j - 1] + 1.0))
                if (i > 1 && j > 1 && a[i - 1] == b[j - 2] && a[i - 2] == b[j - 1]) {
                    v = min(v, prev2[j - 2] + 0.7)
                }
                cur[j] = v
                if (v < rowMin) rowMin = v
            }
            if (rowMin > bound) return 99.0
            val t = prev2
            prev2 = prev
            prev = cur
            cur = t
        }
        return prev[m]
    }

    private fun bigramScore(pl: String, lw: String, langs: List<String>): Double {
        if (pl.isEmpty()) return 0.0
        var s = 0.0
        val c = user.bigram(pl, lw)
        if (c > 0) s += min(3.0, 1.2 * ln(1.0 + c))
        for (id in langs) {
            val seeds = lexicon(id).next[pl] ?: continue
            val i = seeds.indexOfFirst { it.equals(lw, ignoreCase = true) }
            if (i >= 0) {
                s += 2.0 - 0.3 * i
                break
            }
        }
        return s
    }

    private fun put(map: HashMap<String, Cand>, c: Cand) {
        val old = map[c.lw]
        if (old == null || c.score > old.score) map[c.lw] = c
    }

    fun suggest(r: Req): SuggestResult {
        val items = ArrayList<Suggestion>(3)
        val w = r.word
        if (w.isEmpty()) {
            if (r.nextWord) items.addAll(nextWords(r))
            addEmoji(items, r.prev.lowercase(), r.emoji)
            return SuggestResult(items, null)
        }
        val lw = w.lowercase()
        val fw = Fold.fold(w)
        val isKnown = known(lw, r.langs)
        val pl = r.prev.lowercase()
        val cands = HashMap<String, Cand>()

        // completions
        for (id in r.langs) {
            val bonus = if (id == r.active) 0.6 else 0.0
            for (e in lexicon(id).entries) {
                if (e.fw.length >= fw.length && e.lw != lw && e.fw.startsWith(fw)) {
                    val sc = ln(e.f + 1.0) + 1.0 + bonus - 0.15 * (e.fw.length - fw.length)
                    put(cands, Cand(e.lw, e.w, sc, 0.0, Suggestion.WORD))
                }
            }
        }
        for ((ulw, c) in user.prefix(fw, 8)) {
            if (ulw != lw) {
                put(cands, Cand(ulw, user.formOf(ulw) ?: ulw, 3.0 + ln(1.0 + c) * 1.1, 0.0, Suggestion.WORD))
            }
        }

        // corrections
        if (!isKnown && fw.length >= 2) {
            val bound = if (fw.length <= 3) 1.05 else if (fw.length <= 5) 1.55 else 2.05
            for (id in r.langs) {
                val bonus = if (id == r.active) 0.6 else 0.0
                for (e in lexicon(id).entries) {
                    val dl = e.fw.length - fw.length
                    if (dl > 2 || dl < -2) continue
                    val cost = if (e.fw == fw) 0.12 else wedit(fw, e.fw, bound)
                    if (cost > bound) continue
                    put(cands, Cand(e.lw, e.w, ln(e.f + 1.0) - 3.2 * cost + bonus, cost, Suggestion.CORR))
                }
            }
            for ((ulw, form, c) in user.snapshot()) {
                val uf = Fold.fold(ulw)
                if (Math.abs(uf.length - fw.length) > 2) continue
                val cost = if (uf == fw) 0.12 else wedit(fw, uf, bound)
                if (cost > bound) continue
                put(cands, Cand(ulw, form, 2.0 + ln(1.0 + c) - 3.2 * cost, cost, Suggestion.CORR))
            }
        }

        for (c in cands.values) {
            c.score += bigramScore(pl, c.lw, r.langs)
            val uc = user.count(c.lw)
            if (uc > 0) c.score += min(3.0, 0.8 * ln(1.0 + uc))
        }
        val sorted = cands.values.sortedByDescending { it.score }
        val top = ArrayList<Cand>()
        for (c in sorted) {
            if (top.size >= 3) break
            top.add(c)
        }

        if (isKnown) {
            items.add(Suggestion(w, Suggestion.WORD))
            for (c in top) {
                if (items.size >= 3) break
                items.add(Suggestion(matchCase(c.text, w), c.kind))
            }
        } else {
            if (top.isNotEmpty()) items.add(Suggestion(matchCase(top[0].text, w), top[0].kind))
            items.add(Suggestion(w, Suggestion.LITERAL))
            if (top.size > 1) items.add(Suggestion(matchCase(top[1].text, w), top[1].kind))
        }
        if (isKnown) addEmoji(items, lw, r.emoji)
        return SuggestResult(items, null)
    }

    private fun addEmoji(items: ArrayList<Suggestion>, key: String, enabled: Boolean) {
        if (!enabled || key.isEmpty()) return
        val e = EmojiData.lookup(key) ?: return
        if (items.size >= 3) items[2] = Suggestion(e, Suggestion.EMOJI) else items.add(Suggestion(e, Suggestion.EMOJI))
    }

    private fun nextWords(r: Req): List<Suggestion> {
        val sc = HashMap<String, Double>()
        val forms = HashMap<String, String>()
        val pl = r.prev.lowercase()

        fun add(lw: String, s: Double, form: String?) {
            sc[lw] = (sc[lw] ?: 0.0) + s
            if (form != null && !forms.containsKey(lw)) forms[lw] = form
        }

        if (pl.isNotEmpty()) {
            for ((w, c) in user.nextAfter(pl)) add(w, 4.0 + ln(1.0 + c) * 2.0, null)
            for (id in r.langs) {
                val seeds = lexicon(id).next[pl] ?: continue
                for ((i, w) in seeds.withIndex()) {
                    add(w.lowercase(), 3.0 - 0.35 * i + (if (id == r.active) 0.5 else 0.0), w)
                }
            }
        }
        if (r.sentenceStart || pl.isEmpty()) {
            for (id in r.langs) {
                for ((i, w) in lexicon(id).starters.withIndex()) {
                    add(w.lowercase(), 2.4 - 0.2 * i + (if (id == r.active) 0.6 else 0.0), w)
                }
            }
        }
        if (sc.size < 3) {
            val ax = lexicon(r.active)
            for (i in 0 until min(8, ax.entries.size)) {
                val e = ax.entries[i]
                add(e.lw, 1.0 - i * 0.05, e.w)
            }
        }
        val ordered = sc.entries.sortedByDescending { it.value }
        val cap = r.cap || r.sentenceStart
        val out = ArrayList<Suggestion>(3)
        for (en in ordered) {
            if (out.size >= 3) break
            var t = user.formOf(en.key) ?: forms[en.key] ?: en.key
            if (cap && t.isNotEmpty()) t = t.replaceFirstChar { it.uppercaseChar() }
            out.add(Suggestion(t, Suggestion.NEXT))
        }
        return out
    }

    /** Replacement to apply when the user finishes typing [Req.word], or null to leave it alone. */
    fun autoFix(r: Req): String? {
        val w = r.word
        if (w.isEmpty()) return null
        val lw = w.lowercase()
        if (lw == "i" && r.langs.contains("en")) return if (w == "I") null else "I"
        for (id in r.langs) {
            val f = lexicon(id).fixes[lw]
            if (f != null) return matchCase(f, w)
        }
        if (!r.autoCorrect || w.length < 3) return null
        if (w.any { it.isDigit() || it == '@' || it == '#' || it == '_' || it == '.' || it == '/' }) return null
        if (w[0].isUpperCase() && !r.sentenceStart) return null
        if (w.all { !it.isLetter() || it.isUpperCase() }) return null
        if (known(lw, r.langs) || blocked.contains(lw)) return null

        val fw = Fold.fold(w)
        val bound = if (fw.length <= 4) 1.05 else 1.65
        val pl = r.prev.lowercase()
        var best: Cand? = null
        for (id in r.langs) {
            val bonus = if (id == r.active) 0.6 else 0.0
            for (e in lexicon(id).entries) {
                val dl = e.fw.length - fw.length
                if (dl > 1 || dl < -1) continue
                val cost = if (e.fw == fw) 0.12 else wedit(fw, e.fw, bound)
                if (cost > bound) continue
                val sc = ln(e.f + 1.0) - 3.2 * cost + bonus + bigramScore(pl, e.lw, r.langs)
                val b = best
                if (b == null || sc > b.score) best = Cand(e.lw, e.w, sc, cost, Suggestion.CORR)
            }
        }
        val b = best ?: return null
        return matchCase(b.text, w)
    }

    // ---------------------------------------------------------------- swipe typing

    private fun resample(x: FloatArray, y: FloatArray, n: Int, ox: FloatArray, oy: FloatArray, m: Int) {
        if (n < 2) {
            for (i in 0 until m) {
                ox[i] = x[0]
                oy[i] = y[0]
            }
            return
        }
        var total = 0f
        for (i in 1 until n) total += hypot(x[i] - x[i - 1], y[i] - y[i - 1])
        if (total <= 0f) {
            for (i in 0 until m) {
                ox[i] = x[0]
                oy[i] = y[0]
            }
            return
        }
        val step = total / (m - 1)
        var i = 1
        var c0 = 0f
        var segLen = hypot(x[1] - x[0], y[1] - y[0])
        for (k in 0 until m) {
            val d = k * step
            while (i < n - 1 && c0 + segLen < d) {
                c0 += segLen
                i++
                segLen = hypot(x[i] - x[i - 1], y[i] - y[i - 1])
            }
            val t = if (segLen > 0f) ((d - c0) / segLen).coerceIn(0f, 1f) else 0f
            ox[k] = x[i - 1] + (x[i] - x[i - 1]) * t
            oy[k] = y[i - 1] + (y[i] - y[i - 1]) * t
        }
    }

    /** Best words for a swipe path (shape matching on key centres + word frequency). */
    fun glide(
        px: FloatArray, py: FloatArray, n: Int, gk: GlideKeys,
        langs: List<String>, active: String, prev: String
    ): List<String> {
        if (n < 3 || gk.chars.isEmpty()) return emptyList()
        var len = 0f
        for (i in 1 until n) len += hypot(px[i] - px[i - 1], py[i] - py[i - 1])
        if (len < gk.kw * 1.2f) return emptyList()

        val m = 40
        val gx = FloatArray(m)
        val gy = FloatArray(m)
        resample(px, py, n, gx, gy, m)
        val tol = gk.kw * 0.95f
        val ends = gk.kw * 1.7f

        val cidx = IntArray(26) { -1 }
        for (i in gk.chars.indices) {
            val ch = gk.chars[i]
            if (ch in 'a'..'z') cidx[ch - 'a'] = i
        }
        val startOk = BooleanArray(26)
        val endOk = BooleanArray(26)
        for (i in 0 until 26) {
            val k = cidx[i]
            if (k < 0) continue
            if (hypot(px[0] - gk.xs[k], py[0] - gk.ys[k]) <= ends) startOk[i] = true
            if (hypot(px[n - 1] - gk.xs[k], py[n - 1] - gk.ys[k]) <= ends) endOk[i] = true
        }

        val tx = FloatArray(40)
        val ty = FloatArray(40)
        val rx = FloatArray(m)
        val ry = FloatArray(m)
        val found = ArrayList<Cand>()

        fun consider(text: String, lw: String, core: String, lf: Double, bonus: Double) {
            if (core.length < 2) return
            if (!startOk[core[0] - 'a'] || !endOk[core[core.length - 1] - 'a']) return
            var cnt = 0
            var last = ' '
            var pi = 0
            for (ch in core) {
                if (ch == last) continue
                last = ch
                val k = cidx[ch - 'a']
                if (k < 0) return
                var j = pi
                var hit = false
                while (j < n) {
                    if (hypot(px[j] - gk.xs[k], py[j] - gk.ys[k]) <= tol) {
                        hit = true
                        break
                    }
                    j++
                }
                if (!hit) return
                pi = j
                if (cnt >= 40) return
                tx[cnt] = gk.xs[k]
                ty[cnt] = gk.ys[k]
                cnt++
            }
            if (cnt < 2) return
            resample(tx, ty, cnt, rx, ry, m)
            var d = 0f
            for (i in 0 until m) d += hypot(gx[i] - rx[i], gy[i] - ry[i])
            d /= (m * gk.kw)
            if (d > 1.7f) return
            found.add(Cand(lw, text, -d * 4.0 + 0.25 * lf + bonus, d.toDouble(), Suggestion.WORD))
        }

        for (id in langs) {
            val b = if (id == active) 0.3 else 0.0
            for (e in lexicon(id).entries) consider(e.w, e.lw, e.core, ln(e.f + 1.0), b)
        }
        for ((ulw, form, c) in user.snapshot()) {
            consider(form, ulw, Fold.core(Fold.fold(ulw)), ln(2000.0 + c * 500.0), 0.5)
        }
        if (found.isEmpty()) return emptyList()

        found.sortByDescending { it.score }
        val pl = prev.lowercase()
        val shortlist = ArrayList<Cand>(found.subList(0, min(12, found.size)))
        for (c in shortlist) c.score += bigramScore(pl, c.lw, langs)
        shortlist.sortByDescending { it.score }
        val out = ArrayList<String>()
        val seen = HashSet<String>()
        for (c in shortlist) {
            if (out.size >= 4) break
            if (seen.add(c.lw)) out.add(c.text)
        }
        return out
    }
}

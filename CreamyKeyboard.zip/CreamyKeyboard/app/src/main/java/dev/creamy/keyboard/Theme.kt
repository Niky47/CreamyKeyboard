package dev.creamy.keyboard

import android.annotation.SuppressLint
import android.content.Context
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.os.Build
import androidx.core.graphics.ColorUtils
import java.io.File

/** Material 3 colour roles used by the keyboard. */
class Scheme(
    val primary: Int, val onPrimary: Int, val primaryC: Int, val onPrimaryC: Int,
    val secondaryC: Int, val onSecondaryC: Int, val tertiaryC: Int, val onTertiaryC: Int,
    val surface: Int, val container: Int, val containerHigh: Int, val highest: Int,
    val onSurface: Int, val onSurfaceVar: Int, val outline: Int, val dark: Boolean
)

/** Everything the views need to draw the keyboard (colours + geometry). */
class KbTheme(
    val bg: Int, val key: Int, val keyText: Int, val func: Int, val funcText: Int,
    val accent: Int, val accentText: Int, val pressFill: Int, val pressText: Int,
    val chip: Int, val chipText: Int, val chipSel: Int, val chipSelText: Int,
    val panel: Int, val panelText: Int, val hint: Int, val trail: Int, val outline: Int,
    val btn: Int, val btnText: Int, val dark: Boolean,
    val keyH: Float, val keyGap: Float, val rowGap: Float, val radius: Float,
    val enterShape: String, val funcShape: String, val waves: Int, val amp: Float,
    val bold: Boolean, val labelScale: Float, val borders: Boolean, val press: String,
    val bgBitmap: Bitmap?, val bgDim: Float
)

private class Tonal(private val hue: Float, private val sat: Float) {
    fun tone(t: Int): Int {
        val l = t / 100f
        val m = 2f * l - 1f
        val edge = 1f - m * m
        val s = (sat * (0.35f + 0.65f * edge)).coerceIn(0f, 1f)
        return ColorUtils.HSLToColor(floatArrayOf(hue, s, l))
    }
}

object Themes {
    class Preset(val id: String, val name: String, val seed: Int)

    val PRESETS = listOf(
        Preset("you", "Material You", 0),
        Preset("creamy", "Creamy", 0xFFC8963E.toInt()),
        Preset("matcha", "Matcha", 0xFF6A994E.toInt()),
        Preset("rose", "Rosé", 0xFFD0506E.toInt()),
        Preset("ocean", "Ocean", 0xFF2E86C1.toInt()),
        Preset("violet", "Violet", 0xFF7C5CD6.toInt()),
        Preset("graphite", "Graphite", 0xFF607080.toInt()),
        Preset("neon", "Neon", 0xFF00E5CC.toInt()),
        Preset("custom", "Custom", 0)
    )

    private var bgCache: Bitmap? = null
    private var bgKey = ""

    fun fromSeed(seed: Int, dark: Boolean): Scheme {
        val hsl = FloatArray(3)
        ColorUtils.colorToHSL(seed, hsl)
        val h = hsl[0]
        val s = hsl[1].coerceIn(0.25f, 0.85f)
        val p = Tonal(h, s * 0.75f)
        val sec = Tonal(h, s * 0.28f)
        val ter = Tonal((h + 55f) % 360f, s * 0.5f)
        val n = Tonal(h, 0.05f)
        val nv = Tonal(h, 0.10f)
        return if (!dark) {
            Scheme(
                primary = p.tone(40), onPrimary = p.tone(100), primaryC = p.tone(90), onPrimaryC = p.tone(10),
                secondaryC = sec.tone(90), onSecondaryC = sec.tone(10), tertiaryC = ter.tone(90), onTertiaryC = ter.tone(10),
                surface = n.tone(99), container = n.tone(95), containerHigh = n.tone(92), highest = n.tone(90),
                onSurface = n.tone(10), onSurfaceVar = nv.tone(30), outline = nv.tone(50), dark = false
            )
        } else {
            Scheme(
                primary = p.tone(80), onPrimary = p.tone(20), primaryC = p.tone(30), onPrimaryC = p.tone(90),
                secondaryC = sec.tone(30), onSecondaryC = sec.tone(90), tertiaryC = ter.tone(30), onTertiaryC = ter.tone(90),
                surface = n.tone(6), container = n.tone(12), containerHigh = n.tone(17), highest = n.tone(22),
                onSurface = n.tone(90), onSurfaceVar = nv.tone(80), outline = nv.tone(60), dark = true
            )
        }
    }

    /** Material You colours from the wallpaper (Android 12+). */
    @SuppressLint("NewApi")
    fun dynamic(ctx: Context, dark: Boolean): Scheme {
        fun c(id: Int): Int = ctx.getColor(id)
        return if (!dark) {
            Scheme(
                primary = c(android.R.color.system_accent1_600), onPrimary = c(android.R.color.system_accent1_0),
                primaryC = c(android.R.color.system_accent1_100), onPrimaryC = c(android.R.color.system_accent1_900),
                secondaryC = c(android.R.color.system_accent2_100), onSecondaryC = c(android.R.color.system_accent2_900),
                tertiaryC = c(android.R.color.system_accent3_100), onTertiaryC = c(android.R.color.system_accent3_900),
                surface = c(android.R.color.system_neutral1_10), container = c(android.R.color.system_neutral1_50),
                containerHigh = ColorUtils.blendARGB(c(android.R.color.system_neutral1_50), c(android.R.color.system_neutral1_100), 0.4f),
                highest = c(android.R.color.system_neutral1_100),
                onSurface = c(android.R.color.system_neutral1_900), onSurfaceVar = c(android.R.color.system_neutral2_700),
                outline = c(android.R.color.system_neutral2_500), dark = false
            )
        } else {
            Scheme(
                primary = c(android.R.color.system_accent1_200), onPrimary = c(android.R.color.system_accent1_800),
                primaryC = c(android.R.color.system_accent1_700), onPrimaryC = c(android.R.color.system_accent1_100),
                secondaryC = c(android.R.color.system_accent2_700), onSecondaryC = c(android.R.color.system_accent2_100),
                tertiaryC = c(android.R.color.system_accent3_700), onTertiaryC = c(android.R.color.system_accent3_100),
                surface = ColorUtils.blendARGB(c(android.R.color.system_neutral1_900), Color.BLACK, 0.3f),
                container = c(android.R.color.system_neutral1_900),
                containerHigh = ColorUtils.blendARGB(c(android.R.color.system_neutral1_900), c(android.R.color.system_neutral1_800), 0.5f),
                highest = ColorUtils.blendARGB(c(android.R.color.system_neutral1_800), c(android.R.color.system_neutral1_700), 0.15f),
                onSurface = c(android.R.color.system_neutral1_100), onSurfaceVar = c(android.R.color.system_neutral2_200),
                outline = c(android.R.color.system_neutral2_400), dark = true
            )
        }
    }

    private fun loadBg(path: String): Bitmap? {
        if (path.isEmpty()) return null
        val f = File(path)
        if (!f.exists()) return null
        val key = path + f.lastModified()
        if (key == bgKey && bgCache != null) return bgCache
        return try {
            val o = BitmapFactory.Options()
            o.inJustDecodeBounds = true
            BitmapFactory.decodeFile(path, o)
            var sample = 1
            while (o.outWidth / sample > 1400 || o.outHeight / sample > 1400) sample *= 2
            val o2 = BitmapFactory.Options()
            o2.inSampleSize = sample
            val b = BitmapFactory.decodeFile(path, o2)
            bgCache = b
            bgKey = key
            b
        } catch (e: Throwable) {
            null
        }
    }

    fun build(ctx: Context): KbTheme {
        val mode = P.DARK.get()
        val night = (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        val id = P.THEME.get()
        var dark = when (mode) {
            "dark", "amoled" -> true
            "light" -> false
            else -> night
        }
        var amoled = mode == "amoled"
        if (id == "neon") {
            dark = true
            amoled = true
        }
        val bmp = loadBg(P.BG_IMAGE.get())
        if (bmp != null) dark = true

        val s: Scheme = if (id == "you" && Build.VERSION.SDK_INT >= 31) {
            dynamic(ctx, dark)
        } else {
            val preset = PRESETS.firstOrNull { it.id == id }
            val seed = if (id == "custom") P.SEED.get()
            else if (preset != null && preset.seed != 0) preset.seed
            else 0xFF6750A4.toInt()
            fromSeed(seed, dark)
        }

        fun a(c: Int): Int = if (bmp != null) ColorUtils.setAlphaComponent(c, 205) else c

        var bg = s.container
        var key = if (s.dark) s.highest else s.surface
        if (amoled && s.dark) {
            bg = Color.BLACK
            key = ColorUtils.blendARGB(s.container, Color.BLACK, 0.35f)
        }
        if (bmp != null) bg = Color.TRANSPARENT

        val land = ctx.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        val keyH = P.KEY_H.get() * P.SIZE.get() * (if (land) 0.78f else 1f)

        return KbTheme(
            bg = bg, key = a(key), keyText = s.onSurface,
            func = a(s.secondaryC), funcText = s.onSecondaryC,
            accent = s.primary, accentText = s.onPrimary,
            pressFill = s.primaryC, pressText = s.onPrimaryC,
            chip = a(key), chipText = s.onSurface, chipSel = s.primaryC, chipSelText = s.onPrimaryC,
            panel = a(s.containerHigh), panelText = s.onSurface,
            hint = ColorUtils.setAlphaComponent(s.onSurfaceVar, 170),
            trail = s.primary, outline = s.outline,
            btn = s.tertiaryC, btnText = s.onTertiaryC, dark = s.dark,
            keyH = keyH, keyGap = P.KEY_GAP.get(), rowGap = P.ROW_GAP.get(), radius = P.RADIUS.get(),
            enterShape = P.ENTER_SHAPE.get(), funcShape = P.FUNC_SHAPE.get(),
            waves = P.WAVES.get(), amp = P.WAVE_AMP.get(),
            bold = P.BOLD.get(), labelScale = P.LABEL_SCALE.get(), borders = P.BORDERS.get(),
            press = P.PRESS.get(), bgBitmap = bmp, bgDim = P.BG_DIM.get()
        )
    }
}

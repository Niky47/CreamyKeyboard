package dev.creamy.keyboard

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.text.TextUtils
import android.view.Gravity
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.OverScroller
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min

/** What panels can ask the keyboard service to do. */
interface Host {
    fun insert(text: String)
    fun backspace()
    fun closePanel()
    fun fieldText(): String
    fun replaceField(text: String)
    fun openInline(hint: String, live: ((String) -> List<String>)?, onSubmit: (String) -> Unit)
    fun commitGif(url: String)
    fun toast(msg: String)
    fun openSettings()
    fun kbTheme(): KbTheme
    fun panelWidth(): Int
}

object UI {
    fun dp(ctx: Context, v: Float): Int = (v * ctx.resources.displayMetrics.density + 0.5f).toInt()

    fun round(ctx: Context, color: Int, radiusDp: Float): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = radiusDp * ctx.resources.displayMetrics.density
        return g
    }

    val tf: Typeface by lazy {
        if (Build.VERSION.SDK_INT >= 28) {
            Typeface.create(Typeface.create("sans-serif-rounded", Typeface.NORMAL), 600, false)
        } else {
            Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }
    }

    fun chip(ctx: Context, th: KbTheme, text: String, sel: Boolean, onClick: () -> Unit): TextView {
        val t = TextView(ctx)
        t.text = text
        t.textSize = 14f
        t.typeface = tf
        t.gravity = Gravity.CENTER
        t.setTextColor(if (sel) th.chipSelText else th.chipText)
        t.background = round(ctx, if (sel) th.chipSel else th.chip, 100f)
        t.setPadding(dp(ctx, 14f), dp(ctx, 8f), dp(ctx, 14f), dp(ctx, 8f))
        t.setOnClickListener { onClick() }
        return t
    }

    fun label(ctx: Context, text: String, size: Float, color: Int): TextView {
        val t = TextView(ctx)
        t.text = text
        t.textSize = size
        t.typeface = tf
        t.setTextColor(color)
        return t
    }
}

class IconView(ctx: Context, var icon: Int, var tint: Int) : View(ctx) {
    override fun onDraw(c: Canvas) {
        KbIcons.draw(c, icon, width / 2f, height / 2f, min(width, height) * 0.55f, tint)
    }
}

// -------------------------------------------------------------------- emoji

class EmojiGrid(ctx: Context, private val host: Host) : View(ctx) {
    var items: List<String> = emptyList()
        set(v) {
            field = v
            offY = 0f
            toneIdx = -1
            invalidate()
        }

    private val th = host.kbTheme()
    private val cols = 8
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val scroller = OverScroller(ctx)
    private var offY = 0f
    private var toneIdx = -1
    private var tones: List<String> = emptyList()
    private val toneRect = RectF()
    private val rr = RectF()

    private val detector = GestureDetector(ctx, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean {
            scroller.forceFinished(true)
            return true
        }

        override fun onScroll(e1: MotionEvent?, e2: MotionEvent, distanceX: Float, distanceY: Float): Boolean {
            offY = (offY + distanceY).coerceIn(0f, maxOff())
            toneIdx = -1
            invalidate()
            return true
        }

        override fun onFling(e1: MotionEvent?, e2: MotionEvent, velocityX: Float, velocityY: Float): Boolean {
            scroller.fling(0, offY.toInt(), 0, -velocityY.toInt(), 0, 0, 0, maxOff().toInt())
            postInvalidateOnAnimation()
            return true
        }

        override fun onSingleTapUp(e: MotionEvent): Boolean {
            tap(e.x, e.y)
            return true
        }

        override fun onLongPress(e: MotionEvent) {
            longPress(e.x, e.y)
        }
    })

    private fun cell(): Float = width / cols.toFloat()

    private fun maxOff(): Float {
        val rows = ceil(items.size / cols.toFloat())
        return max(0f, rows * cell() - height)
    }

    private fun indexAt(x: Float, y: Float): Int {
        val cw = cell()
        if (cw <= 0f) return -1
        val col = (x / cw).toInt()
        val row = ((y + offY) / cw).toInt()
        val i = row * cols + col
        return if (col in 0 until cols && i >= 0 && i < items.size) i else -1
    }

    private fun tap(x: Float, y: Float) {
        if (toneIdx >= 0) {
            if (toneRect.contains(x, y) && tones.isNotEmpty()) {
                val w = toneRect.width() / tones.size
                val k = ((x - toneRect.left) / w).toInt().coerceIn(0, tones.size - 1)
                pick(tones[k])
            }
            toneIdx = -1
            invalidate()
            return
        }
        val i = indexAt(x, y)
        if (i >= 0) pick(items[i])
    }

    private fun pick(e: String) {
        host.insert(e)
        EmojiData.addRecent(e)
    }

    private fun longPress(x: Float, y: Float) {
        val i = indexAt(x, y)
        if (i < 0) return
        val e = items[i]
        if (!EmojiData.supportsTone(e)) return
        val list = ArrayList<String>()
        list.add(e)
        for (t in 0 until 5) {
            val v = EmojiData.withTone(e, t)
            if (paint.hasGlyph(v)) list.add(v)
        }
        if (list.size < 2) return
        tones = list
        toneIdx = i
        val cw = cell()
        val w = list.size * cw * 0.95f
        val cx = (i % cols + 0.5f) * cw
        val top = (i / cols) * cw - offY
        val l = (cx - w / 2f).coerceIn(2f, max(2f, width - w - 2f))
        val t = if (top - cw * 1.05f < 0f) top + cw else top - cw * 1.05f
        toneRect.set(l, t, l + w, t + cw)
        invalidate()
    }

    override fun computeScroll() {
        if (scroller.computeScrollOffset()) {
            offY = scroller.currY.toFloat().coerceIn(0f, maxOff())
            postInvalidateOnAnimation()
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        parent?.requestDisallowInterceptTouchEvent(true)
        return detector.onTouchEvent(e)
    }

    override fun onDraw(c: Canvas) {
        val cw = cell()
        if (cw <= 0f) return
        paint.textAlign = Paint.Align.CENTER
        if (items.isEmpty()) {
            paint.textSize = cw * 0.28f
            paint.color = th.hint
            c.drawText(Tx.t("Nessuna emoji recente", "No recent emoji"), width / 2f, height / 2f, paint)
            return
        }
        paint.textSize = cw * 0.58f
        paint.color = th.keyText
        val fm = paint.fontMetrics
        val first = max(0, (offY / cw).toInt())
        val last = min((items.size - 1) / cols, ((offY + height) / cw).toInt())
        for (r in first..last) {
            for (k in 0 until cols) {
                val i = r * cols + k
                if (i >= items.size) break
                val cx = (k + 0.5f) * cw
                val cy = r * cw - offY + cw / 2f
                c.drawText(items[i], cx, cy - (fm.ascent + fm.descent) / 2f, paint)
            }
        }
        if (toneIdx >= 0 && tones.isNotEmpty()) {
            paint.style = Paint.Style.FILL
            paint.color = th.panel
            rr.set(toneRect)
            rr.inset(-6f, -6f)
            c.drawRoundRect(rr, cw * 0.4f, cw * 0.4f, paint)
            paint.color = th.keyText
            val w = toneRect.width() / tones.size
            for (k in tones.indices) {
                c.drawText(tones[k], toneRect.left + (k + 0.5f) * w, toneRect.centerY() - (fm.ascent + fm.descent) / 2f, paint)
            }
        }
    }
}

class EmojiPanel(ctx: Context, private val host: Host) : LinearLayout(ctx) {
    private val th = host.kbTheme()
    private val grid = EmojiGrid(ctx, host)
    private val tabs = LinearLayout(ctx)
    private val tabViews = ArrayList<TextView>()

    init {
        orientation = VERTICAL
        EmojiData.load(ctx)

        val header = LinearLayout(ctx)
        header.orientation = HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL

        val search = IconView(ctx, KbIcons.SEARCH, th.chipText)
        search.setOnClickListener {
            host.openInline(Tx.t("Cerca emoji", "Search emoji"), { q -> EmojiData.search(q) }, { })
        }
        header.addView(search, LinearLayout.LayoutParams(UI.dp(ctx, 44f), UI.dp(ctx, 44f)))

        val scroll = HorizontalScrollView(ctx)
        scroll.isHorizontalScrollBarEnabled = false
        tabs.orientation = HORIZONTAL
        scroll.addView(tabs)
        header.addView(scroll, LinearLayout.LayoutParams(0, UI.dp(ctx, 44f), 1f))

        val back = IconView(ctx, KbIcons.BACKSPACE, th.chipText)
        back.setOnClickListener { host.backspace() }
        header.addView(back, LinearLayout.LayoutParams(UI.dp(ctx, 44f), UI.dp(ctx, 44f)))

        val abc = UI.label(ctx, "ABC", 14f, th.chipText)
        abc.gravity = Gravity.CENTER
        abc.setOnClickListener { host.closePanel() }
        header.addView(abc, LinearLayout.LayoutParams(UI.dp(ctx, 52f), UI.dp(ctx, 44f)))

        addView(header, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, UI.dp(ctx, 44f)))
        addView(grid, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        addTab("\uD83D\uDD58", 0)
        for ((i, cat) in EmojiData.cats.withIndex()) addTab(cat.icon, i + 1)
        select(if (EmojiData.recent().isNotEmpty()) 0 else 1)
    }

    private fun addTab(icon: String, index: Int) {
        val t = TextView(context)
        t.text = icon
        t.textSize = 20f
        t.gravity = Gravity.CENTER
        t.setOnClickListener { select(index) }
        tabs.addView(t, LinearLayout.LayoutParams(UI.dp(context, 44f), UI.dp(context, 40f)))
        tabViews.add(t)
    }

    private fun select(i: Int) {
        if (i < 0 || i >= tabViews.size) return
        for ((k, t) in tabViews.withIndex()) {
            t.background = if (k == i) UI.round(context, th.chipSel, 100f) else null
        }
        grid.items = if (i == 0) EmojiData.recent() else EmojiData.cats[i - 1].items.map { it.e }
    }
}

// -------------------------------------------------------------------- clipboard

class ClipPanel(ctx: Context, private val host: Host) : LinearLayout(ctx) {
    private val th = host.kbTheme()
    private val list = LinearLayout(ctx)

    init {
        orientation = VERTICAL
        val header = LinearLayout(ctx)
        header.orientation = HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        header.setPadding(UI.dp(ctx, 14f), 0, UI.dp(ctx, 8f), 0)
        val title = UI.label(ctx, Tx.t("Appunti", "Clipboard"), 16f, th.panelText)
        header.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val clear = UI.chip(ctx, th, Tx.t("Svuota", "Clear"), false) {
            ClipStore.clearUnpinned(context)
            refresh()
        }
        header.addView(clear)
        val abc = UI.chip(ctx, th, "ABC", false) { host.closePanel() }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.leftMargin = UI.dp(ctx, 8f)
        header.addView(abc, lp)
        addView(header, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, UI.dp(ctx, 46f)))

        val scroll = ScrollView(ctx)
        list.orientation = VERTICAL
        list.setPadding(UI.dp(ctx, 10f), 0, UI.dp(ctx, 10f), UI.dp(ctx, 8f))
        scroll.addView(list)
        addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        refresh()
    }

    private fun refresh() {
        list.removeAllViews()
        val ctx = context
        if (!P.CLIP_ON.get()) {
            list.addView(UI.label(ctx, Tx.t("La cronologia appunti è disattivata nelle impostazioni.", "Clipboard history is off in settings."), 14f, th.hint))
            return
        }
        val clips = ClipStore.list(ctx)
        if (clips.isEmpty()) {
            list.addView(UI.label(ctx, Tx.t("Copia del testo: apparirà qui.", "Copy some text: it will show up here."), 14f, th.hint))
            return
        }
        for (c in clips) {
            val row = LinearLayout(ctx)
            row.orientation = HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.background = UI.round(ctx, th.chip, 16f)
            row.setPadding(UI.dp(ctx, 14f), UI.dp(ctx, 8f), UI.dp(ctx, 6f), UI.dp(ctx, 8f))
            val tv = UI.label(ctx, c.text, 15f, th.chipText)
            tv.maxLines = 3
            tv.ellipsize = TextUtils.TruncateAt.END
            tv.setOnClickListener { host.insert(c.text) }
            row.addView(tv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            val pin = IconView(ctx, KbIcons.PIN, if (c.pinned) th.accent else th.hint)
            pin.setOnClickListener {
                ClipStore.togglePin(ctx, c)
                refresh()
            }
            row.addView(pin, LinearLayout.LayoutParams(UI.dp(ctx, 40f), UI.dp(ctx, 40f)))
            val del = IconView(ctx, KbIcons.CLOSE, th.hint)
            del.setOnClickListener {
                ClipStore.remove(ctx, c)
                refresh()
            }
            row.addView(del, LinearLayout.LayoutParams(UI.dp(ctx, 40f), UI.dp(ctx, 40f)))
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.bottomMargin = UI.dp(ctx, 6f)
            list.addView(row, lp)
        }
    }
}

// -------------------------------------------------------------------- GIF / stickers

class GifPanel(ctx: Context, private val host: Host, private var sticker: Boolean) : LinearLayout(ctx) {
    private val th = host.kbTheme()
    private val grid = GridLayout(ctx)
    private val status = UI.label(ctx, "", 14f, th.hint)
    private val searchPill = TextView(ctx)
    private val chipRow = LinearLayout(ctx)
    private var query: String? = null
    private var token = 0

    init {
        orientation = VERTICAL
        val header = LinearLayout(ctx)
        header.orientation = HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        header.setPadding(UI.dp(ctx, 8f), UI.dp(ctx, 4f), UI.dp(ctx, 8f), UI.dp(ctx, 4f))

        searchPill.text = Tx.t("Cerca…", "Search…")
        searchPill.textSize = 15f
        searchPill.typeface = UI.tf
        searchPill.setTextColor(th.hint)
        searchPill.gravity = Gravity.CENTER_VERTICAL
        searchPill.setPadding(UI.dp(ctx, 14f), 0, UI.dp(ctx, 14f), 0)
        searchPill.background = UI.round(ctx, th.chip, 100f)
        searchPill.setOnClickListener {
            host.openInline(Tx.t("Cerca", "Search"), null) { q ->
                query = q
                searchPill.text = if (q.isBlank()) Tx.t("Cerca…", "Search…") else q
                load()
            }
        }
        header.addView(searchPill, LinearLayout.LayoutParams(0, UI.dp(ctx, 40f), 1f))
        chipRow.orientation = HORIZONTAL
        header.addView(chipRow)
        addView(header, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, UI.dp(ctx, 50f)))

        val scroll = ScrollView(ctx)
        val box = LinearLayout(ctx)
        box.orientation = VERTICAL
        grid.columnCount = 3
        box.addView(status, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        box.addView(grid)
        box.setPadding(UI.dp(ctx, 6f), 0, UI.dp(ctx, 6f), UI.dp(ctx, 6f))
        scroll.addView(box)
        addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        rebuildChips()
        load()
    }

    private fun rebuildChips() {
        chipRow.removeAllViews()
        val ctx = context
        val a = UI.chip(ctx, th, "GIF", !sticker) {
            sticker = false
            rebuildChips()
            load()
        }
        val b = UI.chip(ctx, th, "Sticker", sticker) {
            sticker = true
            rebuildChips()
            load()
        }
        val c = UI.chip(ctx, th, "ABC", false) { host.closePanel() }
        for (v in listOf(a, b, c)) {
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.leftMargin = UI.dp(ctx, 6f)
            chipRow.addView(v, lp)
        }
    }

    private fun load() {
        grid.removeAllViews()
        status.text = "…"
        status.visibility = View.VISIBLE
        val my = ++token
        Giphy.fetch(query, sticker, { list ->
            if (my == token) show(list)
        }, { err ->
            if (my == token) {
                status.text = if (err == "no_key") {
                    Tx.t("Aggiungi la tua chiave Giphy gratuita nelle impostazioni (tocca qui).", "Add your free Giphy key in settings (tap here).")
                } else {
                    Tx.t("Errore di rete: ", "Network error: ") + err
                }
                if (err == "no_key") status.setOnClickListener { host.openSettings() }
            }
        })
    }

    private fun show(list: List<Gif>) {
        val ctx = context
        if (list.isEmpty()) {
            status.text = Tx.t("Nessun risultato", "No results")
            return
        }
        status.visibility = View.GONE
        val total = if (host.panelWidth() > 0) host.panelWidth() else resources.displayMetrics.widthPixels
        val cellW = (total - UI.dp(ctx, 12f)) / 3
        val cellH = UI.dp(ctx, 96f)
        for (g in list) {
            val iv = ImageView(ctx)
            iv.scaleType = ImageView.ScaleType.CENTER_CROP
            iv.background = UI.round(ctx, th.chip, 14f)
            iv.clipToOutline = true
            val lp = GridLayout.LayoutParams()
            lp.width = cellW - UI.dp(ctx, 6f)
            lp.height = cellH
            lp.setMargins(UI.dp(ctx, 3f), UI.dp(ctx, 3f), UI.dp(ctx, 3f), UI.dp(ctx, 3f))
            grid.addView(iv, lp)
            iv.setOnClickListener { host.commitGif(g.full) }
            Net.async({ Net.decode(Net.bytes(g.thumb, 1_500_000)) }, { bmp ->
                if (bmp != null) iv.setImageBitmap(bmp)
            }, { })
        }
    }
}

// -------------------------------------------------------------------- translate + AI

private class AiAct(val id: String, val ita: String, val eng: String, val sys: String)

class ToolsPanel(ctx: Context, private val host: Host, startAi: Boolean) : LinearLayout(ctx) {
    private val th = host.kbTheme()
    private var aiMode = startAi
    private val src = host.fieldText()
    private var result = ""
    private val tabRow = LinearLayout(ctx)
    private val options = LinearLayout(ctx)
    private val resView = TextView(ctx)
    private val srcView = TextView(ctx)
    private val btnRow = LinearLayout(ctx)

    private val acts = listOf(
        AiAct("fix", "Correggi", "Fix", "Correct spelling, grammar and punctuation. Keep the language, tone and meaning. Reply with the corrected text only."),
        AiAct("rewrite", "Riformula", "Rewrite", "Rewrite the text to be clearer and more natural. Keep the language and meaning. Reply with the rewritten text only."),
        AiAct("formal", "Formale", "Formal", "Rewrite the text in a formal, professional tone. Keep the language and meaning. Reply with the text only."),
        AiAct("friendly", "Amichevole", "Friendly", "Rewrite the text in a warm, friendly, casual tone. Keep the language and meaning. Reply with the text only."),
        AiAct("short", "Più breve", "Shorter", "Make the text shorter and more concise without losing the key points. Keep the language. Reply with the text only."),
        AiAct("long", "Più lungo", "Longer", "Expand the text with a little more detail while keeping its meaning and language. Reply with the text only."),
        AiAct("emoji", "Emoji", "Emoji", "Add fitting emoji to the text. Keep the wording and language. Reply with the text only.")
    )

    init {
        orientation = VERTICAL
        val pad = UI.dp(ctx, 10f)
        setPadding(pad, UI.dp(ctx, 4f), pad, UI.dp(ctx, 6f))

        tabRow.orientation = HORIZONTAL
        tabRow.gravity = Gravity.CENTER_VERTICAL
        addView(tabRow, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, UI.dp(ctx, 46f)))

        val scroll = HorizontalScrollView(ctx)
        scroll.isHorizontalScrollBarEnabled = false
        options.orientation = HORIZONTAL
        scroll.addView(options)
        addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, UI.dp(ctx, 42f)))

        srcView.textSize = 13f
        srcView.typeface = UI.tf
        srcView.setTextColor(th.hint)
        srcView.maxLines = 2
        srcView.ellipsize = TextUtils.TruncateAt.END
        srcView.text = if (src.isBlank()) {
            Tx.t("Scrivi prima un testo nel campo, poi scegli un'azione.", "Type some text in the field first, then pick an action.")
        } else {
            src
        }
        val slp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        slp.topMargin = UI.dp(ctx, 6f)
        addView(srcView, slp)

        val rs = ScrollView(ctx)
        resView.textSize = 16f
        resView.typeface = UI.tf
        resView.setTextColor(th.chipText)
        resView.setPadding(UI.dp(ctx, 14f), UI.dp(ctx, 10f), UI.dp(ctx, 14f), UI.dp(ctx, 10f))
        rs.background = UI.round(ctx, th.chip, 18f)
        rs.addView(resView)
        val rlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        rlp.topMargin = UI.dp(ctx, 6f)
        addView(rs, rlp)

        btnRow.orientation = HORIZONTAL
        btnRow.gravity = Gravity.END
        val blp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        blp.topMargin = UI.dp(ctx, 6f)
        addView(btnRow, blp)

        rebuildTabs()
        rebuildOptions()
        rebuildButtons()
    }

    private fun gap(v: View, ctx: Context): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.rightMargin = UI.dp(ctx, 6f)
        return lp
    }

    private fun rebuildTabs() {
        tabRow.removeAllViews()
        val ctx = context
        val a = UI.chip(ctx, th, Tx.t("Traduci", "Translate"), !aiMode) {
            aiMode = false
            clearResult()
            rebuildTabs()
            rebuildOptions()
        }
        val b = UI.chip(ctx, th, "AI", aiMode) {
            aiMode = true
            clearResult()
            rebuildTabs()
            rebuildOptions()
        }
        val c = UI.chip(ctx, th, "ABC", false) { host.closePanel() }
        tabRow.addView(a, gap(a, ctx))
        tabRow.addView(b, gap(b, ctx))
        tabRow.addView(View(ctx), LinearLayout.LayoutParams(0, 1, 1f))
        tabRow.addView(c)
    }

    private fun rebuildOptions() {
        options.removeAllViews()
        val ctx = context
        if (!aiMode) {
            val cur = P.TR_TARGET.get()
            for (code in Translator.LANGS) {
                val v = UI.chip(ctx, th, code.uppercase(), code == cur) {
                    P.TR_TARGET.set(code)
                    rebuildOptions()
                    runTranslate(code)
                }
                options.addView(v, gap(v, ctx))
            }
        } else {
            for (a in acts) {
                val v = UI.chip(ctx, th, Tx.t(a.ita, a.eng), false) { runAi(a.sys, src) }
                options.addView(v, gap(v, ctx))
            }
            val w = UI.chip(ctx, th, Tx.t("Scrivi…", "Write…"), false) {
                host.openInline(Tx.t("Cosa vuoi scrivere?", "What should I write?"), null) { prompt ->
                    if (prompt.isNotBlank()) {
                        runAi(
                            "You write short messages for the user. Write exactly what the request asks for, in the language of the request, with no preface and no quotes.",
                            prompt
                        )
                    }
                }
            }
            options.addView(w, gap(w, ctx))
        }
    }

    private fun clearResult() {
        result = ""
        resView.text = ""
        rebuildButtons()
    }

    private fun rebuildButtons() {
        btnRow.removeAllViews()
        val ctx = context
        if (result.isEmpty()) return
        val copy = UI.chip(ctx, th, Tx.t("Copia", "Copy"), false) {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("text", result))
            host.toast(Tx.t("Copiato", "Copied"))
        }
        val ins = UI.chip(ctx, th, Tx.t("Inserisci", "Insert"), false) { host.insert(result) }
        val rep = UI.chip(ctx, th, Tx.t("Sostituisci", "Replace"), true) {
            host.replaceField(result)
            host.closePanel()
        }
        for (v in listOf(copy, ins, rep)) {
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.leftMargin = UI.dp(ctx, 6f)
            btnRow.addView(v, lp)
        }
    }

    private fun showResult(s: String) {
        result = s
        resView.text = s
        resView.setTextColor(th.chipText)
        rebuildButtons()
    }

    private fun fail(err: String) {
        result = ""
        rebuildButtons()
        resView.setTextColor(th.hint)
        if (err == "no_key") {
            resView.text = Tx.t("Inserisci la chiave API nelle impostazioni (tocca qui).", "Add your API key in settings (tap here).")
            resView.setOnClickListener { host.openSettings() }
        } else {
            resView.text = Tx.t("Errore: ", "Error: ") + err
        }
    }

    private fun busy() {
        result = ""
        rebuildButtons()
        resView.setTextColor(th.hint)
        resView.text = "…"
    }

    private fun runTranslate(to: String) {
        if (src.isBlank()) return
        busy()
        var from = Langs.active()
        if (from == to || to.startsWith(from)) from = if (to.startsWith("en")) "it" else "en"
        Translator.translate(src, from, to, { showResult(it) }, { fail(it) })
    }

    private fun runAi(system: String, text: String) {
        if (text.isBlank()) return
        busy()
        Ai.run(system, text, { showResult(it) }, { fail(it) })
    }
}

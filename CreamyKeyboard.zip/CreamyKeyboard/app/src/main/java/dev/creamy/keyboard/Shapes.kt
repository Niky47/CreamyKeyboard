package dev.creamy.keyboard

import android.graphics.Path
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Material 3 Expressive style shapes (cookie / wavy / flower / clover / sunny / burst ...).
 * Every shape is a polar radius profile sampled at N angles, so any two shapes can be
 * morphed by interpolating the radii.
 */
object Shapes {
    private const val N = 96

    val ids = listOf(
        "wavy", "circle", "squircle", "cookie4", "cookie6", "cookie7", "cookie9", "cookie12",
        "flower5", "flower6", "flower8", "clover4", "sunny8", "sunny12", "burst10",
        "pentagon", "gem", "diamond"
    )

    private val cache = HashMap<String, FloatArray>()
    private val sx = FloatArray(N)
    private val sy = FloatArray(N)

    fun isPolar(id: String): Boolean = id != "pill" && id != "round" && id != "square"

    /** Radii profile for [id], or null for rectangular shapes (pill / round / square). */
    fun resolve(id: String, waves: Int, amp: Float): FloatArray? {
        if (!isPolar(id)) return null
        return if (id == "wavy") wavy(waves, amp) else cache.getOrPut(id) { build(id) }
    }

    fun wavy(n: Int, amp: Float): FloatArray = cache.getOrPut("wavy$n/$amp") {
        val a = FloatArray(N) { i -> (1.0 + amp * cos(n * 2.0 * PI * i / N)).toFloat() }
        norm(a)
    }

    private fun norm(a: FloatArray): FloatArray {
        var m = 0f
        for (v in a) if (v > m) m = v
        if (m > 0f) for (i in a.indices) a[i] = a[i] / m
        return a
    }

    private fun poly(sides: Int, t: Double): Double {
        val seg = 2.0 * PI / sides
        val m = ((t + PI / 2.0) % seg + seg) % seg
        val x = cos(PI / sides) / cos(m - seg / 2.0)
        return 0.62 * x + 0.38
    }

    private fun build(id: String): FloatArray {
        val digits = id.takeLastWhile { it.isDigit() }
        val n = digits.toIntOrNull() ?: 0
        val kind = id.dropLast(digits.length)
        val a = FloatArray(N)
        for (i in 0 until N) {
            val t = 2.0 * PI * i / N
            val r: Double = when (kind) {
                "squircle" -> {
                    val c = abs(cos(t))
                    val s = abs(sin(t))
                    1.0 / (c.pow(4.0) + s.pow(4.0)).pow(0.25)
                }
                "cookie" -> 1.0 + 0.065 * cos(n * t)
                "flower" -> 0.80 + 0.20 * abs(cos(n * t / 2.0))
                "clover" -> 0.58 + 0.42 * abs(cos(n * t / 2.0)).pow(0.9)
                "sunny" -> 0.80 + 0.20 * ((1.0 + cos(n * t)) / 2.0).pow(0.6)
                "burst" -> 0.74 + 0.26 * ((1.0 + cos(n * t)) / 2.0).pow(1.4)
                "pentagon" -> poly(5, t)
                "gem" -> poly(6, t)
                "diamond" -> poly(4, t)
                else -> 1.0
            }
            a[i] = r.toFloat()
        }
        return norm(a)
    }

    /** Fills [path] with the shape inscribed in an ellipse (cx, cy, rx, ry) rotated by [rot] radians. */
    fun fill(path: Path, r: FloatArray, cx: Float, cy: Float, rx: Float, ry: Float, rot: Float) {
        path.rewind()
        val n = min(r.size, N)
        for (i in 0 until n) {
            val t = 2.0 * PI * i / n + rot - PI / 2.0
            sx[i] = (cx + rx * r[i] * cos(t)).toFloat()
            sy[i] = (cy + ry * r[i] * sin(t)).toFloat()
        }
        path.moveTo((sx[n - 1] + sx[0]) / 2f, (sy[n - 1] + sy[0]) / 2f)
        for (i in 0 until n) {
            val j = if (i + 1 == n) 0 else i + 1
            path.quadTo(sx[i], sy[i], (sx[i] + sx[j]) / 2f, (sy[i] + sy[j]) / 2f)
        }
        path.close()
    }
}

/** Damped spring (mass 1). [z] is the damping ratio: < 1 overshoots ("jelly"). */
class Spring(var value: Float = 0f, var target: Float = 0f, private val k: Float = 650f, private val z: Float = 0.55f) {
    var v = 0f
    private val c = 2f * sqrt(k) * z

    fun settled(): Boolean = abs(value - target) < 0.002f && abs(v) < 0.01f

    fun step(dt: Float) {
        var left = dt
        while (left > 0f) {
            val h = if (left < 1f / 240f) left else 1f / 240f
            val a = -k * (value - target) - c * v
            v += a * h
            value += v * h
            left -= h
        }
        if (settled()) {
            value = target
            v = 0f
        }
    }
}

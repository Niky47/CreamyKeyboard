package dev.creamy.keyboard

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface

/** Rounded-stroke icons drawn on a 24x24 grid scaled to the requested size. */
object KbIcons {
    const val BACKSPACE = 1
    const val SHIFT = 2
    const val SHIFT_ON = 3
    const val CAPS = 4
    const val ENTER = 5
    const val SEND = 6
    const val SEARCH = 7
    const val GO = 8
    const val NEXT = 9
    const val DONE = 10
    const val GLOBE = 11
    const val EMOJI = 12
    const val CLIPBOARD = 13
    const val MIC = 14
    const val SETTINGS = 15
    const val GIF = 16
    const val TRANSLATE = 17
    const val AI = 18
    const val ONEHAND = 19
    const val RESIZE = 20
    const val INCOGNITO = 21
    const val PIN = 22
    const val CLOSE = 23
    const val CHEV_L = 24
    const val CHEV_R = 25
    const val CHEV_D = 26
    const val CHEV_U = 27
    const val PLUS = 28
    const val STICKER = 29
    const val THEME = 30
    const val EXPAND = 31
    const val SWAP = 32
    const val MENU = 33

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rect = RectF()

    fun draw(c: Canvas, id: Int, cx: Float, cy: Float, size: Float, color: Int) {
        val s = size / 24f
        val ox = cx - 12f * s
        val oy = cy - 12f * s
        p.color = color
        p.strokeWidth = 2f * s
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        p.style = Paint.Style.STROKE
        p.textAlign = Paint.Align.LEFT

        fun px(v: Float): Float = ox + v * s
        fun py(v: Float): Float = oy + v * s
        fun line(x1: Float, y1: Float, x2: Float, y2: Float) {
            c.drawLine(px(x1), py(y1), px(x2), py(y2), p)
        }
        fun poly(close: Boolean, vararg v: Float) {
            path.rewind()
            path.moveTo(px(v[0]), py(v[1]))
            var i = 2
            while (i + 1 < v.size) {
                path.lineTo(px(v[i]), py(v[i + 1]))
                i += 2
            }
            if (close) path.close()
            c.drawPath(path, p)
        }
        fun rrect(l: Float, t: Float, r: Float, b: Float, rad: Float) {
            rect.set(px(l), py(t), px(r), py(b))
            c.drawRoundRect(rect, rad * s, rad * s, p)
        }
        fun circle(x: Float, y: Float, r: Float) {
            c.drawCircle(px(x), py(y), r * s, p)
        }
        fun sparkle(x: Float, y: Float, r: Float) {
            val q = r * 0.14f
            path.rewind()
            path.moveTo(px(x), py(y - r))
            path.quadTo(px(x + q), py(y - q), px(x + r), py(y))
            path.quadTo(px(x + q), py(y + q), px(x), py(y + r))
            path.quadTo(px(x - q), py(y + q), px(x - r), py(y))
            path.quadTo(px(x - q), py(y - q), px(x), py(y - r))
            path.close()
            c.drawPath(path, p)
        }

        when (id) {
            BACKSPACE -> {
                path.rewind()
                path.moveTo(px(9f), py(5f))
                path.lineTo(px(20f), py(5f))
                path.quadTo(px(22f), py(5f), px(22f), py(7f))
                path.lineTo(px(22f), py(17f))
                path.quadTo(px(22f), py(19f), px(20f), py(19f))
                path.lineTo(px(9f), py(19f))
                path.lineTo(px(2f), py(12f))
                path.close()
                c.drawPath(path, p)
                line(12.5f, 9.5f, 17.5f, 14.5f)
                line(17.5f, 9.5f, 12.5f, 14.5f)
            }
            SHIFT -> poly(true, 12f, 3.5f, 3.5f, 12.5f, 8.5f, 12.5f, 8.5f, 19.5f, 15.5f, 19.5f, 15.5f, 12.5f, 20.5f, 12.5f)
            SHIFT_ON, CAPS -> {
                p.style = Paint.Style.FILL_AND_STROKE
                poly(true, 12f, 3.5f, 3.5f, 12.5f, 8.5f, 12.5f, 8.5f, 19.5f, 15.5f, 19.5f, 15.5f, 12.5f, 20.5f, 12.5f)
                if (id == CAPS) {
                    p.style = Paint.Style.STROKE
                    line(8.5f, 22.5f, 15.5f, 22.5f)
                }
            }
            ENTER -> {
                poly(false, 20f, 5f, 20f, 11f, 18f, 13f, 5f, 13f)
                poly(false, 9f, 8.5f, 4.5f, 13f, 9f, 17.5f)
            }
            SEND -> {
                p.style = Paint.Style.FILL_AND_STROKE
                poly(true, 3.5f, 19.5f, 20.5f, 12f, 3.5f, 4.5f, 3.5f, 10f, 14f, 12f, 3.5f, 14f)
            }
            SEARCH -> {
                circle(10.5f, 10.5f, 6.5f)
                line(15.5f, 15.5f, 21f, 21f)
            }
            GO, NEXT -> {
                line(4f, 12f, 20f, 12f)
                poly(false, 13f, 5f, 20f, 12f, 13f, 19f)
            }
            DONE -> poly(false, 4.5f, 12.5f, 9.5f, 17.5f, 19.5f, 6.5f)
            GLOBE -> {
                circle(12f, 12f, 9f)
                rect.set(px(8f), py(3f), px(16f), py(21f))
                c.drawOval(rect, p)
                line(3f, 12f, 21f, 12f)
                line(4.8f, 7.5f, 19.2f, 7.5f)
                line(4.8f, 16.5f, 19.2f, 16.5f)
            }
            EMOJI -> {
                circle(12f, 12f, 9f)
                p.style = Paint.Style.FILL
                circle(9f, 10f, 1.3f)
                circle(15f, 10f, 1.3f)
                p.style = Paint.Style.STROKE
                rect.set(px(7f), py(7f), px(17f), py(17f))
                c.drawArc(rect, 25f, 130f, false, p)
            }
            CLIPBOARD -> {
                rrect(5f, 4.5f, 19f, 21f, 2f)
                rrect(9f, 2.5f, 15f, 6.5f, 1.5f)
                line(8.5f, 11f, 15.5f, 11f)
                line(8.5f, 15f, 15.5f, 15f)
            }
            MIC -> {
                rrect(9f, 3f, 15f, 14f, 3f)
                rect.set(px(6f), py(7f), px(18f), py(19f))
                c.drawArc(rect, 0f, 180f, false, p)
                line(12f, 19f, 12f, 22f)
                line(9f, 22f, 15f, 22f)
            }
            SETTINGS -> {
                line(3f, 6f, 7.5f, 6f); circle(10f, 6f, 2.5f); line(12.5f, 6f, 21f, 6f)
                line(3f, 12f, 13f, 12f); circle(15.5f, 12f, 2.5f); line(18f, 12f, 21f, 12f)
                line(3f, 18f, 5.5f, 18f); circle(8f, 18f, 2.5f); line(10.5f, 18f, 21f, 18f)
            }
            GIF -> {
                rrect(2.5f, 6f, 21.5f, 18f, 3f)
                p.style = Paint.Style.FILL
                p.textAlign = Paint.Align.CENTER
                p.typeface = Typeface.DEFAULT_BOLD
                p.textSize = 7.2f * s
                c.drawText("GIF", px(12f), py(14.5f), p)
            }
            TRANSLATE -> {
                p.style = Paint.Style.FILL
                p.textAlign = Paint.Align.CENTER
                p.typeface = Typeface.DEFAULT_BOLD
                p.textSize = 11f * s
                c.drawText("文", px(8f), py(11f), p)
                c.drawText("A", px(16f), py(19f), p)
            }
            AI -> {
                p.style = Paint.Style.FILL
                sparkle(10.5f, 13f, 8f)
                sparkle(19f, 5f, 3.4f)
                sparkle(19f, 19f, 2.8f)
            }
            ONEHAND -> {
                rrect(7f, 2.5f, 17f, 21.5f, 2.5f)
                poly(false, 11f, 9f, 14f, 12f, 11f, 15f)
            }
            RESIZE -> {
                line(12f, 4f, 12f, 20f)
                poly(false, 8f, 8f, 12f, 4f, 16f, 8f)
                poly(false, 8f, 16f, 12f, 20f, 16f, 16f)
            }
            INCOGNITO -> {
                line(3.5f, 11f, 20.5f, 11f)
                poly(false, 6f, 11f, 8f, 4.5f, 16f, 4.5f, 18f, 11f)
                circle(8f, 16.5f, 2.8f)
                circle(16f, 16.5f, 2.8f)
                line(10.8f, 16f, 13.2f, 16f)
            }
            PIN -> {
                poly(true, 9f, 3f, 15f, 3f, 14f, 10f, 18f, 14f, 6f, 14f, 10f, 10f)
                line(12f, 14f, 12f, 21f)
            }
            CLOSE -> {
                line(6f, 6f, 18f, 18f)
                line(18f, 6f, 6f, 18f)
            }
            CHEV_L -> poly(false, 15f, 5f, 8f, 12f, 15f, 19f)
            CHEV_R -> poly(false, 9f, 5f, 16f, 12f, 9f, 19f)
            CHEV_D -> poly(false, 5f, 9f, 12f, 16f, 19f, 9f)
            CHEV_U -> poly(false, 5f, 15f, 12f, 8f, 19f, 15f)
            PLUS -> {
                line(12f, 5f, 12f, 19f)
                line(5f, 12f, 19f, 12f)
            }
            STICKER -> {
                rrect(3f, 3f, 21f, 21f, 5f)
                poly(false, 14f, 21f, 14f, 16.5f, 16.5f, 14f, 21f, 14f)
            }
            THEME -> {
                circle(12f, 12f, 9f)
                p.style = Paint.Style.FILL
                circle(8f, 10f, 1.4f)
                circle(12f, 7.5f, 1.4f)
                circle(16f, 10f, 1.4f)
                circle(9f, 15f, 1.4f)
            }
            EXPAND -> {
                poly(false, 8f, 3.5f, 3.5f, 3.5f, 3.5f, 8f)
                poly(false, 16f, 3.5f, 20.5f, 3.5f, 20.5f, 8f)
                poly(false, 8f, 20.5f, 3.5f, 20.5f, 3.5f, 16f)
                poly(false, 16f, 20.5f, 20.5f, 20.5f, 20.5f, 16f)
            }
            SWAP -> {
                line(4f, 9f, 20f, 9f)
                poly(false, 16f, 5f, 20f, 9f, 16f, 13f)
                line(20f, 16f, 4f, 16f)
                poly(false, 8f, 12f, 4f, 16f, 8f, 20f)
            }
            MENU -> {
                p.style = Paint.Style.FILL
                circle(8f, 8f, 2.2f)
                circle(16f, 8f, 2.2f)
                circle(8f, 16f, 2.2f)
                circle(16f, 16f, 2.2f)
            }
        }
        p.style = Paint.Style.STROKE
    }
}

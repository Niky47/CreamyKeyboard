package dev.creamy.keyboard

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color as AColor
import android.graphics.Paint as APaint
import android.graphics.Path as APath
import android.graphics.RectF
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File
import java.io.FileOutputStream

class MainActivity : ComponentActivity() {
    private var resumeTick by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.init(this)
        enableEdgeToEdge()
        if (intent?.getBooleanExtra("ask_mic", false) == true) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 7)
        }
        setContent { CreamyApp(resumeTick) }
    }

    override fun onResume() {
        super.onResume()
        resumeTick++
    }
}

@Composable
fun CreamyApp(resume: Int) {
    val dark = isSystemInDarkTheme()
    val ctx = LocalContext.current
    val scheme = if (Build.VERSION.SDK_INT >= 31) {
        if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
    } else {
        if (dark) darkColorScheme() else lightColorScheme()
    }
    MaterialTheme(colorScheme = scheme) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            SettingsScreen(resume)
        }
    }
}

// ------------------------------------------------------------------ building blocks

@Composable
fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
        Text(
            title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(start = 14.dp, bottom = 8.dp)
        )
        Surface(
            shape = RoundedCornerShape(28.dp), color = MaterialTheme.colorScheme.surfaceContainer,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(vertical = 8.dp), content = content)
        }
    }
}

@Composable
fun SwitchRow(title: String, sub: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(horizontal = 20.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            if (sub != null) {
                Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
fun SwitchPref(title: String, p: BoolP, sub: String? = null, bump: () -> Unit = {}) {
    var v by remember { mutableStateOf(p.get()) }
    SwitchRow(title, sub, v) {
        v = it
        p.set(it)
        bump()
    }
}

@Composable
fun SliderRow(title: String, value: Float, range: ClosedFloatingPointRange<Float>, label: String, steps: Int, onChange: (Float) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 4.dp)) {
        Row(Modifier.fillMaxWidth()) {
            Text(title, Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
            Text(label, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
        }
        Slider(value = value, onValueChange = onChange, valueRange = range, steps = steps)
    }
}

@Composable
fun FloatPref(title: String, p: FloatP, range: ClosedFloatingPointRange<Float>, unit: String = "", decimals: Int = 0, bump: () -> Unit = {}) {
    var v by remember { mutableStateOf(p.get()) }
    val label = if (decimals == 0) "%.0f".format(v) + unit else "%.2f".format(v) + unit
    SliderRow(title, v, range, label, 0) {
        v = it
        p.set(it)
        bump()
    }
}

@Composable
fun IntPref(title: String, p: IntP, range: IntRange, unit: String = "", bump: () -> Unit = {}) {
    var v by remember { mutableStateOf(p.get()) }
    SliderRow(title, v.toFloat(), range.first.toFloat()..range.last.toFloat(), "$v$unit", 0) {
        v = it.toInt()
        p.set(it.toInt())
        bump()
    }
}

@Composable
fun ChipsRow(title: String, options: List<Pair<String, String>>, selected: String, onSelect: (String) -> Unit) {
    Column(Modifier.padding(horizontal = 20.dp, vertical = 6.dp)) {
        Text(title, style = MaterialTheme.typography.bodyLarge)
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(top = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            for ((id, name) in options) {
                FilterChip(selected = id == selected, onClick = { onSelect(id) }, label = { Text(name) })
            }
        }
    }
}

@Composable
fun ChipsPref(title: String, p: StrP, options: List<Pair<String, String>>, bump: () -> Unit = {}) {
    var v by remember { mutableStateOf(p.get()) }
    ChipsRow(title, options, v) {
        v = it
        p.set(it)
        bump()
    }
}

@Composable
fun TextPref(title: String, p: StrP, secret: Boolean = false, minLines: Int = 1) {
    var v by remember { mutableStateOf(p.get()) }
    OutlinedTextField(
        value = v,
        onValueChange = {
            v = it
            p.set(it)
        },
        label = { Text(title) },
        singleLine = minLines == 1,
        minLines = minLines,
        visualTransformation = if (secret) PasswordVisualTransformation() else VisualTransformation.None,
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)
    )
}

@Composable
fun Note(text: String) {
    Text(
        text, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp)
    )
}

// ------------------------------------------------------------------ live preview (same drawing code as the keyboard)

@Composable
fun KeyboardPreview(th: KbTheme, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        drawIntoCanvas { c ->
            val nc = c.nativeCanvas
            val d = density
            val w = size.width
            val h = size.height
            val p = APaint(APaint.ANTI_ALIAS_FLAG)
            val r = RectF()
            val path = APath()
            p.style = APaint.Style.FILL
            p.color = if (th.bgBitmap != null) th.panel else th.bg
            r.set(0f, 0f, w, h)
            nc.drawRoundRect(r, 26f * d, 26f * d, p)

            val pad = 10f * d
            val gap = 5f * d
            val rowH = (h - 2f * pad - 2f * gap) / 3f
            val tf = Typeface.create("sans-serif-medium", Typeface.BOLD)
            val rows = listOf("qwertyu", "asdfg", "zxcv")
            for ((ri, row) in rows.withIndex()) {
                val top = pad + ri * (rowH + gap)
                val keysN = if (ri == 0) 7 else 7
                val kw = (w - 2f * pad - gap * (keysN - 1)) / keysN
                var x = pad
                val cells = ArrayList<String>()
                if (ri == 2) cells.add("<shift>")
                for (ch in row) cells.add(ch.toString())
                if (ri == 1) cells.add("<enter>")
                if (ri == 2) cells.add("<del>")
                for (cell in cells) {
                    var cw = kw
                    if (cell == "<shift>" || cell == "<del>") cw = kw * 1.5f
                    if (cell == "<enter>") cw = kw * 2f + gap
                    if (ri == 1 && cell != "<enter>") cw = kw
                    r.set(x, top, x + cw, top + rowH)
                    when (cell) {
                        "<enter>" -> {
                            val radii = Shapes.resolve(th.enterShape, th.waves, th.amp)
                            p.color = th.accent
                            if (radii != null) {
                                val half = minOf(cw, rowH * 1.5f) / 2f
                                Shapes.fill(path, radii, r.centerX(), r.centerY(), half, rowH / 2f, 0f)
                                nc.drawPath(path, p)
                            } else {
                                val rad = if (th.enterShape == "pill") rowH / 2f else th.radius * d
                                nc.drawRoundRect(r, rad, rad, p)
                            }
                            KbIcons.draw(nc, KbIcons.ENTER, r.centerX(), r.centerY(), rowH * 0.44f, th.accentText)
                        }
                        "<shift>", "<del>" -> {
                            p.color = th.func
                            val rad = when (th.funcShape) {
                                "pill" -> rowH / 2f
                                "square" -> 4f * d
                                else -> th.radius * d
                            }
                            nc.drawRoundRect(r, rad, rad, p)
                            KbIcons.draw(
                                nc, if (cell == "<shift>") KbIcons.SHIFT else KbIcons.BACKSPACE,
                                r.centerX(), r.centerY(), rowH * 0.44f, th.funcText
                            )
                        }
                        else -> {
                            p.color = th.key
                            nc.drawRoundRect(r, th.radius * d, th.radius * d, p)
                            p.color = th.keyText
                            p.typeface = tf
                            p.textAlign = APaint.Align.CENTER
                            p.textSize = rowH * 0.4f * th.labelScale
                            val fm = p.fontMetrics
                            nc.drawText(cell, r.centerX(), r.centerY() - (fm.ascent + fm.descent) / 2f, p)
                        }
                    }
                    x += cw + gap
                }
            }
        }
    }
}

// ------------------------------------------------------------------ screen

@Composable
fun SettingsScreen(resume: Int) {
    val ctx = LocalContext.current
    var look by remember { mutableIntStateOf(0) }
    Column(
        Modifier.fillMaxSize().systemBarsPadding().imePadding().verticalScroll(rememberScrollState())
    ) {
        Text(
            "Creamy Keyboard", fontSize = 34.sp, fontWeight = FontWeight.ExtraBold,
            color = MaterialTheme.colorScheme.onBackground, modifier = Modifier.padding(start = 24.dp, top = 24.dp)
        )
        Text(
            Tx.t("Look Material 3 Expressive · suoni da switch meccanico · funzioni stile SwiftKey",
                "Material 3 Expressive look · mechanical switch sounds · SwiftKey-style features"),
            style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(start = 24.dp, end = 24.dp, bottom = 8.dp, top = 4.dp)
        )
        SetupSection(resume)
        TypingSection()
        LanguagesSection()
        LookSection(look) { look++ }
        SoundSection()
        ToolbarSection()
        ClipboardSection()
        ShortcutsSection()
        OnlineSection()
        PrivacySection(resume)
        AboutSection()
        Spacer(Modifier.height(40.dp))
    }
}

@Composable
fun SetupSection(resume: Int) {
    val ctx = LocalContext.current
    val imm = ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
    val enabled = remember(resume) { imm.enabledInputMethodList.any { it.packageName == ctx.packageName } }
    val selected = remember(resume) {
        (Settings.Secure.getString(ctx.contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD) ?: "").startsWith(ctx.packageName)
    }
    val micOk = remember(resume) { ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED }
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    var test by remember { mutableStateOf("") }

    Section(Tx.t("Configurazione", "Setup")) {
        SetupRow("1", Tx.t("Attiva la tastiera", "Enable the keyboard"), enabled, Tx.t("Attiva", "Enable")) {
            ctx.startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        SetupRow("2", Tx.t("Scegli Creamy Keyboard", "Choose Creamy Keyboard"), selected, Tx.t("Scegli", "Choose")) {
            imm.showInputMethodPicker()
        }
        SetupRow("3", Tx.t("Microfono per la dettatura", "Microphone for voice typing"), micOk, Tx.t("Consenti", "Allow")) {
            micLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
        OutlinedTextField(
            value = test, onValueChange = { test = it },
            label = { Text(Tx.t("Prova la tastiera qui", "Try the keyboard here")) },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)
        )
    }
}

@Composable
fun SetupRow(n: String, title: String, done: Boolean, action: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(
            if (done) "✓" else n, fontWeight = FontWeight.Bold, fontSize = 20.sp,
            color = if (done) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(end = 14.dp)
        )
        Text(title, Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
        if (done) {
            TextButton(onClick = onClick) { Text(action) }
        } else {
            Button(onClick = onClick) { Text(action) }
        }
    }
}

@Composable
fun TypingSection() {
    Section(Tx.t("Scrittura", "Typing")) {
        SwitchPref(Tx.t("Suggerimenti", "Suggestions"), P.SUGGEST)
        SwitchPref(Tx.t("Autocorrezione", "Autocorrect"), P.AUTOCORRECT, Tx.t("Premi backspace subito dopo per annullare", "Press backspace right after to undo"))
        SwitchPref(Tx.t("Previsione parola successiva", "Next-word prediction"), P.NEXTWORD)
        SwitchPref(Tx.t("Previsione emoji", "Emoji prediction"), P.EMOJI_PRED)
        SwitchPref(Tx.t("Maiuscola automatica", "Auto-capitalise"), P.AUTOCAP)
        SwitchPref(Tx.t("Doppio spazio = punto", "Double space = full stop"), P.DBLSPACE)
        SwitchPref(Tx.t("Scrittura a scorrimento (Flow)", "Swipe typing (Flow)"), P.GLIDE)
        SwitchPref(Tx.t("Scia colorata durante lo swipe", "Swipe trail"), P.TRAIL)
        SwitchPref(Tx.t("Cursore con la barra spaziatrice", "Space-bar cursor control"), P.SPACE_CURSOR, Tx.t("Scorri sulla barra spaziatrice", "Slide across the space bar"))
        SwitchPref(Tx.t("Scorri su cancella per eliminare parole", "Swipe on backspace to delete words"), P.BACK_SWIPE)
        SwitchPref(Tx.t("Anteprima tasto", "Key preview"), P.PREVIEW)
        SwitchPref(Tx.t("Suggerimenti dei tasti (numeri)", "Key hints (numbers)"), P.HINTS)
        SwitchPref(Tx.t("Riga dei numeri", "Number row"), P.NUMBER_ROW)
        IntPref(Tx.t("Durata pressione lunga", "Long-press delay"), P.LONGPRESS, 200..700, " ms")
        SwitchPref(Tx.t("Impara da quello che scrivi", "Learn from what you type"), P.LEARN)
    }
}

@Composable
fun LanguagesSection() {
    var sel by remember { mutableStateOf(Langs.enabled()) }
    Section(Tx.t("Lingue e layout", "Languages & layout")) {
        Column(Modifier.padding(horizontal = 20.dp, vertical = 6.dp)) {
            Text(Tx.t("Lingue attive (fino a 5, le previsioni le usano insieme)", "Active languages (up to 5, predictions use them together)"), style = MaterialTheme.typography.bodyLarge)
            Row(
                Modifier.horizontalScroll(rememberScrollState()).padding(top = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                for (l in Langs.all) {
                    FilterChip(
                        selected = sel.contains(l.id),
                        onClick = {
                            val n = if (sel.contains(l.id)) {
                                if (sel.size > 1) sel - l.id else sel
                            } else if (sel.size < 5) {
                                sel + l.id
                            } else {
                                sel
                            }
                            sel = n
                            P.LANGS.set(n.joinToString(","))
                            if (!n.contains(P.ACTIVE.get())) P.ACTIVE.set(n[0])
                        },
                        label = { Text(l.name) }
                    )
                }
            }
        }
        ChipsPref(
            Tx.t("Disposizione tasti", "Key layout"), P.LAYOUT,
            listOf("auto" to "Auto", "qwerty" to "QWERTY", "qwertz" to "QWERTZ", "azerty" to "AZERTY", "colemak" to "Colemak", "dvorak" to "Dvorak")
        )
        Note(Tx.t("Tieni premuta la barra spaziatrice per cambiare lingua.", "Long-press the space bar to switch language."))
    }
}

@Composable
fun LookSection(tick: Int, bump: () -> Unit) {
    val ctx = LocalContext.current
    val th = remember(tick) { Themes.build(ctx) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            try {
                val f = File(ctx.filesDir, "bg_" + System.currentTimeMillis() + ".jpg")
                ctx.contentResolver.openInputStream(uri)?.use { input -> FileOutputStream(f).use { out -> input.copyTo(out) } }
                File(P.BG_IMAGE.get()).delete()
                P.BG_IMAGE.set(f.absolutePath)
                bump()
            } catch (e: Exception) {
                // ignore unreadable image
            }
        }
    }
    var hue by remember { mutableStateOf(seedHue()) }
    var sat by remember { mutableStateOf(0.55f) }

    Section(Tx.t("Aspetto (Material 3 Expressive)", "Look (Material 3 Expressive)")) {
        KeyboardPreview(th, Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp).height(168.dp))
        ChipsPref(
            Tx.t("Tema", "Theme"), P.THEME,
            Themes.PRESETS.map { it.id to (if (it.id == "you") Tx.t("Material You (sfondo)", "Material You (wallpaper)") else if (it.id == "custom") Tx.t("Personalizzato", "Custom") else it.name) },
            bump
        )
        ChipsPref(
            Tx.t("Chiaro / scuro", "Light / dark"), P.DARK,
            listOf("system" to Tx.t("Sistema", "System"), "light" to Tx.t("Chiaro", "Light"), "dark" to Tx.t("Scuro", "Dark"), "amoled" to "AMOLED"),
            bump
        )
        SliderRow(Tx.t("Colore personalizzato · tonalità", "Custom colour · hue"), hue, 0f..360f, "${hue.toInt()}°", 0) {
            hue = it
            P.SEED.set(AColor.HSVToColor(floatArrayOf(hue, sat, 0.85f)))
            P.THEME.set("custom")
            bump()
        }
        SliderRow(Tx.t("Colore personalizzato · intensità", "Custom colour · saturation"), sat, 0.2f..0.95f, "%.2f".format(sat), 0) {
            sat = it
            P.SEED.set(AColor.HSVToColor(floatArrayOf(hue, sat, 0.85f)))
            P.THEME.set("custom")
            bump()
        }
        ChipsPref(
            Tx.t("Forma del tasto Invio", "Enter key shape"), P.ENTER_SHAPE,
            Shapes.ids.map { it to it } + listOf("pill" to "pill", "round" to "round", "square" to "square"),
            bump
        )
        ChipsPref(
            Tx.t("Forma di tasti funzione e spazio", "Function / space key shape"), P.FUNC_SHAPE,
            listOf("pill" to "Pill", "round" to Tx.t("Arrotondati", "Rounded"), "square" to Tx.t("Squadrati", "Square")),
            bump
        )
        IntPref(Tx.t("Onde della forma (cookie)", "Shape waves (cookie)"), P.WAVES, 5..14, "", bump)
        FloatPref(Tx.t("Ampiezza delle onde", "Wave amplitude"), P.WAVE_AMP, 0f..0.2f, "", 2, bump)
        ChipsPref(
            Tx.t("Animazione pressione", "Press animation"), P.PRESS,
            listOf("jelly" to "Jelly", "scale" to "Scale", "sink" to "Sink", "none" to Tx.t("Nessuna", "None")),
            bump
        )
        FloatPref(Tx.t("Altezza tasti", "Key height"), P.KEY_H, 40f..72f, " dp", 0, bump)
        FloatPref(Tx.t("Spazio tra i tasti", "Key gap"), P.KEY_GAP, 1f..10f, " dp", 0, bump)
        FloatPref(Tx.t("Spazio tra le righe", "Row gap"), P.ROW_GAP, 1f..12f, " dp", 0, bump)
        FloatPref(Tx.t("Arrotondamento tasti", "Key corner radius"), P.RADIUS, 2f..28f, " dp", 0, bump)
        FloatPref(Tx.t("Dimensione etichette", "Label size"), P.LABEL_SCALE, 0.8f..1.3f, "×", 2, bump)
        FloatPref(Tx.t("Altezza generale (ridimensiona)", "Overall height (resize)"), P.SIZE, 0.7f..1.4f, "×", 2, bump)
        SwitchPref(Tx.t("Etichette in grassetto", "Bold labels"), P.BOLD, null, bump)
        SwitchPref(Tx.t("Bordi sui tasti", "Key borders"), P.BORDERS, null, bump)
        ChipsPref(
            Tx.t("Modalità una mano", "One-handed mode"), P.ONE_HAND,
            listOf("off" to Tx.t("Off", "Off"), "left" to Tx.t("Sinistra", "Left"), "right" to Tx.t("Destra", "Right")),
            bump
        )
        FloatPref(Tx.t("Larghezza in modalità una mano", "One-handed width"), P.ONE_HAND_W, 0.6f..0.95f, "", 2, bump)
        Row(Modifier.padding(horizontal = 16.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilledTonalButton(onClick = { picker.launch("image/*") }) { Text(Tx.t("Foto come sfondo", "Photo background")) }
            if (P.BG_IMAGE.get().isNotEmpty()) {
                TextButton(onClick = {
                    File(P.BG_IMAGE.get()).delete()
                    P.BG_IMAGE.set("")
                    bump()
                }) { Text(Tx.t("Rimuovi foto", "Remove photo")) }
            }
        }
        FloatPref(Tx.t("Oscuramento della foto", "Photo dimming"), P.BG_DIM, 0f..0.8f, "", 2, bump)
    }
}

fun seedHue(): Float {
    val hsv = FloatArray(3)
    AColor.colorToHSV(P.SEED.get(), hsv)
    return hsv[0]
}

@Composable
fun SoundSection() {
    val ctx = LocalContext.current
    val engine = remember { SoundEngine(ctx) }
    DisposableEffect(Unit) { onDispose { engine.release() } }
    Section(Tx.t("Suoni e vibrazione", "Sound & haptics")) {
        SwitchPref(Tx.t("Suono dei tasti (switch meccanici)", "Key sounds (mechanical switches)"), P.SOUND)
        ChipsPref(
            Tx.t("Profilo del suono", "Sound profile"), P.PROFILE,
            listOf("creamy" to "Creamy", "thock" to "Deep Thock", "linear" to "Soft Linear")
        ) { engine.warmUp() }
        IntPref(Tx.t("Volume", "Volume"), P.VOLUME, 0..100, "%")
        SwitchPref(Tx.t("Suono anche al rilascio del tasto", "Also play on key release"), P.SOUND_UP)
        SwitchPref(Tx.t("Muto in modalità silenziosa", "Mute in silent mode"), P.MUTE_SILENT)
        Row(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
            FilledTonalButton(onClick = {
                engine.warmUp()
                engine.play(KType.LETTER, true)
                Handler(Looper.getMainLooper()).postDelayed({ engine.play(KType.LETTER, false) }, 90L)
            }) { Text(Tx.t("Prova il suono", "Test the sound")) }
        }
        ChipsRowInt(
            Tx.t("Intensità vibrazione", "Vibration strength"), P.HAPTIC,
            listOf(0 to Tx.t("Off", "Off"), 1 to Tx.t("Leggera", "Light"), 2 to Tx.t("Media", "Medium"), 3 to Tx.t("Forte", "Strong"))
        )
    }
}

@Composable
fun ChipsRowInt(title: String, p: IntP, options: List<Pair<Int, String>>) {
    var v by remember { mutableStateOf(p.get()) }
    ChipsRow(title, options.map { it.first.toString() to it.second }, v.toString()) {
        v = it.toInt()
        p.set(v)
    }
}

@Composable
fun ToolbarSection() {
    var visible by remember { mutableStateOf(P.TOOLS.get().split(",").map { it.trim() }.filter { ToolTable.ids.contains(it) }) }
    fun save(l: List<String>) {
        visible = l
        P.TOOLS.set(l.joinToString(","))
    }
    Section(Tx.t("Barra degli strumenti", "Toolbar")) {
        Note(Tx.t("Tocca il pulsante a griglia sopra la tastiera per aprire gli strumenti. Attiva, disattiva e riordina.", "Tap the grid button above the keys to open the tools. Turn them on/off and reorder."))
        for ((i, id) in visible.withIndex()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(ToolTable.def(id)?.label ?: id, Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
                TextButton(onClick = {
                    if (i > 0) {
                        val l = visible.toMutableList()
                        l[i] = l[i - 1]
                        l[i - 1] = id
                        save(l)
                    }
                }) { Text("▲") }
                TextButton(onClick = {
                    if (i < visible.size - 1) {
                        val l = visible.toMutableList()
                        l[i] = l[i + 1]
                        l[i + 1] = id
                        save(l)
                    }
                }) { Text("▼") }
                Switch(checked = true, onCheckedChange = { save(visible - id) })
            }
        }
        for (id in ToolTable.ids.filter { !visible.contains(it) }) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(ToolTable.def(id)?.label ?: id, Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Switch(checked = false, onCheckedChange = { save(visible + id) })
            }
        }
    }
}

@Composable
fun ClipboardSection() {
    val ctx = LocalContext.current
    Section(Tx.t("Appunti", "Clipboard")) {
        SwitchPref(Tx.t("Cronologia appunti", "Clipboard history"), P.CLIP_ON)
        ChipsRowInt(
            Tx.t("Conserva gli elementi per", "Keep items for"), P.CLIP_TTL,
            listOf(1 to "1 h", 24 to "24 h", 168 to Tx.t("7 giorni", "7 days"), 0 to Tx.t("Sempre", "Forever"))
        )
        Row(Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
            TextButton(onClick = { ClipStore.clearUnpinned(ctx) }) { Text(Tx.t("Svuota (tranne i fissati)", "Clear (except pinned)")) }
        }
    }
}

@Composable
fun ShortcutsSection() {
    Section(Tx.t("Scorciatoie di testo", "Text shortcuts")) {
        Note(Tx.t("Una per riga: scorciatoia=testo. Si espande quando premi spazio.", "One per line: shortcut=text. Expands when you press space."))
        TextPref(Tx.t("Scorciatoie", "Shortcuts"), P.SHORTCUTS, false, 4)
    }
}

@Composable
fun OnlineSection() {
    Section(Tx.t("Servizi online (GIF, traduttore, AI)", "Online services (GIF, translator, AI)")) {
        Note(Tx.t("GIF e sticker usano Giphy: incolla qui la tua chiave API gratuita (developers.giphy.com).", "GIFs and stickers use Giphy: paste your free API key here (developers.giphy.com)."))
        TextPref("Giphy API key", P.GIPHY, true)
        ChipsPref(
            Tx.t("Lingua di destinazione del traduttore", "Translator target language"), P.TR_TARGET,
            Translator.LANGS.map { it to it.uppercase() }
        )
        Note(Tx.t("Assistente AI (riformula, tono, scrivi): usa la tua chiave. Funziona con Anthropic o con qualsiasi API compatibile OpenAI.", "AI assistant (rewrite, tone, compose): uses your own key. Works with Anthropic or any OpenAI-compatible API."))
        ChipsPref(
            Tx.t("Provider AI", "AI provider"), P.AI_PROVIDER,
            listOf("anthropic" to "Anthropic (Claude)", "openai" to Tx.t("Compatibile OpenAI", "OpenAI-compatible"))
        )
        TextPref(Tx.t("Chiave API", "API key"), P.AI_KEY, true)
        TextPref(Tx.t("Modello", "Model"), P.AI_MODEL)
        TextPref(Tx.t("URL base (solo OpenAI-compatibile)", "Base URL (OpenAI-compatible only)"), P.AI_URL)
    }
}

@Composable
fun PrivacySection(resume: Int) {
    val ctx = LocalContext.current
    var confirm by remember { mutableStateOf(false) }
    val dictPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            try {
                val dir = File(ctx.filesDir, "dict")
                dir.mkdirs()
                val f = File(dir, Langs.active() + ".txt")
                ctx.contentResolver.openInputStream(uri)?.use { input -> FileOutputStream(f).use { out -> input.copyTo(out) } }
                P.DICT_VER.set(P.DICT_VER.get() + 1)
            } catch (e: Exception) {
                // ignore
            }
        }
    }
    Section(Tx.t("Privacy e dizionario", "Privacy & dictionary")) {
        SwitchPref(Tx.t("Modalità incognito", "Incognito mode"), P.INCOGNITO, Tx.t("Non impara nulla mentre è attiva", "Nothing is learned while it is on"))
        Row(Modifier.padding(horizontal = 16.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilledTonalButton(onClick = { dictPicker.launch("text/*") }) { Text(Tx.t("Importa dizionario (.txt)", "Import dictionary (.txt)")) }
            TextButton(onClick = { confirm = true }) { Text(Tx.t("Cancella dati appresi", "Clear learned data")) }
        }
        Note(Tx.t("Il dizionario importato vale per la lingua attiva. Formato: parole in ordine di frequenza, oppure \"parola conteggio\" per riga.", "The imported list applies to the active language. Format: words in frequency order, or \"word count\" per line."))
        if (confirm) {
            Row(Modifier.padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(Tx.t("Sicuro? Non si può annullare.", "Sure? This can't be undone."), Modifier.weight(1f))
                TextButton(onClick = { confirm = false }) { Text(Tx.t("No", "No")) }
                Button(onClick = {
                    File(ctx.filesDir, "user_model.tsv").delete()
                    P.CLEAR_VER.set(P.CLEAR_VER.get() + 1)
                    confirm = false
                }) { Text(Tx.t("Cancella", "Clear")) }
            }
        }
        val words = remember(resume) { P.ST_WORDS.get() }
        val corr = remember(resume) { P.ST_CORR.get() }
        val pred = remember(resume) { P.ST_PRED.get() }
        val saved = remember(resume) { P.ST_SAVED.get() }
        val glide = remember(resume) { P.ST_GLIDE.get() }
        val chars = remember(resume) { P.ST_CHARS.get() }
        Text(
            Tx.t("Statistiche", "Statistics"), fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(start = 20.dp, top = 10.dp)
        )
        Note(
            Tx.t(
                "$words parole · $chars caratteri · $corr correzioni · $pred previsioni usate · $saved tasti risparmiati · $glide parole con swipe",
                "$words words · $chars characters · $corr corrections · $pred predictions used · $saved keystrokes saved · $glide swiped words"
            )
        )
    }
}

@Composable
fun AboutSection() {
    Section(Tx.t("Informazioni", "About")) {
        Note(
            Tx.t(
                "Estetica ispirata a Expressive Keyboard (kotlalipopus, licenza MIT) e al linguaggio Material 3 Expressive. Funzioni ispirate a Microsoft SwiftKey. I suoni sono sintetizzati da tools/generate_sounds.py. I servizi cloud Microsoft (account, sincronizzazione, Copilot, To Do) non sono inclusi.",
                "Look inspired by Expressive Keyboard (kotlalipopus, MIT licence) and the Material 3 Expressive design language. Features inspired by Microsoft SwiftKey. Sounds are synthesised by tools/generate_sounds.py. Microsoft cloud services (account, sync, Copilot, To Do) are not included."
            )
        )
    }
}

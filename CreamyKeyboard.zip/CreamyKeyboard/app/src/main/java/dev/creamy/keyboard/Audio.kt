package dev.creamy.keyboard

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.SoundPool
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import java.util.Random

/**
 * Plays the mechanical-switch sounds (res/raw/snd_<profile>_*.wav) with a tiny random pitch
 * variation so repeated keys never sound like a machine gun. Down and up are separate samples.
 */
class SoundEngine(private val ctx: Context) {
    private var pool: SoundPool? = null
    private val ids = HashMap<String, IntArray>()
    private var loaded = ""
    private val rnd = Random()
    private val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    fun warmUp() {
        val prof = P.PROFILE.get()
        if (pool == null || prof != loaded) load(prof)
    }

    private fun load(profile: String) {
        pool?.release()
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        val sp = SoundPool.Builder().setMaxStreams(8).setAudioAttributes(attrs).build()
        ids.clear()

        fun group(key: String, names: List<String>) {
            ids[key] = IntArray(names.size) { i ->
                val rid = ctx.resources.getIdentifier("snd_${profile}_${names[i]}", "raw", ctx.packageName)
                if (rid != 0) sp.load(ctx, rid, 1) else 0
            }
        }
        group("ad", listOf("d1", "d2", "d3", "d4", "d5"))
        group("au", listOf("u1", "u2", "u3"))
        group("sd", listOf("sd1", "sd2"))
        group("su", listOf("su1"))
        group("ed", listOf("ed1"))
        group("eu", listOf("eu1"))
        group("bd", listOf("bd1", "bd2"))
        group("bu", listOf("bu1"))
        group("md", listOf("md1"))
        group("mu", listOf("mu1"))
        pool = sp
        loaded = profile
    }

    fun play(type: KType, down: Boolean) {
        if (!P.SOUND.get()) return
        if (!down && !P.SOUND_UP.get()) return
        if (P.MUTE_SILENT.get() && am.ringerMode != AudioManager.RINGER_MODE_NORMAL) return
        warmUp()
        val base = when (type) {
            KType.SPACE -> "s"
            KType.ENTER -> "e"
            KType.BACKSPACE -> "b"
            KType.SHIFT, KType.MODE, KType.EMOJI, KType.GLOBE -> "m"
            else -> "a"
        }
        val arr = ids[base + (if (down) "d" else "u")] ?: return
        if (arr.isEmpty()) return
        val id = arr[rnd.nextInt(arr.size)]
        if (id == 0) return
        val vol = P.VOLUME.get() / 100f
        val v = vol * vol
        pool?.play(id, v, v, 1, 0, 0.97f + rnd.nextFloat() * 0.06f)
    }

    fun release() {
        pool?.release()
        pool = null
    }
}

class Haptics(ctx: Context) {
    @Suppress("DEPRECATION")
    private val vib: Vibrator? = if (Build.VERSION.SDK_INT >= 31) {
        (ctx.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
    } else {
        ctx.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
    }

    fun tick(release: Boolean = false) {
        val level = P.HAPTIC.get()
        if (level <= 0) return
        val v = vib ?: return
        if (!v.hasVibrator()) return
        val ms = when (level) {
            1 -> 7L
            2 -> 11L
            else -> 16L
        }
        val amp = when (level) {
            1 -> 70
            2 -> 140
            else -> 255
        }
        try {
            if (release) v.vibrate(VibrationEffect.createOneShot(ms / 2, amp / 2))
            else v.vibrate(VibrationEffect.createOneShot(ms, amp))
        } catch (e: Exception) {
            // ignore: vibration is best effort
        }
    }
}

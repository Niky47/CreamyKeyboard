package dev.creamy.keyboard

import java.util.Locale
import kotlin.math.max

object Code {
    const val SHIFT = -1
    const val BACKSPACE = -2
    const val ENTER = -3
    const val SYMBOLS = -4
    const val ABC = -5
    const val SYMBOLS2 = -6
    const val EMOJI = -7
    const val GLOBE = -8
    const val SPACE = 32
}

enum class KType { LETTER, SYMBOL, SHIFT, BACKSPACE, ENTER, SPACE, MODE, EMOJI, GLOBE, SPACER }

class KeyDef(
    val label: String,
    val code: Int,
    val type: KType,
    val weight: Float = 1f,
    val alts: List<String> = emptyList(),
    val altOut: List<String>? = null,
    val hint: String? = null,
    val out: String? = null
)

class KbLayout(val id: String, val rows: List<List<KeyDef>>)

class Lang(
    val id: String,
    val name: String,
    val rows: List<String>,
    val alts: Map<Char, String>,
    val currency: String,
    val elision: Boolean
)

object Langs {
    private val QWERTY = listOf("qwertyuiop", "asdfghjkl", "zxcvbnm")

    val STYLES = listOf("auto", "qwerty", "qwertz", "azerty", "colemak", "dvorak")

    fun styleRows(style: String): List<String>? = when (style) {
        "qwerty" -> QWERTY
        "qwertz" -> listOf("qwertzuiop", "asdfghjkl", "yxcvbnm")
        "azerty" -> listOf("azertyuiop", "qsdfghjklm", "wxcvbn")
        "colemak" -> listOf("qwfpgjluy", "arstdhneio", "zxcvbkm")
        "dvorak" -> listOf("pyfgcrl", "aoeuidhtns", "qjkxbmwvz")
        else -> null
    }

    val all: List<Lang> = listOf(
        Lang(
            "en", "English", QWERTY,
            mapOf(
                'a' to "àáâäæãåā", 'c' to "çćč", 'e' to "èéêëēėę", 'i' to "ìíîïīį", 'l' to "ł",
                'n' to "ñń", 'o' to "òóôöõøœō", 's' to "ßśš", 'u' to "ùúûüū", 'y' to "ýÿ", 'z' to "žźż"
            ),
            "\$", false
        ),
        Lang(
            "it", "Italiano", QWERTY,
            mapOf('a' to "àáâä", 'e' to "èéêë", 'i' to "ìíîï", 'o' to "òóôö", 'u' to "ùúûü", 'c' to "ç", 'n' to "ñ"),
            "€", true
        ),
        Lang(
            "es", "Español", listOf("qwertyuiop", "asdfghjklñ", "zxcvbnm"),
            mapOf('a' to "áàâä", 'e' to "éèêë", 'i' to "íìîï", 'o' to "óòôö", 'u' to "úùûü", 'n' to "ñ"),
            "€", false
        ),
        Lang(
            "fr", "Français", listOf("azertyuiop", "qsdfghjklm", "wxcvbn"),
            mapOf('a' to "àâæáä", 'e' to "éèêëę", 'i' to "îïíì", 'o' to "ôœöòó", 'u' to "ùûüú", 'c' to "ç", 'y' to "ÿ"),
            "€", true
        ),
        Lang(
            "de", "Deutsch", listOf("qwertzuiopü", "asdfghjklöä", "yxcvbnm"),
            mapOf('s' to "ß", 'e' to "éè", 'a' to "áà", 'o' to "óò", 'u' to "úù"),
            "€", false
        ),
        Lang(
            "pt", "Português", QWERTY,
            mapOf('a' to "áàâãä", 'e' to "éêèë", 'i' to "íìî", 'o' to "óôõòö", 'u' to "úùü", 'c' to "ç"),
            "€", false
        )
    )

    fun get(id: String): Lang = all.firstOrNull { it.id == id } ?: all[0]

    fun rowsFor(lang: Lang, style: String): List<String> = styleRows(style) ?: lang.rows

    /** Enabled languages (max 5). Defaults to the system language + English. */
    fun enabled(): List<String> {
        val raw = P.LANGS.get().split(",").map { it.trim() }
            .filter { id -> all.any { l -> l.id == id } }.distinct()
        if (raw.isNotEmpty()) return raw.take(5)
        val sys = Locale.getDefault().language
        val list = ArrayList<String>()
        if (all.any { it.id == sys }) list.add(sys)
        if (!list.contains("en")) list.add("en")
        return list
    }

    fun active(): String {
        val e = enabled()
        val a = P.ACTIVE.get()
        return if (e.contains(a)) a else e[0]
    }
}

object LayoutFactory {
    private val DIGIT_ALTS: Map<Char, List<String>> = mapOf(
        '1' to listOf("¹", "½", "⅓", "¼"), '2' to listOf("²", "⅔"), '3' to listOf("³", "¾"),
        '4' to listOf("⁴"), '0' to listOf("°", "∅", "ⁿ")
    )
    private val PERIOD_ALTS = listOf("…", ",", "!", "?", ":", ";", "'", "\"", "-", "_", "(", ")", "@", "/", "#")
    private val WEB_ALTS = listOf(".com", ".it", ".org", ".net", ".eu", "-", "_")

    private fun letter(ch: Char, lang: Lang, hint: String?): KeyDef {
        // accents first (é è à...), the number hint last: hold + release = first accent
        val alts = ArrayList<String>()
        val extra = lang.alts[ch]
        if (extra != null) for (e in extra) alts.add(e.toString())
        if (hint != null) alts.add(hint)
        return KeyDef(ch.toString(), ch.code, KType.LETTER, 1f, alts, null, hint, null)
    }

    private fun sym(s: String, alts: List<String> = emptyList(), w: Float = 1f): KeyDef =
        KeyDef(s, s[0].code, KType.SYMBOL, w, alts, null, null, null)

    private fun spacer(w: Float): KeyDef = KeyDef("", 0, KType.SPACER, w)
    private fun shiftKey(w: Float): KeyDef = KeyDef("shift", Code.SHIFT, KType.SHIFT, w)
    private fun backKey(w: Float): KeyDef = KeyDef("del", Code.BACKSPACE, KType.BACKSPACE, w)
    private fun mode(label: String, code: Int, w: Float): KeyDef = KeyDef(label, code, KType.MODE, w)
    private fun enterKey(w: Float): KeyDef = KeyDef("enter", Code.ENTER, KType.ENTER, w)

    private fun spaceKey(w: Float, langs: List<Lang>): KeyDef {
        val multi = langs.size > 1
        return KeyDef(
            " ", Code.SPACE, KType.SPACE, w,
            if (multi) langs.map { it.name } else emptyList(),
            if (multi) langs.map { "lang:" + it.id } else null,
            null, " "
        )
    }

    private fun digits(): List<KeyDef> = "1234567890".map { sym(it.toString(), DIGIT_ALTS[it] ?: emptyList()) }

    private fun bottom(modeKey: KeyDef, globe: Boolean, field: Int, langs: List<Lang>): List<KeyDef> {
        val row = ArrayList<KeyDef>()
        row.add(modeKey)
        if (globe) row.add(KeyDef("globe", Code.GLOBE, KType.GLOBE, 1f))
        row.add(
            when (field) {
                1 -> sym("@", listOf(",", "_", "-", "+"))
                2 -> sym("/", listOf(",", "-", "_", ":"))
                else -> sym(",", listOf(";", ":", "!", "?", "@", "#"))
            }
        )
        row.add(KeyDef("emoji", Code.EMOJI, KType.EMOJI, 1f))
        val others = 1.35f + (if (globe) 1f else 0f) + 1f + 1f + 1f + 1.7f
        row.add(spaceKey(10f - others, langs))
        row.add(sym(".", if (field == 0) PERIOD_ALTS else WEB_ALTS))
        row.add(enterKey(1.7f))
        return row
    }

    /** field: 0 normal, 1 e-mail, 2 url */
    fun letters(lang: Lang, style: String, numberRow: Boolean, globe: Boolean, field: Int, langs: List<Lang>): KbLayout {
        val rows = Langs.rowsFor(lang, style)
        val out = ArrayList<List<KeyDef>>()
        if (numberRow) out.add(digits())

        val r1 = rows[0].mapIndexed { i, ch ->
            val hint = if (!numberRow && i < 10) "1234567890"[i].toString() else null
            letter(ch, lang, hint)
        }
        val pad1 = (10f - r1.size) / 2f
        out.add(if (pad1 > 0f) listOf(spacer(pad1)) + r1 + listOf(spacer(pad1)) else r1)

        val r2 = rows[1].map { letter(it, lang, null) }
        val pad2 = (10f - r2.size) / 2f
        out.add(if (pad2 > 0f) listOf(spacer(pad2)) + r2 + listOf(spacer(pad2)) else r2)

        val r3 = rows[2].map { letter(it, lang, null) }
        val sw = max(1f, (10f - r3.size) / 2f)
        out.add(listOf(shiftKey(sw)) + r3 + listOf(backKey(sw)))

        out.add(bottom(mode("?123", Code.SYMBOLS, 1.35f), globe, field, langs))
        return KbLayout("letters", out)
    }

    fun symbols1(lang: Lang, globe: Boolean, field: Int, langs: List<Lang>): KbLayout {
        val r2 = listOf(
            sym("@"), sym("#"), sym(lang.currency, listOf("\$", "€", "£", "¥", "₹", "¢")),
            sym("%", listOf("‰")), sym("&"), sym("-", listOf("_", "–", "—", "•")),
            sym("+", listOf("±")), sym("(", listOf("[", "{", "<")), sym(")", listOf("]", "}", ">")),
            sym("/", listOf("\\", "|"))
        )
        val r3 = listOf(
            mode("=\\<", Code.SYMBOLS2, 1.5f), sym("*", listOf("†", "‡", "★")),
            sym("\"", listOf("“", "”", "„", "«", "»")), sym("'", listOf("‘", "’", "‚", "`")),
            sym(":"), sym(";"), sym("!", listOf("¡")), sym("?", listOf("¿")), backKey(1.5f)
        )
        return KbLayout("sym1", listOf(digits(), r2, r3, bottom(mode("ABC", Code.ABC, 1.35f), globe, field, langs)))
    }

    fun symbols2(globe: Boolean, field: Int, langs: List<Lang>): KbLayout {
        val r1 = listOf("~", "`", "|", "•", "√", "π", "÷", "×", "¶", "∆").map { sym(it) }
        val r2 = listOf("€", "£", "¥", "¢", "^", "°", "=", "{", "}", "\\").map { sym(it) }
        val r3 = listOf(mode("?123", Code.SYMBOLS, 1.5f)) +
            listOf("%", "©", "®", "™", "[", "]", "_").map { sym(it) } +
            listOf(backKey(1.5f))
        return KbLayout("sym2", listOf(r1, r2, r3, bottom(mode("ABC", Code.ABC, 1.35f), globe, field, langs)))
    }

    fun numeric(): KbLayout = KbLayout(
        "num",
        listOf(
            listOf(sym("1"), sym("2"), sym("3"), backKey(1f)),
            listOf(sym("4"), sym("5"), sym("6"), sym("-")),
            listOf(sym("7"), sym("8"), sym("9"), KeyDef(" ", Code.SPACE, KType.SPACE, 1f, emptyList(), null, null, " ")),
            listOf(sym(","), sym("0"), sym("."), enterKey(1f))
        )
    )

    fun phone(): KbLayout = KbLayout(
        "phone",
        listOf(
            listOf(sym("1"), sym("2"), sym("3"), backKey(1f)),
            listOf(sym("4"), sym("5"), sym("6"), sym("+")),
            listOf(sym("7"), sym("8"), sym("9"), sym(",")),
            listOf(sym("*", listOf("(", ")", "-")), sym("0"), sym("#", listOf(".", "/")), enterKey(1f))
        )
    )
}

package dev.creamy.keyboard

import android.content.Context
import android.content.SharedPreferences
import java.util.Locale

object Store {
    lateinit var sp: SharedPreferences
        private set

    fun init(ctx: Context) {
        if (!::sp.isInitialized) {
            sp = ctx.applicationContext.getSharedPreferences("creamy_prefs", Context.MODE_PRIVATE)
        }
    }
}

class BoolP(val key: String, val def: Boolean) {
    fun get(): Boolean = Store.sp.getBoolean(key, def)
    fun set(v: Boolean) { Store.sp.edit().putBoolean(key, v).apply() }
}

class IntP(val key: String, val def: Int) {
    fun get(): Int = Store.sp.getInt(key, def)
    fun set(v: Int) { Store.sp.edit().putInt(key, v).apply() }
}

class FloatP(val key: String, val def: Float) {
    fun get(): Float = Store.sp.getFloat(key, def)
    fun set(v: Float) { Store.sp.edit().putFloat(key, v).apply() }
}

class StrP(val key: String, val def: String) {
    fun get(): String = Store.sp.getString(key, def) ?: def
    fun set(v: String) { Store.sp.edit().putString(key, v).apply() }
}

/** Every preference of the keyboard, with its default value. */
object P {
    // typing
    val LANGS = StrP("langs", "")
    val ACTIVE = StrP("active_lang", "")
    val LAYOUT = StrP("layout_style", "auto")
    val NUMBER_ROW = BoolP("number_row", false)
    val HINTS = BoolP("hints", true)
    val PREVIEW = BoolP("preview", true)
    val AUTOCORRECT = BoolP("autocorrect", true)
    val SUGGEST = BoolP("suggest", true)
    val NEXTWORD = BoolP("nextword", true)
    val EMOJI_PRED = BoolP("emoji_pred", true)
    val AUTOCAP = BoolP("autocap", true)
    val DBLSPACE = BoolP("dblspace", true)
    val GLIDE = BoolP("glide", true)
    val TRAIL = BoolP("trail", true)
    val SPACE_CURSOR = BoolP("space_cursor", true)
    val BACK_SWIPE = BoolP("back_swipe", true)
    val LEARN = BoolP("learn", true)
    val INCOGNITO = BoolP("incognito", false)
    val LONGPRESS = IntP("longpress_ms", 350)
    val SHORTCUTS = StrP("shortcuts", "omw=On my way!\nbrb=Be right back")

    // look
    val THEME = StrP("theme", "you")
    val DARK = StrP("dark_mode", "system")
    val SEED = IntP("seed_color", 0xFF6750A4.toInt())
    val KEY_H = FloatP("key_height", 54f)
    val KEY_GAP = FloatP("key_gap", 5f)
    val ROW_GAP = FloatP("row_gap", 6f)
    val RADIUS = FloatP("key_radius", 14f)
    val ENTER_SHAPE = StrP("enter_shape", "wavy")
    val FUNC_SHAPE = StrP("func_shape", "pill")
    val WAVES = IntP("waves", 9)
    val WAVE_AMP = FloatP("wave_amp", 0.07f)
    val BOLD = BoolP("bold_labels", true)
    val LABEL_SCALE = FloatP("label_scale", 1f)
    val BORDERS = BoolP("key_borders", false)
    val PRESS = StrP("press_anim", "jelly")
    val BG_IMAGE = StrP("bg_image", "")
    val BG_DIM = FloatP("bg_dim", 0.35f)
    val SIZE = FloatP("size_scale", 1f)
    val ONE_HAND = StrP("one_hand", "off")
    val ONE_HAND_W = FloatP("one_hand_width", 0.82f)

    // sound & haptics
    val SOUND = BoolP("sound", true)
    val PROFILE = StrP("sound_profile", "creamy")
    val VOLUME = IntP("sound_volume", 70)
    val SOUND_UP = BoolP("sound_up", true)
    val MUTE_SILENT = BoolP("mute_silent", true)
    val HAPTIC = IntP("haptic", 2)

    // toolbar / clipboard
    val TOOLS = StrP("tools", "clipboard,emoji,gif,sticker,translate,ai,search,voice,onehand,resize,incognito,theme,settings")
    val CLIP_ON = BoolP("clip_on", true)
    val CLIP_TTL = IntP("clip_ttl_h", 1)

    // online services
    val GIPHY = StrP("giphy_key", "")
    val TR_TARGET = StrP("tr_target", "en")
    val AI_PROVIDER = StrP("ai_provider", "anthropic")
    val AI_KEY = StrP("ai_key", "")
    val AI_MODEL = StrP("ai_model", "claude-haiku-5-5")
    val AI_URL = StrP("ai_url", "")
    val EMOJI_RECENT = StrP("emoji_recent", "")
    val DICT_VER = IntP("dict_version", 0)
    val CLEAR_VER = IntP("clear_user_ver", 0)

    // typing statistics
    val ST_CHARS = IntP("st_chars", 0)
    val ST_WORDS = IntP("st_words", 0)
    val ST_CORR = IntP("st_corrected", 0)
    val ST_PRED = IntP("st_predicted", 0)
    val ST_SAVED = IntP("st_saved_keys", 0)
    val ST_GLIDE = IntP("st_glide_words", 0)
}

object Stats {
    fun inc(p: IntP, n: Int = 1) { p.set(p.get() + n) }
}

object Tx {
    val isIt: Boolean get() = Locale.getDefault().language == "it"
    fun t(ita: String, eng: String): String = if (isIt) ita else eng
}

package dev.creamy.keyboard

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.drawable.Drawable
import android.os.Build
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.widget.FrameLayout
import android.widget.LinearLayout
import androidx.core.graphics.ColorUtils
import kotlin.math.max
import kotlin.math.min

/** Draws the keyboard background: flat colour, or a photo with a dimming scrim. */
class BgDrawable : Drawable() {
    var theme: KbTheme? = null
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val src = Rect()

    override fun draw(c: Canvas) {
        val th = theme ?: return
        val b = bounds
        paint.style = Paint.Style.FILL
        paint.color = th.bg
        c.drawRect(b, paint)
        val bmp = th.bgBitmap
        if (bmp != null && b.width() > 0 && b.height() > 0) {
            val bw = bmp.width.toFloat()
            val bh = bmp.height.toFloat()
            val scale = max(b.width() / bw, b.height() / bh)
            val sw = b.width() / scale
            val sh = b.height() / scale
            src.set(((bw - sw) / 2f).toInt(), ((bh - sh) / 2f).toInt(), ((bw + sw) / 2f).toInt(), ((bh + sh) / 2f).toInt())
            c.drawBitmap(bmp, src, b, paint)
            paint.color = Color.argb((th.bgDim * 255f).toInt().coerceIn(0, 255), 0, 0, 0)
            c.drawRect(b, paint)
        }
    }

    override fun setAlpha(alpha: Int) {}

    override fun setColorFilter(colorFilter: ColorFilter?) {}

    @Suppress("DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/** Transparent layer on top of everything: key previews, accent popups and the swipe trail. */
class OverlayView(ctx: Context) : View(ctx) {
    var kb: KeyboardView? = null
    private val l1 = IntArray(2)
    private val l2 = IntArray(2)

    init {
        isClickable = false
        isFocusable = false
    }

    override fun onDraw(c: Canvas) {
        val k = kb ?: return
        getLocationInWindow(l1)
        k.getLocationInWindow(l2)
        k.drawOverlay(c, (l2[0] - l1[0]).toFloat(), (l2[1] - l1[1]).toFloat())
    }

    override fun onTouchEvent(event: MotionEvent): Boolean = false
}

/** Buttons shown next to the keyboard in one-handed mode. */
class SideStrip(ctx: Context) : View(ctx) {
    interface Listener {
        fun onExpand()
        fun onSwap()
    }

    var listener: Listener? = null
    var theme: KbTheme? = null
        set(v) {
            field = v
            invalidate()
        }
    private val density = ctx.resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = android.graphics.Path()
    private val top = RectF()
    private val bottom = RectF()

    private fun layoutButtons() {
        val s = min(width.toFloat() - 12f * density, 52f * density)
        val cx = width / 2f
        top.set(cx - s / 2f, 14f * density, cx + s / 2f, 14f * density + s)
        bottom.set(cx - s / 2f, top.bottom + 14f * density, cx + s / 2f, top.bottom + 14f * density + s)
    }

    override fun onDraw(c: Canvas) {
        val th = theme ?: return
        layoutButtons()
        paint.style = Paint.Style.FILL
        paint.color = if (th.bgBitmap != null) ColorUtils.setAlphaComponent(th.panel, 140) else th.bg
        c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
        for (i in 0 until 2) {
            val r = if (i == 0) top else bottom
            paint.color = th.btn
            val s = r.width() / 2f
            Shapes.fill(path, Shapes.wavy(th.waves, th.amp * 1.3f), r.centerX(), r.centerY(), s, s, 0f)
            c.drawPath(path, paint)
            KbIcons.draw(c, if (i == 0) KbIcons.EXPAND else KbIcons.SWAP, r.centerX(), r.centerY(), r.width() * 0.5f, th.btnText)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_UP) {
            layoutButtons()
            if (top.contains(e.x, e.y)) listener?.onExpand()
            else if (bottom.contains(e.x, e.y)) listener?.onSwap()
        }
        return true
    }
}

class KbRoot(ctx: Context) : FrameLayout(ctx) {
    val toolbar = ToolbarView(ctx)
    val kb = KeyboardView(ctx)
    val overlay = OverlayView(ctx)
    val side = SideStrip(ctx)
    private val column = LinearLayout(ctx)
    private val content = FrameLayout(ctx)
    private val bg = BgDrawable()
    private var panel: View? = null
    private val density = ctx.resources.displayMetrics.density

    /** Transparent strip above the toolbar where key previews can be drawn. */
    val popupPad: Int = (74f * density).toInt()

    init {
        clipChildren = false
        clipToPadding = false
        column.orientation = LinearLayout.VERTICAL
        column.background = bg
        column.addView(toolbar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        content.addView(kb, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        column.addView(content, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val lp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.START)
        lp.topMargin = popupPad
        addView(column, lp)

        val sp = FrameLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.BOTTOM or Gravity.END)
        sp.topMargin = popupPad
        side.visibility = View.GONE
        addView(side, sp)

        overlay.kb = kb
        kb.onOverlay = { overlay.invalidate() }
        addView(overlay, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        setOnApplyWindowInsetsListener { _, insets ->
            val b = navInset(insets)
            if (b != column.paddingBottom) column.setPadding(0, 0, 0, b)
            insets
        }
    }

    @Suppress("DEPRECATION")
    private fun navInset(i: WindowInsets): Int {
        return if (Build.VERSION.SDK_INT >= 30) {
            i.getInsets(WindowInsets.Type.navigationBars()).bottom
        } else {
            i.systemWindowInsetBottom
        }
    }

    /** Top of the visible (touchable) keyboard, relative to this view. */
    fun visibleTop(): Int = popupPad

    fun applyTheme(th: KbTheme) {
        bg.theme = th
        column.invalidate()
        toolbar.theme = th
        kb.theme = th
        side.theme = th
        overlay.invalidate()
    }

    fun setPanel(v: View?) {
        panel?.let { content.removeView(it) }
        panel = v
        if (v != null) {
            content.addView(v, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            kb.visibility = View.INVISIBLE
        } else {
            kb.visibility = View.VISIBLE
        }
    }

    fun hasPanel(): Boolean = panel != null

    fun setOneHand(mode: String, frac: Float) {
        val screenW = resources.displayMetrics.widthPixels
        val lp = column.layoutParams as FrameLayout.LayoutParams
        val sp = side.layoutParams as FrameLayout.LayoutParams
        if (mode == "off") {
            lp.width = ViewGroup.LayoutParams.MATCH_PARENT
            lp.gravity = Gravity.BOTTOM or Gravity.START
            side.visibility = View.GONE
        } else {
            val cw = (screenW * frac.coerceIn(0.6f, 0.95f)).toInt()
            val left = mode == "left"
            lp.width = cw
            lp.gravity = Gravity.BOTTOM or (if (left) Gravity.START else Gravity.END)
            sp.width = screenW - cw
            sp.gravity = Gravity.BOTTOM or (if (left) Gravity.END else Gravity.START)
            side.visibility = View.VISIBLE
        }
        column.layoutParams = lp
        side.layoutParams = sp
        requestLayout()
    }
}

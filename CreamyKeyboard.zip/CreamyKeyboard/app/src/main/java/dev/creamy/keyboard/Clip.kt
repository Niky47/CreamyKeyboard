package dev.creamy.keyboard

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class Clip(val text: String, var pinned: Boolean, val time: Long)

/** Clipboard history (like SwiftKey: recent items expire, pinned items stay). */
object ClipStore {
    private val items = ArrayList<Clip>()
    private var loaded = false

    private fun file(ctx: Context): File = File(ctx.filesDir, "clips.json")

    @Synchronized
    fun load(ctx: Context) {
        if (loaded) return
        loaded = true
        try {
            val arr = JSONArray(file(ctx).readText())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                items.add(Clip(o.getString("t"), o.optBoolean("p", false), o.optLong("ts", 0L)))
            }
        } catch (e: Exception) {
            // first run / unreadable file
        }
    }

    @Synchronized
    private fun save(ctx: Context) {
        try {
            val arr = JSONArray()
            for (c in items) {
                arr.put(JSONObject().put("t", c.text).put("p", c.pinned).put("ts", c.time))
            }
            file(ctx).writeText(arr.toString())
        } catch (e: Exception) {
            // best effort
        }
    }

    @Synchronized
    fun add(ctx: Context, text: String) {
        if (text.isBlank() || !P.CLIP_ON.get()) return
        load(ctx)
        if (items.any { it.pinned && it.text == text }) return
        items.removeAll { it.text == text }
        items.add(0, Clip(text, false, System.currentTimeMillis()))
        var unpinned = 0
        val it2 = items.iterator()
        while (it2.hasNext()) {
            val c = it2.next()
            if (!c.pinned) {
                unpinned++
                if (unpinned > 60) it2.remove()
            }
        }
        save(ctx)
    }

    @Synchronized
    fun list(ctx: Context): List<Clip> {
        load(ctx)
        val ttl = P.CLIP_TTL.get()
        if (ttl > 0) {
            val limit = System.currentTimeMillis() - ttl * 3_600_000L
            items.removeAll { !it.pinned && it.time < limit }
        }
        val out = ArrayList<Clip>()
        for (c in items) if (c.pinned) out.add(c)
        for (c in items) if (!c.pinned) out.add(c)
        return out
    }

    @Synchronized
    fun togglePin(ctx: Context, c: Clip) {
        c.pinned = !c.pinned
        save(ctx)
    }

    @Synchronized
    fun remove(ctx: Context, c: Clip) {
        items.remove(c)
        save(ctx)
    }

    @Synchronized
    fun clearUnpinned(ctx: Context) {
        items.removeAll { !it.pinned }
        save(ctx)
    }
}

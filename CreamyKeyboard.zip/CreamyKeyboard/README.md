# Creamy Keyboard

Tastiera Android (IME) con tre ingredienti:

1. **Estetica Material 3 Expressive**, come *Expressive Keyboard* di kotlalipopus (licenza MIT): colori Material You dal
   wallpaper, tasti che si "schiacciano" con molle (jelly), tasto Invio a forma espressiva (cookie / flower / clover…),
   anteprima del tasto a forma di cookie, popup degli accenti, pulsanti a cookie nella barra.
2. **Suoni da switch meccanici "creamy"** a ogni tasto (pressione + rilascio, tasti diversi per barra spaziatrice,
   invio, cancella, modificatori). Tre profili: *Creamy* (default), *Deep Thock*, *Soft Linear*.
3. **Le funzioni di Microsoft SwiftKey** (vedi tabella sotto).

## Come ottenere l'APK

Il codice è un progetto Android Studio completo. Servono solo `Android Studio` **oppure** GitHub.

**A. Con GitHub (senza installare nulla)**
1. Crea un repository su GitHub e carica tutto il contenuto di questa cartella (anche `.github/`).
2. Vai su *Actions → Build APK → Run workflow* (parte anche da solo a ogni push).
3. A fine build scarica l'artifact **CreamyKeyboard-apk**: dentro ci sono `app-debug.apk` e `app-release.apk`
   (entrambi installabili).

**B. Con Android Studio**
1. *File → Open* e scegli questa cartella (usa JDK 17; Android Studio scarica Gradle 8.13 da solo).
2. *Build → Build Bundle(s) / APK(s) → Build APK(s)*.

**C. Da terminale**: installa Gradle 8.13 e lancia `gradle :app:assembleDebug`
(oppure `gradle wrapper --gradle-version 8.13` una volta, poi `./gradlew :app:assembleDebug`).

> Nota onesta: il codice è stato scritto e controllato staticamente (parentesi, risorse, riferimenti, asset), ma
> **non è stato compilato né provato su un telefono** nell'ambiente in cui è stato generato. Se Gradle segnala un
> errore di compilazione, incollalo e si corregge in un attimo.

## Primo avvio

Apri l'app *Creamy Keyboard* → **Configurazione**: 1) attiva la tastiera, 2) sceglila, 3) consenti il microfono
(solo per la dettatura). Poi regola tema, suoni, lingue, barra strumenti.

## Funzioni (confronto con SwiftKey)

| SwiftKey | Creamy Keyboard |
|---|---|
| Predizioni + autocorrezione che imparano | Sì: modello locale (parole + coppie di parole), correzione "a vicinanza di tasti", accenti (perche → perché), annulla con backspace, scorciatoie di testo |
| Previsione della parola successiva | Sì |
| Flow (swipe typing) | Sì, con scia colorata e alternative nella barra suggerimenti |
| Più lingue insieme (fino a 5) | Sì: en, it, es, fr, de, pt; previsioni unite; layout QWERTY/QWERTZ/AZERTY/Colemak/Dvorak; importi dizionari `.txt` |
| Emoji: pannello, ricerca, previsione, toni della pelle | Sì (ricerca in IT/EN) |
| GIF e sticker | Sì, via Giphy (chiave API gratuita nelle impostazioni) |
| Appunti con cronologia e fissati | Sì (senza sync cloud) |
| Traduttore | Sì (MyMemory, gratuito) |
| Copilot: tono / riformula / scrivi | Equivalente con la **tua** chiave Anthropic (Claude) o API compatibile OpenAI |
| Ricerca dalla tastiera | Sì (apre il browser) |
| Modalità incognito | Sì |
| Dettatura vocale | Sì (riconoscimento di sistema) |
| Una mano / ridimensiona / temi / foto di sfondo | Sì (una mano sx/dx, altezza regolabile, 8 temi + colore personalizzato + foto) |
| Cursore con la barra spaziatrice, scorri su cancella | Sì |
| Riga numeri, accenti con pressione lunga, simboli | Sì |
| Barra strumenti personalizzabile | Sì (attiva/disattiva/riordina) |
| Statistiche di scrittura | Sì |
| Account Microsoft: sincronizzazione, backup cloud, To Do, Outlook, Copilot ufficiale | **Non inclusi** (richiedono i servizi Microsoft) |
| Tastiera flottante / split | Non inclusi |

## Personalizzare i suoni

I suoni sono **sintetizzati** (nessun campione, nessun problema di licenza) da `tools/generate_sounds.py`.
Modifica i parametri in `PROFILES` (frequenza del "thock", durata, tap, sub-basso…) e rilancia:

```
python3 tools/generate_sounds.py
```

I file vanno in `app/src/main/res/raw/` (`snd_<profilo>_<nome>.wav`). Puoi anche sostituirli con campioni tuoi,
mantenendo gli stessi nomi.

## Struttura

```
app/src/main/java/dev/creamy/keyboard/
  CreamyIME.kt      servizio di tastiera (digitazione, autocorrezione, swipe, emoji, voce…)
  KeyboardView.kt   tasti disegnati a mano: molle, anteprime a cookie, popup, swipe, cursore
  ToolbarView.kt    barra suggerimenti / strumenti / ricerca inline
  Panels.kt         emoji, appunti, GIF/sticker, traduttore + AI
  Engine.kt         dizionari, modello utente, previsioni, autocorrezione, decodifica swipe
  Shapes.kt Theme.kt Icons.kt Layouts.kt Audio.kt Emoji.kt Clip.kt Net.kt Root.kt Prefs.kt
  MainActivity.kt   impostazioni (Jetpack Compose) con anteprima dal vivo
app/src/main/assets/dict/*.txt   dizionari base (parole per frequenza, coppie, correzioni)
app/src/main/assets/emoji.txt    emoji con parole chiave IT/EN
```

## Crediti e licenze

- Linguaggio visivo: Material 3 Expressive (Google). Ispirazione diretta: *Expressive Keyboard* di
  kotlalipopus (MIT) — nessun codice è stato copiato.
- Funzioni ispirate a Microsoft SwiftKey; nessun codice o asset Microsoft è usato.
- GIF/sticker: Giphy API (tua chiave). Traduzione: MyMemory. AI: tuo provider.
